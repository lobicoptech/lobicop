# LOBICOP — Base de travail de démonstration

Ce dossier est indépendant du code. Il contient les données initiales de démonstration : comptes, boutiques, produits et médias.

## Utilisation

1. Copiez/remplacez le dossier `demo_data/` à la racine du projet.
2. Au démarrage, LOBICOP importe les données absentes dans la base locale.
3. Les images peuvent être remplacées dans `media/stores/` et `media/products/` sans modifier le code.
4. Le chargement est idempotent : un redémarrage ne crée pas de doublons.

Comptes de démonstration : mot de passe `Demo12345!`.
