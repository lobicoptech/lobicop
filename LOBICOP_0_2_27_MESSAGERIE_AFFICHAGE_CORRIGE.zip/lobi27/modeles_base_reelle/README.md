Copier BOUTIQUE dans base_reelle/boutiques/ et UTILISATEUR dans base_reelle/utilisateurs/, puis renseigner les informations réelles.
