const $=s=>document.querySelector(s);
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function escAttr(s){return esc(s).replace(/`/g,'&#096;')}let current=null,cart=[],currentSectorCategories=[];
let auth=null;try{auth=JSON.parse(localStorage.getItem('lobicop_auth')||'null')}catch(e){auth=null}

async function api(url,opt){const r=await fetch(url,opt);const d=await r.json();if(!r.ok)throw Error(d.error||'Erreur');return d}
function authHeaders(extra){return Object.assign({},extra||{}, auth?{'Authorization':'Bearer '+auth.token}:{})}
function money(v){return Number(v).toLocaleString('fr-FR')+' FCFA'}

function saveAuth(a){auth=a;localStorage.setItem('lobicop_auth',JSON.stringify(a));refreshAuthUI()}
function clearAuth(){auth=null;localStorage.removeItem('lobicop_auth');refreshAuthUI()}
async function loadMyStores(){
  const box=$('#myStores'); if(!box) return;
  if(!auth){box.innerHTML='<p class="muted">Connectez-vous pour voir vos boutiques.</p>';return}
  try{
    const d=await api('/api/my/stores',{headers:authHeaders()});
    if(!d.items.length){box.innerHTML='<div class="emptyStore"><p>Vous n’avez pas encore de boutique.</p><button id="accountCreateSpace2" class="primary" type="button">Créer ma boutique →</button></div>';$('#accountCreateSpace2')?.addEventListener('click',()=>$('#openCreateSpace')?.click());return;}
    box.innerHTML=d.items.map(st=>`<article class="myStore"><div><span class="state ${st.open?'open':''}">${st.open?'Ouvert':'Fermé'}</span><h4>${st.name}</h4><p>${st.sector_label||st.sector} · ${st.district||''}${st.city?', '+st.city:''}</p></div><div class="myStoreActions"><button class="secondaryBtn accountEnterStore" data-id="${st.id}" type="button">Ma boutique →</button><button class="textDanger accountDeleteStore" data-id="${st.id}" data-name="${String(st.name).replace(/"/g,'&quot;')}" type="button">Supprimer</button></div></article>`).join('');
  }catch(e){box.innerHTML='<p class="muted">Impossible de charger vos boutiques.</p>';}
}
function refreshAccountPage(){
  const guest=$('#accountGuest'),details=$('#accountDetails'); if(!guest||!details)return;
  const logged=!!auth; guest.classList.toggle('hidden',logged); details.classList.toggle('hidden',!logged);
  if(logged){$('#globalAccountName').textContent=auth.account.name;$('#globalAccountMeta').textContent=auth.account.email;$('#accountAvatar').textContent=(auth.account.name||'L').trim().charAt(0).toUpperCase();loadMyStores();}
}
function refreshAuthUI(){
  const logged=!!auth;
  $('#openLogin').classList.toggle('hidden',logged);
  $('#openSignup').classList.toggle('hidden',logged);
  $('#accountMenu').classList.toggle('hidden',!logged);
  if(logged){$('#accountName').textContent=auth.account.name}
  if(current)renderOwnerPanel();
  refreshAccountPage();
}
function renderOwnerPanel(){
  const isOwner=auth && current && auth.account.id===current.owner_id;
  $('#ownerPanel').classList.toggle('hidden',!isOwner);
  if(isOwner){
    $('#opCategory').innerHTML=currentSectorCategories.map(c=>`<option value="${c}">${c}</option>`).join('');
    $('#mySpaceLink').classList.remove('hidden');
    $('#mySpaceLink').href=`#espace=${encodeURIComponent(current.id)}`;
  }
}

/* Carte boutique (résultats de recherche) — 0.2.18 */
const escH=esc;
const safeImg=s=>typeof s==='string'&&s.startsWith('data:image/')?s:'';
const svgIc=d=>`<span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg></span>`;
const IC={
  store:'<path d="M4 9l1.5-5h13L20 9M4 9v11h16V9M4 9a2.5 2.5 0 0 0 5 0 2.5 2.5 0 0 0 5 0 2.5 2.5 0 0 0 5 0M10 20v-5h4v5"/>',
  clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  pin:'<path d="M12 21s6-5.6 6-11a6 6 0 0 0-12 0c0 5.4 6 11 6 11Z"/><path d="M12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>',
  phone:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A15 15 0 0 1 4 5a1 1 0 0 1 1-1Z"/>',
  arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>'
};
function storeCard(s){
  const cover=safeImg(s.cover_data),logo=safeImg(s.logo_data);
  const place=[s.district,s.city].filter(Boolean).join(', ');
  return `<article class="storeCard"><div class="storeCover">${cover?`<img src="${cover}" alt="" loading="lazy">`:''}</div><div class="storeHead"><span class="storeLogo">${logo?`<img src="${logo}" alt="">`:svgIc(IC.store)}</span><div><h3>${escH(s.name)}</h3><p>${escH(s.sector_label||s.sector)}${place?' · '+escH(place):''}</p></div></div>${s.description?`<p class="storeDesc">${escH(s.description)}</p>`:''}<div class="storeFacts"><div class="storeFact ${s.open?'isOpen':'isClosed'}">${svgIc(IC.clock)}<small>${s.open?'Ouvert':'Fermé'}</small></div><div class="storeFact">${svgIc(IC.pin)}<small>${escH(s.address||place||'—')}</small></div><div class="storeFact">${svgIc(IC.phone)}<small>${escH(s.phone||'—')}</small></div></div><button class="enter" data-id="${escH(s.id)}" type="button">Voir la boutique ${svgIc(IC.arrow)}</button></article>`;
}
function render(items){const box=$('#stores');box.innerHTML=items.length?items.map(storeCard).join(''):`<article class="store"><div><h3>Aucun résultat</h3><p>Essayez un autre terme.</p></div></article>`;$('#count').textContent=items.length+' résultat'+(items.length>1?'s':'');$('#results').classList.remove('hidden')}
async function search(){const q=$('#q').value.trim();if(!q){$('#results').classList.add('hidden');return}try{const d=await api('/api/search?q='+encodeURIComponent(q));render(d.items)}catch(e){console.error(e)}}
async function enter(id){location.href=`/boutique/?store=${encodeURIComponent(id)}`};
$('#liSubmit')?.addEventListener('click',async()=>{
  try{
    const email=$('#liEmail').value.trim(),password=$('#liPassword').value;
    if(!email||!password)throw Error('Merci de remplir tous les champs');
    const d=await api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
    saveAuth({token:d.token,account:d.account});hideModal('#loginModal');
    $('#liEmail').value='';$('#liPassword').value='';
  }catch(e){$('#liMsg').textContent=e.message}
});
$('#accountToggle')?.addEventListener('click',()=>$('#accountDropdown').classList.toggle('hidden'));
$('#logoutBtn')?.addEventListener('click',async()=>{
  try{await api('/api/auth/logout',{method:'POST',headers:authHeaders()})}catch(e){}
  clearAuth();$('#accountDropdown')?.classList.add('hidden');
});

/* --- Création d'espace --- */
async function loadSectorsIntoSelect(){
  try{
    const d=await api('/api/sectors');
    $('#spSector').innerHTML='<option value="">Choisir un secteur…</option>'+d.items.map(s=>`<option value="${s.id}">${s.label}</option>`).join('');
  }catch(e){}
}
$('#openCreateSpace')?.addEventListener('click',async()=>{$('#spMsg').textContent='';await loadSectorsIntoSelect();showModal('#spaceModal')});
$('#closeSpace')?.addEventListener('click',()=>hideModal('#spaceModal'));
$('#spSubmit')?.addEventListener('click',async()=>{
  try{
    const payload={
      name:$('#spName').value.trim(),sector:$('#spSector').value,city:$('#spCity').value.trim(),
      district:$('#spDistrict').value.trim(),address:$('#spAddress').value.trim(),
      phone:$('#spPhone').value.trim(),description:$('#spDescription').value.trim()
    };
    if(!payload.name||!payload.sector||!payload.city)throw Error('Nom, secteur et ville sont requis');
    const d=await api('/api/spaces',{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify(payload)});
    hideModal('#spaceModal');
    ['spName','spCity','spDistrict','spAddress','spPhone','spDescription'].forEach(id=>$('#'+id).value='');
    location.hash=`#espace=${encodeURIComponent(d.store.id)}`;
    await enter(d.store.id);
  }catch(e){$('#spMsg').textContent=e.message}
});

/* --- Panneau propriétaire : ajouter un produit/article à son espace --- */
$('#opSubmit')?.addEventListener('click',async()=>{
  try{
    if(!current)throw Error('Espace introuvable');
    const payload={
      name:$('#opName').value.trim(),category:$('#opCategory').value,
      price:Number($('#opPrice').value||0),stock:Number($('#opStock').value||0),
      description:$('#opDesc').value.trim()
    };
    if(!payload.category)throw Error('Choisissez une catégorie');
    if(!payload.name)throw Error('Nom requis');
    await api(`/api/stores/${current.id}/products`,{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify(payload)});
    $('#opMsg').textContent='Ajouté au catalogue.';
    ['opName','opPrice','opStock','opDesc'].forEach(id=>$('#'+id).value='');
    const d=await api(`/api/stores/${current.id}/catalog`);renderCatalog(d.products);
  }catch(e){$('#opMsg').textContent=e.message}
});

refreshAuthUI();


// Classic-first Global navigation. The boutique has its own exact bottom navigation.
function showGlobalPage(page){
  document.querySelectorAll('.globalPage').forEach(el=>el.classList.add('hidden'));
  const target=document.getElementById(page==='account'?'accountPage':page);
  if(target) target.classList.remove('hidden');
  if(page==='account') refreshAccountPage();
  document.querySelectorAll('.globalNavItem').forEach(b=>b.classList.toggle('active',b.dataset.globalPage===page));
  const main=document.getElementById('globalMain');
  if(main) main.scrollTop=0;
}
document.querySelectorAll('.globalNavItem:not([data-global-page=\"messages\"])').forEach(b=>b.addEventListener('click',()=>showGlobalPage(b.dataset.globalPage)));
$('#discoverTop')?.addEventListener('click',()=>showGlobalPage('discover'));
$('#closeDiscover')?.addEventListener('click',()=>showGlobalPage('home'));
document.querySelectorAll('[data-query]').forEach(b=>b.addEventListener('click',()=>{ $('#q').value=b.dataset.query; showGlobalPage('results'); search(); }));


function showModal(sel){$(sel)?.classList.remove('hidden')}
function hideModal(sel){$(sel)?.classList.add('hidden')}
$('#openLogin')?.addEventListener('click',()=>showModal('#loginModal'));
$('#openSignup')?.addEventListener('click',()=>showModal('#signupModal'));
$('#closeLogin')?.addEventListener('click',()=>hideModal('#loginModal'));
$('#closeSignup')?.addEventListener('click',()=>hideModal('#signupModal'));
$('#switchToSignup')?.addEventListener('click',()=>{hideModal('#loginModal');showModal('#signupModal')});
$('#switchToLogin')?.addEventListener('click',()=>{hideModal('#signupModal');showModal('#loginModal')});
$('#signupModal')?.addEventListener('click',e=>{if(e.target.id==='signupModal')hideModal('#signupModal')});
$('#loginModal')?.addEventListener('click',e=>{if(e.target.id==='loginModal')hideModal('#loginModal')});
$('#searchForm')?.addEventListener('submit',e=>{e.preventDefault();showGlobalPage('results');search()});
$('#clear')?.addEventListener('click',()=>{$('#q').value='';$('#q').focus();showGlobalPage('home')});
$('#stores')?.addEventListener('click',e=>{const b=e.target.closest('.enter');if(b)enter(b.dataset.id)});
$('#discoverTop')?.addEventListener('click',()=>showGlobalPage('discover'));
$('#spSector') && loadSectorsIntoSelect();
$('#openCreateSpace')?.addEventListener('click',()=>showModal('#spaceModal'));
$('#closeSpace')?.addEventListener('click',()=>hideModal('#spaceModal'));
$('#accountLoginBtn')?.addEventListener('click',()=>showModal('#loginModal'));
$('#accountCreateSpace')?.addEventListener('click',()=>$('#openCreateSpace')?.click());
$('#myStores')?.addEventListener('click',async e=>{
  const enterBtn=e.target.closest('.accountEnterStore');
  if(enterBtn){ enter(enterBtn.dataset.id); return; }
  const delBtn=e.target.closest('.accountDeleteStore');
  if(delBtn){
    const name=delBtn.dataset.name||'cette boutique';
    if(!confirm(`Supprimer « ${name} » définitivement ? Cette action est irréversible.`))return;
    try{await api(`/api/stores/${encodeURIComponent(delBtn.dataset.id)}`,{method:'DELETE',headers:authHeaders()});await loadMyStores();}catch(err){alert(err.message)}
  }
});
$('#deleteAccountBtn')?.addEventListener('click',async()=>{
  if(!auth)return;
  const ok=confirm('Supprimer définitivement votre compte et vos boutiques ? Cette action est irréversible.');
  if(!ok)return;
  const confirmName=prompt('Pour confirmer, saisissez SUPPRIMER');
  if(confirmName!=='SUPPRIMER')return;
  try{await api('/api/auth/account',{method:'DELETE',headers:authHeaders()});clearAuth();showGlobalPage('home');alert('Votre compte a été supprimé.');}catch(e){alert(e.message)}
});
$('#suSubmit')?.addEventListener('click',async()=>{try{const d=await api('/api/auth/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('#suName').value.trim(),email:$('#suEmail').value.trim(),password:$('#suPassword').value})});saveAuth({token:d.token,account:d.account});hideModal('#signupModal');$('#globalAccountName').textContent=d.account.name;showGlobalPage('account')}catch(e){$('#suMsg').textContent=e.message}});

/* --- Messagerie temps réel : interface simple, privée et réactive -------- */
let messageStream=null, conversations=[], activeConversation=null;
function messageApi(path,opt={}){opt.headers=authHeaders(Object.assign({'Content-Type':'application/json'},opt.headers||{}));return api(path,opt)}
function messageTitle(c){return c.kind==='store'?(c.store?.name||'Boutique'):(c.other?.name||c.other?.email||'Utilisateur')}
function messageMeta(c){return c.kind==='store'?'Boutique LobiCop':(c.other?.email||'Utilisateur LobiCop')}
function messageInitial(c){return (messageTitle(c)||'L').trim().charAt(0).toUpperCase()}
function formatMessageTime(v){if(!v)return '';const d=new Date(v);if(Number.isNaN(d.getTime()))return '';return d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}
function formatMessageDay(v){if(!v)return '';const d=new Date(v);if(Number.isNaN(d.getTime()))return '';const today=new Date();const yesterday=new Date();yesterday.setDate(today.getDate()-1);if(d.toDateString()===today.toDateString())return "Aujourd’hui";if(d.toDateString()===yesterday.toDateString())return 'Hier';return d.toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'})}
function renderMessageBadge(total){const n=Number(total)||0;['#messageNavBadge','#messageUnreadTotal'].forEach(sel=>{const el=$(sel);if(!el)return;el.hidden=n<=0;if(n>0)el.textContent=n>99?'99+':String(n)})}
function renderConversations(){
  const box=$('#conversationList');if(!box)return;
  const q=($('#conversationSearch')?.value||'').trim().toLocaleLowerCase();
  const items=conversations.filter(c=>{if(!q)return true;return [messageTitle(c),messageMeta(c),c.last_body||''].join(' ').toLocaleLowerCase().includes(q)});
  const total=conversations.reduce((n,c)=>n+Number(c.unread_count||0),0);renderMessageBadge(total);
  if(!items.length){box.innerHTML=q?'<div class="messageEmptyList"><b>Aucun résultat</b><span>Essayez un autre nom ou message.</span></div>':'<div class="messageEmptyList"><b>Vos conversations</b><span>Écrivez à une boutique ou à un utilisateur.</span></div>';return}
  box.innerHTML=items.map(c=>{const unread=Number(c.unread_count||0);return `<button class="conversationItem ${activeConversation?.id===c.id?'active':''} ${unread?'unread':''}" data-cid="${escAttr(c.id)}"><span class="conversationAvatar">${esc(messageInitial(c))}</span><span class="conversationBody"><b>${esc(messageTitle(c))}</b><small>${esc(c.last_body||'Nouvelle conversation')}</small></span><span class="conversationSide"><time>${esc(formatMessageTime(c.last_message_at||c.updated_at))}</time>${unread?`<i>${unread>9?'9+':unread}</i>`:''}</span></button>`}).join('')
}
async function loadConversations(){
  if(!auth){conversations=[];activeConversation=null;renderConversations();return []}
  try{
    const d=await messageApi('/api/messages/conversations');
    conversations=d.items||[];
    if(activeConversation){activeConversation=conversations.find(c=>c.id===activeConversation.id)||null}
    renderConversations();
    return conversations;
  }catch(e){
    console.error(e);
    const box=$('#conversationList');
    if(box)box.innerHTML='<div class="messageEmptyList"><b>Messagerie indisponible</b><span>Impossible de charger vos conversations.</span><button class="textBtn" type="button" onclick="loadConversations()">Réessayer</button></div>';
    return [];
  }
}
function renderMessages(items){
  const list=$('#messageList');if(!list)return;
  let html='',lastDay='';
  for(const m of items||[]){const day=formatMessageDay(m.created_at);if(day!==lastDay){html+=`<div class="messageDay"><span>${esc(day)}</span></div>`;lastDay=day}const mine=m.sender_id===auth.account.id;html+=`<div class="messageRow ${mine?'mine':'theirs'}"><div class="messageBubble"><div class="messageBody">${esc(m.body)}</div><div class="messageInfo"><time>${esc(formatMessageTime(m.created_at))}</time>${mine&&m.read_at?'<span>Lu</span>':''}</div></div></div>`}
  list.innerHTML=html||'<div class="messageConversationEmpty">Commencez la conversation.</div>';requestAnimationFrame(()=>{list.scrollTop=list.scrollHeight});
}
async function openConversation(cid,showOnMobile=true){
  const c=conversations.find(x=>x.id===cid);if(!c)return;activeConversation=c;renderConversations();
  $('#chatEmpty')?.classList.add('hidden');$('#chatActive')?.classList.remove('hidden');
  $('#chatTitle').textContent=messageTitle(c);$('#chatMeta').textContent=messageMeta(c);$('#chatAvatar').textContent=messageInitial(c);
  $('#messagesPage')?.classList.toggle('conversation-open',!!showOnMobile);
  try{
    await messageApi('/api/messages/conversations/'+encodeURIComponent(cid)+'/read',{method:'PUT'});
    const d=await messageApi('/api/messages/conversations/'+encodeURIComponent(cid)+'/messages');
    renderMessages(d.items||[]);await loadConversations();
    $('#messageInput')?.focus();
  }catch(e){console.error(e)}
}
function startMessageStream(){if(messageStream||!auth?.token)return;const u=new URL('/api/messages/stream',location.origin);u.searchParams.set('token',auth.token);messageStream=new EventSource(u);messageStream.onmessage=async e=>{try{const evt=JSON.parse(e.data);if(evt.type==='message_created'){await loadConversations();if(activeConversation?.id===evt.conversation_id)await openConversation(evt.conversation_id,false)}}catch(_){} };messageStream.onerror=()=>{messageStream?.close();messageStream=null;setTimeout(startMessageStream,2000)}}
function stopMessageStream(){messageStream?.close();messageStream=null}
async function openMessages(){
  if(!auth){showModal('#loginModal');return}
  // Afficher la page immédiatement : le réseau ne doit jamais laisser l'onglet
  // Messages visuellement vide pendant le chargement des conversations.
  showGlobalPage('messages');
  const page=$('#messagesPage');
  page?.classList.remove('hidden');
  $('#chatEmpty')?.classList.remove('hidden');
  $('#chatActive')?.classList.add('hidden');
  $('#messagesPage')?.classList.remove('conversation-open');
  renderConversations();
  await loadConversations();
}
document.querySelectorAll('.globalNavItem[data-global-page="messages"]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();openMessages()}));
$('#conversationList')?.addEventListener('click',e=>{const b=e.target.closest('.conversationItem');if(b)openConversation(b.dataset.cid,true)});
$('#conversationSearch')?.addEventListener('input',renderConversations);
$('#backToConversations')?.addEventListener('click',()=>{$('#messagesPage')?.classList.remove('conversation-open');activeConversation=null;$('#chatActive')?.classList.add('hidden');$('#chatEmpty')?.classList.remove('hidden');renderConversations()});
function openNewMessage(){if(!auth){showModal('#loginModal');return}$('#userSearchResults').innerHTML='';$('#userSearch').value='';showModal('#newMessageModal');setTimeout(()=>$('#userSearch').focus(),50)}
$('#newMessageBtn')?.addEventListener('click',openNewMessage);$('#emptyNewMessageBtn')?.addEventListener('click',openNewMessage);$('#closeNewMessage')?.addEventListener('click',()=>hideModal('#newMessageModal'));
let userSearchTimer=null;$('#userSearch')?.addEventListener('input',()=>{clearTimeout(userSearchTimer);userSearchTimer=setTimeout(async()=>{const q=$('#userSearch').value.trim();if(q.length<2){$('#userSearchResults').innerHTML='';return}try{const d=await messageApi('/api/accounts/search?q='+encodeURIComponent(q));$('#userSearchResults').innerHTML=(d.items||[]).map(a=>`<button class="userResult" data-aid="${escAttr(a.id)}"><span class="userResultAvatar">${esc((a.name||'L').trim().charAt(0).toUpperCase())}</span><span><b>${esc(a.name)}</b><small>${esc(a.email)}</small></span></button>`).join('')||'<p class="muted">Aucun utilisateur trouvé.</p>'}catch(e){$('#userSearchResults').textContent=e.message}},220)});
$('#userSearchResults')?.addEventListener('click',async e=>{const b=e.target.closest('.userResult');if(!b)return;try{const d=await messageApi('/api/messages/conversations',{method:'POST',body:JSON.stringify({target_account_id:b.dataset.aid})});hideModal('#newMessageModal');showGlobalPage('messages');await loadConversations();openConversation(d.conversation.id,true)}catch(err){alert(err.message)}});
$('#messageForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!activeConversation||!auth)return;const input=$('#messageInput'),body=input.value.trim();if(!body)return;const btn=e.submitter||e.currentTarget.querySelector('button');btn.disabled=true;try{await messageApi('/api/messages/conversations/'+encodeURIComponent(activeConversation.id)+'/messages',{method:'POST',body:JSON.stringify({body})});input.value='';await openConversation(activeConversation.id,false)}catch(err){alert(err.message)}finally{btn.disabled=false;input.focus()}});
$('#messageInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('#messageForm')?.requestSubmit()}});
async function contactStore(storeId){if(!auth){showModal('#loginModal');return}try{const d=await messageApi('/api/messages/conversations',{method:'POST',body:JSON.stringify({store_id:storeId})});showGlobalPage('messages');await loadConversations();openConversation(d.conversation.id,true)}catch(e){alert(e.message)}}
const _oldRefreshAuthUI=refreshAuthUI;refreshAuthUI=function(){_oldRefreshAuthUI();if(auth){startMessageStream();loadConversations()}else{stopMessageStream();conversations=[];activeConversation=null;renderMessageBadge(0);$('#chatActive')?.classList.add('hidden');$('#chatEmpty')?.classList.remove('hidden');$('#messagesPage')?.classList.remove('conversation-open')}};
if(auth){startMessageStream();loadConversations()}

const messageQuery=new URLSearchParams(location.search);
if(messageQuery.get('messages')==='1'){
  showGlobalPage('messages');
  setTimeout(async()=>{
    if(!auth){showModal('#loginModal');return}
    await loadConversations();
    const cid=messageQuery.get('conversation');
    if(cid)await openConversation(cid,true);
  },50);
}
