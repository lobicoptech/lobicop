
function updateShopIdentityDock(identity){
  const data = identity || {};
  const name = data.name || 'Ma boutique';
  const logo = data.logo || data.logo_data || data.image_data || '';
  const slogan = data.slogan || '';
  const contact = data.contact || data.phone || data.telephone || '—';
  const sector = data.sector || data.activity || '—';
  const setText = (id, value) => { const el = document.getElementById(id); if(el) el.textContent = value || '—'; };
  setText('shopDockName', name);
  setText('shopCardName', name);
  setText('shopCardSlogan', slogan);
  setText('shopCardContact', contact);
  setText('shopCardSector', sector);
  ['shopDockLogo','shopCardLogo'].forEach(id => {
    const img = document.getElementById(id);
    if(!img) return;
    if(logo){ img.src = logo; img.hidden = false; }
    else { img.removeAttribute('src'); img.hidden = true; }
  });
}
function bindShopIdentityDock(){
  const dock = document.getElementById('shopIdentityDock');
  const card = document.getElementById('shopIdentityCard');
  const close = document.getElementById('closeShopIdentityCard');
  if(!dock || !card || dock.dataset.bound) return;
  dock.dataset.bound = '1';
  const open = () => { card.hidden = false; dock.setAttribute('aria-expanded','true'); card.scrollIntoView({behavior:'smooth', block:'nearest'}); };
  const shut = () => { card.hidden = true; dock.setAttribute('aria-expanded','false'); };
  dock.addEventListener('click', () => card.hidden ? open() : shut());
  close?.addEventListener('click', shut);
}

const $=s=>document.querySelector(s);
const ADMIN_PARAMS=new URLSearchParams(location.search);let ADMIN_STORE=ADMIN_PARAMS.get('store')||'';let adminStream=null;let authAdmin=null;try{authAdmin=JSON.parse(localStorage.getItem('lobicop_auth')||'null')}catch(_){}
function adminUrl(p){const u=new URL(p,location.origin);if(ADMIN_STORE)u.searchParams.set('store',ADMIN_STORE);return u.pathname+u.search}

const THEME_KEY='nzela_theme';
const THEME_SCALE_KEY='nzela_theme_scale';
function applyThemeScale(value){const scale=Math.max(0,Math.min(100,Number(value)||0));document.body.style.setProperty('--theme-scale',scale+'%');const el=$('#themeScale'),label=$('#themeScaleLabel');if(el)el.value=String(scale);if(label)label.textContent=String(scale)+'%';try{localStorage.setItem(THEME_SCALE_KEY,String(scale))}catch(e){}}
function applyTheme(mode,scale){document.body.classList.toggle('light',mode==='light');document.body.classList.toggle('admin-dark',mode!=='light');try{localStorage.setItem(THEME_KEY,mode)}catch(e){}applyThemeScale(scale ?? Number(localStorage.getItem(THEME_SCALE_KEY) ?? 50));const button=$('#themeToggle');if(button){button.textContent=mode==='light'?'☾':'☼';button.title=mode==='light'?'Passer en mode sombre':'Passer en mode clair';button.setAttribute('aria-label',button.title)}}
function theme(){const next=document.body.classList.contains('light')?'dark':'light';applyTheme(next)}
function initAdminTheme(){let mode='dark',scale=50;try{mode=(localStorage.getItem(THEME_KEY)||localStorage.getItem('nzela_theme_mode'))==='light'?'light':'dark';scale=Number(localStorage.getItem(THEME_SCALE_KEY) ?? 50)}catch(e){}applyTheme(mode,scale);$('#themeToggle')?.addEventListener('click',theme);$('#themeScale')?.addEventListener('input',e=>applyThemeScale(e.target.value));}
initAdminTheme();
async function api(p,o={}){const headers={'Content-Type':'application/json',...(o.headers||{})};if(authAdmin?.token)headers.Authorization='Bearer '+authAdmin.token;let r=await fetch(adminUrl(p),{cache:'no-store',...o,headers}),d=await r.json();if(!r.ok)throw Error(d.error||'Erreur');return d}
function opSpec(kind){return catalog.operations.find(o=>o.kind===kind)||{name:kind}}
function kindLabel(kind){return opSpec(kind).name}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function detailsText(it){const d=it.details||{};let pairs=[];for(const [k,v] of Object.entries(d)){if(k==='operation'||!v)continue;const labels={phone:'Numéro de téléphone',recipient_phone:'Bénéficiaire',recipient_name:'Nom du destinataire',operator:'Opérateur',amount:'Montant',target:'Destination',beneficiary_id:'Identifiant'};pairs.push(`${labels[k]||k}: ${esc(v)}`)}return pairs.join(' • ')}
function requestCard(x){const ops=(x.items||[]).map(it=>`<div class="requestOperation"><b>${esc(it.name)}</b><span>${esc(kindLabel(it.kind)||'Article')}</span><small>${it.quantity>1?`Quantité: ${it.quantity} • `:''}${detailsText(it)}</small></div>`).join('');return `<div class="listItem requestCard"><div><b>#${String(x.queue_number).padStart(3,'0')} — ${esc(x.customer_name)}</b><div class="mut">${esc(x.customer_phone||'')} • ${x.items?.length||0} article(s)</div><div class="requestOperations">${ops}</div></div><select onchange="setStatus('${x.id}',this.value)"><option ${x.status==='pending'?'selected':''}>pending</option><option ${x.status==='preparing'?'selected':''}>preparing</option><option ${x.status==='ready'?'selected':''}>ready</option><option ${x.status==='completed'?'selected':''}>completed</option><option ${x.status==='cancelled'?'selected':''}>cancelled</option></select></div>`}
function renderRequests(){const q=($('#requestSearch')?.value||'').toLowerCase();const items=allRequests.filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q));$('#requests').innerHTML=items.map(requestCard).join('')||'<p class="mut">Aucune demande.</p>';$('#requestsPreview').innerHTML=allRequests.slice(0,6).map(requestCard).join('')||'<p class="mut">Aucune demande.</p>'}
async function loadCategories(selected=''){
  const r=await api('/api/categories');
  categoriesCache=r.items||[];
  const form=$('#pcategory'), filter=$('#productCategoryFilter');
  if(form){
    const current=selected||form.value;
    form.innerHTML=categoriesCache.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('')+`<option value="__new__">＋ Ajouter une catégorie…</option>`;
    if(current && categoriesCache.some(c=>c.name===current)) form.value=current; else if(categoriesCache.length) form.value=categoriesCache[0].name;
  }
  if(filter){
    const current=productCategoryFilter||filter.value;
    filter.innerHTML='<option value="">Toutes les catégories</option>'+categoriesCache.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
    filter.value=categoriesCache.some(c=>c.name===current)?current:'';
  }
}
function renderProducts(){
  const q=(productCategoryFilter||'').toLocaleLowerCase();
  const items=productsCache.filter(x=>!q||String(x.category||'').toLocaleLowerCase()===q);
  $('#productList').innerHTML=items.map(x=>`<div class="listItem adminObject"><div><b>${esc(x.name)}</b><div class="mut">${esc(x.category)} • ${Number(x.price).toLocaleString('fr-FR')} FCFA • Stock: ${x.stock}</div></div><div><button onclick="editProduct('${x.id}')">Modifier</button> <button onclick="toggleProduct('${x.id}',${!x.available})">${x.available?'Masquer':'Afficher'}</button> <button onclick="deleteProduct('${x.id}')">Supprimer</button></div></div>`).join('')||'<p class="mut">Aucun produit dans cette catégorie.</p>';
}
function renderCategories(){
  const list=$('#categoryList');
  if(!list) return;
  list.innerHTML=categoriesCache.map(c=>`<div class="listItem adminObject"><div><b>${esc(c.name)}</b><div class="mut">Catégorie disponible pour les produits et services de cet espace.</div></div></div>`).join('')||'<p class="mut">Aucune catégorie.</p>';
}
let lastRequestSignature='';
async function refresh(){try{await fetchOrders();const [cfg,s,p,h,a,health,cats]=await Promise.all([api('/api/config'),api('/api/stats'),api('/api/products'),api('/api/admin/highlights'),api('/api/admin/announcements'),api('/api/health'),api('/api/categories')]);catalog=cfg.operation_catalog||{operations:[]};$('#stats').innerHTML=Object.entries(s.counts).map(([k,v])=>`<div class="stat"><span class="mut">${k}</span><b>${v}</b></div>`).join('');renderRequests();productsCache=p.items||[];categoriesCache=cats.items||[];await loadCategories($('#pcategory')?.value||'');renderProducts();renderCategories();$('#highlightList').innerHTML=h.items.map(x=>`<div class="listItem"><div><b>${esc(x.title)}</b><div class="mut">${esc(x.subtitle||'')} • ${esc(x.kind)}</div></div><button class="toggle ${x.active?'on':'off'}" onclick="toggleHighlight('${x.id}',${!x.active})">${x.active?'Publié — masquer':'Masqué — publier'}</button></div>`).join('')||'<p class="mut">Aucune mise en avant.</p>';$('#announcementList').innerHTML=a.items.map(x=>`<div class="listItem"><div><b>${esc(x.title)}</b><div class="mut">${esc(x.message)}</div></div><button class="toggle ${x.active?'on':'off'}" onclick="toggleAnnouncement('${x.id}',${!x.active})">${x.active?'Publié — masquer':'Masqué — publier'}</button></div>`).join('');updateConn()}catch(e){handleAdminError(e)}}

async function setStatus(id,status){await api('/api/requests/'+id+'/status',{method:'PUT',body:JSON.stringify({status})});refresh()}async function toggleHighlight(id,active){await api('/api/admin/highlights/'+id+'/active',{method:'PUT',body:JSON.stringify({active})});refresh()}async function toggleAnnouncement(id,active){await api('/api/admin/announcements/'+id+'/active',{method:'PUT',body:JSON.stringify({active})});refresh()}
document.querySelectorAll('.adminNav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.adminNav button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#tab-'+b.dataset.tab).classList.add('active');if(b.dataset.tab==='requests')renderRequests()});$('#requestSearch')?.addEventListener('input',renderRequests);
$('#announcementForm').onsubmit=async e=>{e.preventDefault();await api('/api/admin/announcements',{method:'POST',body:JSON.stringify({title:$('#atitle').value,message:$('#amessage').value,type:$('#atype').value})});e.target.reset();refresh()};/* =====================================================================
   COMMANDES EN TEMPS RÉEL (v0.2.6)
   Chaîne complète : le client commande -> le serveur publie l'événement
   « request_created » -> ce flux (EventSource) le reçoit -> on recharge la
   liste des commandes -> on prévient le propriétaire (bannière + son +
   titre de l'onglet + notification système si autorisée).
   Filets de sécurité : à chaque (re)connexion du flux, au retour sur
   l'onglet, au retour du réseau, et par un sondage léger de secours.
   ===================================================================== */
/* CAUSE RACINE du « l'admin ne voit pas les commandes » : `catalog` (et `allRequests`) n'étaient jamais déclarées.
   Dès qu'une commande existait au chargement de la page, l'affichage levait « catalog is not defined »,
   le chargement s'arrêtait, et chaque nouvelle tentative plantait pareil : liste vide pour toujours. */
let allRequests=[],catalog={operations:[]};
let timer=null,streamRetry=null,fullRefreshTimer=null;
let streamOpen=false,authBroken=false,lastOrdersSync=0,orderFetchSeq=0,knownOrderIds=null,unseenOrders=0,audioCtx=null;
const BASE_TITLE=document.title;
const ALERT_KEY='lobicop_admin_alerts',SESSION_KEY='lobicop_admin_session';

function setConn(t){const el=$('#adminConn');if(el)el.textContent=t}
function updateConn(){
  if(authBroken)return;
  if(!navigator.onLine)return setConn('Hors connexion — en attente du réseau');
  const n=allRequests.length+' demande(s)';
  setConn(streamOpen?'En ligne • commandes en temps réel • '+n:'Actualisation automatique • '+n);
}
function renderStats(c){const el=$('#stats');if(el&&c)el.innerHTML=Object.entries(c).map(([k,v])=>`<div class="stat"><span class="mut">${k}</span><b>${v}</b></div>`).join('')}

/* --- Session propriétaire ------------------------------------------------
   Le jeton de connexion est partagé (localStorage) avec la page client :
   si quelqu'un se connecte avec un AUTRE compte dans ce navigateur, le jeton
   du propriétaire est écrasé et l'admin ne voyait plus rien (403) sans
   explication. On garde donc une copie du jeton propriétaire qui a
   fonctionné, et on la réessaie si le jeton courant n'est plus le bon. */
function readSaved(key){try{const a=JSON.parse(localStorage.getItem(key)||'null');return a&&a.token?a:null}catch(_){return null}}
async function resolveAdminAuth(){
  const live=readSaved('lobicop_auth'),saved=readSaved(SESSION_KEY),tries=[];
  if(live)tries.push(live);
  if(saved&&(!live||saved.token!==live.token))tries.push(saved);
  let lastErr=new Error('authentication_required');
  for(const cand of tries){
    authAdmin=cand;
    try{
      const c=await api('/api/admin/context');
      try{localStorage.setItem(SESSION_KEY,JSON.stringify({token:cand.token,store:c.store.id}))}catch(_){}
      return c;
    }catch(e){lastErr=e}
  }
  throw lastErr;
}
function isAuthError(e){const m=String(e&&e.message||'');return m==='authentication_required'||m==='not_space_owner'}
function handleAdminError(e){
  console.error(e);
  if(isAuthError(e)){
    authBroken=true;streamOpen=false;adminStream?.close();clearInterval(timer);clearTimeout(streamRetry);
    setConn('⚠️ Session propriétaire invalide');
    showAuthBanner(String(e.message)==='not_space_owner'?"Ce compte n'est pas le propriétaire de cet espace.":"Votre session a expiré ou a été remplacée par une autre connexion dans ce navigateur.");
  }else{setConn('Connexion à vérifier — nouvelle tentative automatique…')}
}
function showAuthBanner(msg){
  ensureAlertUi();if($('#authBanner'))return;
  const b=document.createElement('div');b.id='authBanner';b.setAttribute('role','alert');
  const t=document.createElement('span');t.textContent='⚠️ '+msg+' Reconnectez-vous avec le compte propriétaire pour recevoir les commandes.';
  const a=document.createElement('a');a.href='/';a.textContent='Se reconnecter';
  const r=document.createElement('button');r.type='button';r.textContent='Réessayer';r.onclick=()=>location.reload();
  b.append(t,a,r);document.body.prepend(b);
}

/* --- Récupération des commandes + détection des nouvelles ------------------ */
async function fetchOrders(){
  const seq=++orderFetchSeq;
  const [r,st]=await Promise.all([api('/api/admin/requests'),api('/api/stats')]);
  if(seq<orderFetchSeq)return;              // réponse périmée : une plus récente est déjà passée
  const next=r.items||[];
  detectNewOrders(next);
  allRequests=next;
  lastRequestSignature=JSON.stringify(next.map(x=>[x.id,x.status,x.updated_at]));
  renderRequests();renderStats(st&&st.counts);
  lastOrdersSync=Date.now();updateConn();
}
async function refreshOrders(){if(authBroken)return;try{await fetchOrders()}catch(e){handleAdminError(e)}}
async function fetchOrderImmediately(id){
  if(!id||authBroken)return false;
  try{
    const x=await api('/api/admin/requests/'+encodeURIComponent(id));
    const idx=allRequests.findIndex(r=>r.id===x.id);
    if(idx>=0) allRequests[idx]=x; else allRequests.unshift(x);
    allRequests.sort((a,b)=>(b.queue_number||0)-(a.queue_number||0));
    lastRequestSignature=JSON.stringify(allRequests.map(r=>[r.id,r.status,r.updated_at]));
    renderRequests();updateConn();
    detectNewOrders([x]);
    lastOrdersSync=Date.now();
    return true;
  }catch(e){
    console.warn('Commande temps réel indisponible, rattrapage par liste',e);
    return false;
  }
}
function scheduleFullRefresh(){clearTimeout(fullRefreshTimer);fullRefreshTimer=setTimeout(()=>{if(!authBroken)refresh()},400)}

function detectNewOrders(next){
  if(knownOrderIds===null){knownOrderIds=new Set(next.map(x=>x.id));return}   // premier chargement : on ne notifie pas l'historique
  const fresh=next.filter(x=>!knownOrderIds.has(x.id)).sort((a,b)=>(a.queue_number||0)-(b.queue_number||0));
  next.forEach(x=>knownOrderIds.add(x.id));
  fresh.forEach(notifyNewOrder);
}

/* --- Alertes : bannière, son, titre, notification système ------------------ */
function ensureAlertUi(){
  if(!$('#orderToasts')){const t=document.createElement('div');t.id='orderToasts';t.setAttribute('aria-live','polite');document.body.appendChild(t)}
  const host=document.querySelector('.headerActions');
  if(host&&!$('#notifBtn')){const b=document.createElement('button');b.id='notifBtn';b.type='button';b.onclick=enableAlerts;host.prepend(b);updateNotifBtn()}
}
function alertsOn(){try{return localStorage.getItem(ALERT_KEY)==='1'}catch(_){return false}}
function updateNotifBtn(){
  const b=$('#notifBtn');if(!b)return;
  const perm='Notification' in window?Notification.permission:'unsupported';
  b.textContent=alertsOn()?'🔔 Alertes actives':'🔕 Activer les alertes';
  b.classList.toggle('on',alertsOn());
  b.title=perm==='denied'?'Notifications système bloquées dans les réglages du navigateur — la bannière et le son restent actifs.':'Son + notification à chaque nouvelle commande';
}
function unlockAudio(){try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume()}catch(_){}}
['pointerdown','keydown','touchstart'].forEach(ev=>document.addEventListener(ev,unlockAudio,{once:true,passive:true}));
function beep(){
  try{
    if(!audioCtx||audioCtx.state!=='running')return;
    const t0=audioCtx.currentTime;
    [880,1175,880].forEach((f,i)=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain(),t=t0+i*.2;
      o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.3,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.17);
      o.connect(g);g.connect(audioCtx.destination);o.start(t);o.stop(t+.19)});
  }catch(_){}
}
async function enableAlerts(){
  unlockAudio();setTimeout(beep,50);
  try{localStorage.setItem(ALERT_KEY,'1')}catch(_){}
  if('Notification' in window&&Notification.permission==='default'){try{await Notification.requestPermission()}catch(_){}}
  updateNotifBtn();pushToast('🔔 Alertes activées','Vous serez prévenu à chaque nouvelle commande.');
}
function pushToast(title,body,onClick){
  ensureAlertUi();
  const el=document.createElement('div');el.className='orderToast';
  const b=document.createElement('b');b.textContent=title;const sp=document.createElement('span');sp.textContent=body||'';
  el.append(b,sp);
  el.onclick=()=>{el.remove();onClick&&onClick()};
  $('#orderToasts').prepend(el);
  while($('#orderToasts').children.length>4)$('#orderToasts').lastChild.remove();
  setTimeout(()=>el.remove(),12000);
}
function goToOrders(){document.querySelector('.adminNav button[data-tab="requests"]')?.click();window.focus()}
function notifyNewOrder(x){
  const num='#'+String(x.queue_number||'').padStart(3,'0');
  const total=x.total!=null?new Intl.NumberFormat('fr-FR').format(x.total)+' FCFA':'';
  const body=[x.customer_name,total].filter(Boolean).join(' • ');
  pushToast('🔔 Nouvelle commande '+num,body,goToOrders);
  beep();
  if(document.hidden){
    unseenOrders++;document.title='('+unseenOrders+') Nouvelle commande — '+BASE_TITLE;
    if('Notification' in window&&Notification.permission==='granted'){
      try{const n=new Notification('Nouvelle commande '+num,{body,tag:'order-'+x.id});n.onclick=()=>{window.focus();goToOrders();n.close()}}catch(_){}
    }
  }
}
function clearUnseen(){unseenOrders=0;document.title=BASE_TITLE}

/* --- Flux temps réel ------------------------------------------------------- */
function startAdminStream(){
  if(authBroken)return;
  if(!ADMIN_STORE||!authAdmin?.token){streamOpen=false;updateConn();return}
  adminStream?.close();clearTimeout(streamRetry);
  const u=new URL('/api/admin/stream',location.origin);u.searchParams.set('store',ADMIN_STORE);u.searchParams.set('token',authAdmin.token);
  adminStream=new EventSource(u);
  adminStream.onopen=()=>{streamOpen=true;updateConn();refreshOrders()};   // rattrape tout ce qui a pu arriver pendant une coupure
  adminStream.onmessage=async e=>{
    let evt={};try{evt=JSON.parse(e.data||'{}')}catch(_){}
    if(evt.type==='request_created'){
      // Affichage direct : on récupère uniquement la commande qui vient d'être créée.
      // Le refresh complet reste en secours pour les statistiques/catalogue.
      const ok=await fetchOrderImmediately(evt.request_id);
      if(!ok) await refreshOrders();
    }else if(evt.type==='status_changed'){
      const ok=await fetchOrderImmediately(evt.request_id);
      if(!ok) await refreshOrders();
    }
    scheduleFullRefresh();
  };
  adminStream.onerror=()=>{streamOpen=false;adminStream?.close();if(!authBroken){setConn('Reconnexion au temps réel…');streamRetry=setTimeout(startAdminStream,1500)}};
}
/* Sondage de secours (léger : seulement les commandes) : toutes les 3 s si le flux est coupé, sinon toutes les 15 s. */
function scheduleRefresh(){clearInterval(timer);timer=setInterval(()=>{if(document.hidden||authBroken)return;if(!streamOpen||Date.now()-lastOrdersSync>15000)refreshOrders()},3000)}

(async()=>{
  ensureAlertUi();
  try{
    const c=await resolveAdminAuth();ADMIN_STORE=c.store.id;
    const clientLink=document.querySelector('.headerActions a[href="/"]');if(clientLink)clientLink.href='/boutique/?store='+encodeURIComponent(ADMIN_STORE);
    await refresh();startAdminStream();
  }catch(e){document.body.dataset.adminError=e.message;handleAdminError(e)}
  scheduleRefresh();
})();
document.addEventListener('visibilitychange',()=>{if(document.hidden||authBroken)return;clearUnseen();refreshOrders();if(!streamOpen)startAdminStream()});
window.addEventListener('focus',clearUnseen);
window.addEventListener('online',()=>{if(authBroken)return;startAdminStream();refreshOrders()});
window.addEventListener('offline',updateConn);


let productsCache=[];
let categoriesCache=[];
let productCategoryFilter='';
function closeProductForm(){const el=$('#productFormWrap');if(!el)return;el.classList.remove('is-open');el.hidden=true}
async function openProductForm(x=null){$('#productFormWrap').hidden=false;$('#productFormWrap').classList.add('is-open');$('#productFormTitle').textContent=x?'Modifier le produit':'Ajouter un produit';$('#productId').value=x?.id||'';$('#pname').value=x?.name||'';$('#pprice').value=x?.price??'';await loadCategories(x?.category||'');$('#pstock').value=x?.stock??999;$('#pdescription').value=x?.description||'';$('#pavailable').checked=x?!!x.available:true;$('#pimage').value='';$('#imageHint').textContent=x?.image_data?'Photo déjà enregistrée — choisir un fichier pour la remplacer':'Aucune photo sélectionnée';$('#newCategoryRow').hidden=true;}
function editProduct(id){const x=productsCache.find(p=>p.id===id);if(x)openProductForm(x);}
async function toggleProduct(id,available){await api('/api/products/'+id,{method:'PUT',body:JSON.stringify({available})});refresh()}
async function deleteProduct(id){if(confirm('Supprimer ce produit ?')){await api('/api/products/'+id,{method:'DELETE'});refresh()}}
$('#addProductBtn')?.addEventListener('click',()=>openProductForm());
$('#cancelProduct')?.addEventListener('click',()=>closeProductForm());
$('#productCategoryFilter')?.addEventListener('change',e=>{productCategoryFilter=e.target.value;renderProducts()});
$('#pcategory')?.addEventListener('change',()=>{
  const row=$('#newCategoryRow');
  if($('#pcategory').value==='__new__'){row.hidden=false;$('#newCategoryName').focus();}
  else row.hidden=true;
});
$('#cancelCategoryBtn')?.addEventListener('click',()=>{const row=$('#newCategoryRow');row.hidden=true;$('#newCategoryName').value='';if(categoriesCache.length)$('#pcategory').value=categoriesCache[0].name;});
$('#createCategoryBtn')?.addEventListener('click',async()=>{
  const input=$('#newCategoryName'), name=input.value.trim();
  if(!name)return alert('Entrez un nom de catégorie.');
  try{const r=await api('/api/categories',{method:'POST',body:JSON.stringify({name})});await loadCategories(r.name);$('#pcategory').value=r.name;$('#newCategoryRow').hidden=true;input.value='';}
  catch(e){alert(e.message==='category_exists'?'Cette catégorie existe déjà.':'Impossible de créer la catégorie.');}
});
$('#categoryForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const input=$('#categoryName'), name=input.value.trim();
  if(!name)return;
  try{
    const r=await api('/api/categories',{method:'POST',body:JSON.stringify({name})});
    input.value='';
    await loadCategories(r.name);
    renderCategories();
  }catch(err){
    alert(err.message==='category_exists'?'Cette catégorie existe déjà.':err.message==='invalid_category'?'Nom de catégorie invalide.':'Impossible de créer la catégorie.');
  }
});
$('#pimage')?.addEventListener('change',()=>{const file=$('#pimage').files[0];$('#imageHint').textContent=file?file.name:'Aucune photo sélectionnée';const preview=$('#imagePreview');if(preview){preview.innerHTML='';if(file&&file.type.startsWith('image/')){const img=document.createElement('img');img.alt='Aperçu de la photo';img.src=URL.createObjectURL(file);preview.appendChild(img);}}});$('#productForm')?.addEventListener('submit',async e=>{e.preventDefault();const id=$('#productId').value;const file=$('#pimage').files[0];let image_data=undefined;if(file){if(!file.type.startsWith('image/'))return alert('Veuillez choisir une image.');if(file.size>1_500_000)return alert('Image trop lourde : maximum 1,5 Mo.');image_data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});}const selectedCategory=$('#pcategory').value;if(!selectedCategory||selectedCategory==='__new__')return alert('Choisissez une catégorie ou créez-la avant d’enregistrer le produit.');const data={name:$('#pname').value,price:$('#pprice').value,category:selectedCategory,stock:$('#pstock').value,description:$('#pdescription').value,available:$('#pavailable').checked};if(image_data!==undefined)data.image_data=image_data;await api(id?'/api/products/'+id:'/api/products',{method:id?'PUT':'POST',body:JSON.stringify(data)});closeProductForm();refresh()});

async function readImage(file){if(!file)return '';if(!file.type.startsWith('image/'))throw Error('Image invalide');if(file.size>1_500_000)throw Error('Image trop lourde : maximum 1,5 Mo');return await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
function identityPreview(){const name=$('#iname')?.value||'Nom du restaurant';const slogan=$('#islogan')?.value||'Votre slogan';$('#identityNamePreview').textContent=name;$('#identitySloganPreview').textContent=slogan}
['iname','islogan'].forEach(id=>$('#'+id)?.addEventListener('input',identityPreview));
async function loadIdentity(){try{const c=await api('/api/config');const x=c.identity||{};updateShopIdentityDock(x);$('#iname').value=x.name||'';$('#islogan').value=x.slogan||'';$('#idescription').value=x.description||'';$('#iphone').value=x.phone||'';$('#iaddress').value=x.address||'';$('#ihours').value=x.hours||'';identityPreview();if(x.logo_data){$('#identityLogoPreview').innerHTML=`<img src="${x.logo_data}" alt="Logo du restaurant">`}$('#identitySummary').innerHTML=`<h2>${esc(x.name||'Nom du restaurant')}</h2><p>${esc(x.slogan||'Aucun slogan renseigné')}</p><p class="mut">${esc(x.address||'Adresse non renseignée')} · ${esc(x.phone||'Téléphone non renseigné')}</p>`;if(!x.name){$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Compléter les informations'}else{$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Modifier les informations'}}catch(e){console.error(e)}}
$('#ilogo')?.addEventListener('change',()=>$('#ilogoHint').textContent=$('#ilogo').files[0]?.name||'Aucun logo sélectionné');$('#editIdentityBtn')?.addEventListener('click',()=>{const el=$('#identityForm');el.hidden=false;el.classList.add('is-open');requestAnimationFrame(()=>el.scrollIntoView({behavior:'smooth',block:'start'}));});$('#cancelIdentityBtn')?.addEventListener('click',()=>{const el=$('#identityForm');el.classList.remove('is-open');el.hidden=true;});
$('#identityForm')?.addEventListener('submit',async e=>{e.preventDefault();try{const logo=await readImage($('#ilogo').files[0]);const cover='';const old=await api('/api/config');const prev=old.identity||{};await api('/api/identity',{method:'PUT',body:JSON.stringify({name:$('#iname').value,slogan:$('#islogan').value,description:$('#idescription').value,phone:$('#iphone').value,address:$('#iaddress').value,hours:$('#ihours').value,logo_data:logo||prev.logo_data||'',cover_data:cover||prev.cover_data||''})});alert('Identité enregistrée');$('#identityForm').classList.remove('is-open');$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Modifier les informations';loadIdentity();}catch(err){alert(err.message||'Erreur')}});loadIdentity();


bindShopIdentityDock();

if (typeof identity !== 'undefined') updateShopIdentityDock(identity);

function makeFloatingIdentityMovable(button, storageKey){
  if(!button || button.dataset.dragBound) return;
  button.dataset.dragBound='1';
  button.style.touchAction='none';
  let dragging=false, moved=false, startX=0, startY=0, originLeft=0, originTop=0;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem(storageKey)||'null')}catch(_){return null}})();
  const apply=(left,top)=>{
    const maxX=Math.max(0,window.innerWidth-button.offsetWidth);
    const maxY=Math.max(0,window.innerHeight-button.offsetHeight);
    left=Math.max(0,Math.min(maxX,left)); top=Math.max(0,Math.min(maxY,top));
    button.style.left=left+'px'; button.style.top=top+'px';
    button.style.right='auto'; button.style.bottom='auto';
    try{localStorage.setItem(storageKey,JSON.stringify({left,top}))}catch(_){}
  };
  if(saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)){
    requestAnimationFrame(()=>apply(saved.left,saved.top));
  }
  const point=(e)=>({x:e.clientX,y:e.clientY});
  button.addEventListener('pointerdown',e=>{
    if(e.button!==undefined && e.button!==0) return;
    const p=point(e), r=button.getBoundingClientRect();
    dragging=true; moved=false; startX=p.x; startY=p.y; originLeft=r.left; originTop=r.top;
    button.setPointerCapture?.(e.pointerId);
  });
  button.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const p=point(e), dx=p.x-startX, dy=p.y-startY;
    if(Math.abs(dx)>4 || Math.abs(dy)>4)moved=true;
    if(moved)apply(originLeft+dx,originTop+dy);
  });
  const end=e=>{
    if(!dragging)return;
    dragging=false;
    button.releasePointerCapture?.(e.pointerId);
    if(moved){
      button.dataset.suppressClick='1';
      setTimeout(()=>{button.dataset.suppressClick='';},0);
    }
  };
  button.addEventListener('pointerup',end);
  button.addEventListener('pointercancel',end);
  button.addEventListener('click',e=>{
    if(button.dataset.suppressClick==='1'){e.preventDefault();e.stopImmediatePropagation();}
  },true);
  window.addEventListener('resize',()=>{
    const r=button.getBoundingClientRect();
    if(r.width)apply(r.left,r.top);
  });
}

makeFloatingIdentityMovable(document.getElementById('shopIdentityDock'),'nzela_admin_identity_position');

/* --- Messagerie boutique en temps réel ----------------------------------- */
let adminConversations=[],adminActiveConversation=null,adminMessageStream=null;
async function loadAdminMessages(){if(!authAdmin?.token)return;try{const d=await api('/api/messages/conversations');adminConversations=(d.items||[]).filter(c=>c.kind==='store'&&c.store_id===ADMIN_STORE);if(!adminConversations.length){$('#adminConversationList').innerHTML='<p class="mut">Aucun message reçu.</p>';}else{$('#adminConversationList').innerHTML=adminConversations.map(c=>`<button class="adminConversationItem ${adminActiveConversation?.id===c.id?'active':''}" data-cid="${esc(c.id)}"><b>${esc(c.other?.name||c.other?.email||'Client')}</b><small>${esc(c.last_body||'Aucun message')}</small></button>`).join('')}}catch(e){if(e.message!=='authentication_required')console.error(e)}}
async function openAdminConversation(cid){const c=adminConversations.find(x=>x.id===cid);if(!c)return;adminActiveConversation=c;document.querySelectorAll('.adminConversationItem').forEach(x=>x.classList.toggle('active',x.dataset.cid===cid));$('#adminChatEmpty').hidden=true;$('#adminChatActive').hidden=false;$('#adminChatTitle').textContent=c.other?.name||'Client';try{await api('/api/messages/conversations/'+encodeURIComponent(cid)+'/read',{method:'PUT'});const d=await api('/api/messages/conversations/'+encodeURIComponent(cid)+'/messages');$('#adminMessageList').innerHTML=(d.items||[]).map(m=>`<div class="adminMessageBubble ${m.sender_id===authAdmin.account.id?'mine':'theirs'}"><div>${esc(m.body)}</div><small>${esc(m.created_at||'')}${m.sender_id===authAdmin.account.id&&m.read_at?' · Lu':''}</small></div>`).join('')||'<p class="mut">Aucun message.</p>';const box=$('#adminMessageList');box.scrollTop=box.scrollHeight}catch(e){console.error(e)}}
function startAdminMessageStream(){if(adminMessageStream||!authAdmin?.token)return;const u=new URL('/api/messages/stream',location.origin);u.searchParams.set('token',authAdmin.token);adminMessageStream=new EventSource(u);adminMessageStream.onmessage=async e=>{try{const evt=JSON.parse(e.data);if(evt.type==='message_created'){await loadAdminMessages();if(adminActiveConversation?.id===evt.conversation_id)await openAdminConversation(evt.conversation_id)}}catch(_){} };adminMessageStream.onerror=()=>{adminMessageStream?.close();adminMessageStream=null;setTimeout(startAdminMessageStream,2500)}}
$('#adminConversationList')?.addEventListener('click',e=>{const b=e.target.closest('.adminConversationItem');if(b)openAdminConversation(b.dataset.cid)});
$('#adminMessageForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!adminActiveConversation)return;const input=$('#adminMessageInput'),body=input.value.trim();if(!body)return;const btn=e.submitter;btn.disabled=true;try{await api('/api/messages/conversations/'+encodeURIComponent(adminActiveConversation.id)+'/messages',{method:'POST',body:JSON.stringify({body})});input.value='';await openAdminConversation(adminActiveConversation.id);await loadAdminMessages()}catch(err){alert(err.message)}finally{btn.disabled=false}});
const _oldAdminRefresh=refresh;refresh=async function(){await _oldAdminRefresh();await loadAdminMessages();startAdminMessageStream()};
setTimeout(()=>{loadAdminMessages();startAdminMessageStream()},300);
