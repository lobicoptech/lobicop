
function updateClientShopIdentity(identity){
  const d=identity||{};
  const name=d.name||'Ma boutique';
  const logo=safeImg(d.logo||d.logo_data||d.image_data);
  const cover=safeImg(d.cover_data);
  const text=(id,v,fallback='')=>{const e=document.getElementById(id);if(e)e.textContent=v||fallback;};
  const sector=String(d.sector_label||d.sector||d.activity||enterprise?.sector||'');
  const place=[d.district,d.city].filter(Boolean).join(', ');
  text('clientShopName',name); text('clientCardName',name); text('shopBarTitle',name,'Boutique');
  text('clientCardSlogan',d.slogan||'');
  text('clientCardSector',[sector?sector.charAt(0).toUpperCase()+sector.slice(1):'',place].filter(Boolean).join(' · '));
  text('clientCardContact',d.contact||d.phone||d.telephone,'—');
  text('clientCardAddress',d.address,'—');
  text('clientCardHours',d.hours,'—');
  text('clientCardDescription',d.description||'');
  const setImg=(id,src)=>{const e=document.getElementById(id);if(!e)return;if(src){e.src=src;e.hidden=false;}else{e.removeAttribute('src');e.hidden=true;}};
  setImg('clientShopLogo',logo); setImg('clientCardLogo',logo); setImg('clientCardCover',cover);
  const logoIcon=document.getElementById('clientCardLogoIcon'); if(logoIcon)logoIcon.hidden=!!logo;
}
document.getElementById('contactStoreBtn')?.addEventListener('click',async()=>{if(!auth){alert('Connectez-vous pour contacter cette boutique.');return}try{const d=await api('/api/messages/conversations',{method:'POST',body:JSON.stringify({store_id:BOUTIQUE_STORE})});location.href='/?messages=1&conversation='+encodeURIComponent(d.conversation.id)}catch(e){alert(e.message)}});
function bindClientShopIdentity(){
  const b=document.getElementById('clientShopIdentity'), c=document.getElementById('clientShopCard'), x=document.getElementById('closeClientShopCard');
  if(!b||!c||b.dataset.bound)return; b.dataset.bound='1';
  const close=()=>{c.hidden=true;b.setAttribute('aria-expanded','false');};
  b.addEventListener('click',()=>{if(c.hidden){c.hidden=false;b.setAttribute('aria-expanded','true');}else close();});
  x?.addEventListener('click',close);
}
function bindAppIdentity(){
  const b=document.getElementById('appIdentity'), c=document.getElementById('appIdentityCard'), x=document.getElementById('closeAppIdentity');
  if(!b||!c||b.dataset.bound)return; b.dataset.bound='1';
  const close=()=>{c.hidden=true;b.setAttribute('aria-expanded','false');};
  b.addEventListener('click',()=>{if(c.hidden){c.hidden=false;b.setAttribute('aria-expanded','true');}else close();});
  x?.addEventListener('click',close);
}

const $=s=>document.querySelector(s);let auth=null;try{auth=JSON.parse(localStorage.getItem('lobicop_auth')||'null')}catch(_){auth=null}let products=[],highlights=[],cart=new Map(),last=null,currentProduct=null,previewOpen=false,enterprise={sector:'',name:'LobiCop'};
const THEME_KEY='nzela_theme', THEME_SCALE_KEY='nzela_theme_scale';
function storageGet(key,fallback=null){try{const v=localStorage.getItem(key);return v===null?fallback:v}catch(_){return fallback}}
function storageSet(key,value){try{localStorage.setItem(key,value)}catch(_){} }
function applyThemeScale(value){const scale=Math.max(0,Math.min(100,Number(value)||0));document.body.style.setProperty('--theme-scale',scale+'%');const el=$('#themeScale'),label=$('#themeScaleLabel');if(el)el.value=String(scale);if(label)label.textContent=String(scale)+'%';storageSet(THEME_SCALE_KEY,String(scale));}
function applyTheme(mode,scale){document.body.classList.toggle('light',mode==='light');storageSet(THEME_KEY,mode);applyThemeScale(scale ?? Number(storageGet(THEME_SCALE_KEY,50)));const button=$('#themeToggle');if(button){button.textContent=mode==='light'?'☾':'☼';button.title=mode==='light'?'Passer en mode sombre':'Passer en mode clair'}}
function theme(){const next=document.body.classList.contains('light')?'dark':'light';applyTheme(next,Number(storageGet(THEME_SCALE_KEY,50)))}
function initTheme(){const mode=storageGet(THEME_KEY,'dark')==='light'?'light':'dark';applyTheme(mode,Number(storageGet(THEME_SCALE_KEY,50)));if(!initTheme.bound){initTheme.bound=true;$('#themeToggle')?.addEventListener('click',theme);$('#themeScale')?.addEventListener('input',e=>applyThemeScale(e.target.value));}}

const CART_COLLAPSED_KEY='nzela_cart_collapsed';
function setCartCollapsed(collapsed){const panel=$('#cart');if(!panel)return;panel.classList.toggle('collapsed',collapsed);storageSet(CART_COLLAPSED_KEY,collapsed?'1':'0');const btn=$('#cartCollapse');if(btn){btn.textContent=collapsed?'+':'−';btn.title=collapsed?'Agrandir':'Réduire';btn.setAttribute('aria-label',btn.title)}}
function initCartCollapse(){setCartCollapsed(storageGet(CART_COLLAPSED_KEY,'0')==='1');$('#cartCollapse')?.addEventListener('click',e=>{e.stopPropagation();setCartCollapsed(!$('#cart').classList.contains('collapsed'))})}
const HISTORY_KEY='nzela_order_history';
const money=n=>new Intl.NumberFormat('fr-FR').format(n)+' FCFA';
function getTrackedOrders(){try{return JSON.parse(storageGet(HISTORY_KEY,'[]')||'[]').slice(0,20)}catch{return[]}}
function trackOrder(order){const list=getTrackedOrders().filter(x=>x.request_id!==order.request_id);list.unshift({request_id:order.request_id,queue_number:order.queue_number,total:order.total,created_at:new Date().toISOString()});storageSet(HISTORY_KEY,JSON.stringify(list.slice(0,20)));startOrderStream()}
function clearInvalidAuth(){
  auth=null; storageSet('lobicop_auth','');
  if(accountStream){accountStream.close();accountStream=null;}
  clearInterval(accountHistoryTimer);
}
async function refreshTrackedOrders(){
  let rows=[];
  let accountHistoryOk=false;
  if(auth?.token){
    try{
      const mine=await api('/api/my/requests');
      accountHistoryOk=true;
      rows=(mine.items||[]).map(d=>trackCard(d));
    }catch(_){
      accountHistoryOk=false;
    }
  }
  if(!rows.length && !accountHistoryOk){
    const list=getTrackedOrders();
    if(!list.length){$('#history').innerHTML='<p class="empty">Aucune demande sur cet appareil.</p>';return}
    const results=await Promise.all(list.map(async x=>{try{return {x,d:await api('/api/requests/'+encodeURIComponent(x.request_id))}}catch{return {x,d:null}}}));
    const valid=results.filter(({d})=>d);
    const stale=results.filter(({d})=>!d).map(({x})=>x.request_id);
    if(stale.length){storageSet(HISTORY_KEY,JSON.stringify(getTrackedOrders().filter(x=>!stale.includes(x.request_id)).slice(0,20)));}
    rows=valid.map(({x,d})=>trackCard(d,x.created_at));
  }
  $('#history').innerHTML=rows.join('')||'<p class="empty">Aucune demande.</p>';
}

function stopOrderStream(){if(orderStream){orderStream.close();orderStream=null}}
function startOrderStream(){
  stopOrderStream();
  const ids=getTrackedOrders().map(x=>x.request_id);
  if(!ids.length)return;
  const u=new URL('/api/events/stream',location.origin);u.searchParams.set('store',BOUTIQUE_STORE);u.searchParams.set('request_ids',ids.join(','));
  orderStream=new EventSource(u);
  orderStream.onmessage=e=>{try{const evt=JSON.parse(e.data);if(last?.request_id===evt.request_id&&evt.status)$('#status').textContent=({pending:'En attente',preparing:'En préparation',ready:'Prête',completed:'Terminée',cancelled:'Annulée'})[evt.status]||evt.status}catch(_){} refreshTrackedOrders();};
  orderStream.onerror=()=>{if(orderStream)orderStream.close();setTimeout(startOrderStream,3000)};
}
async function startAccountHistorySync(){
  clearInterval(accountHistoryTimer);
  if(accountStream){accountStream.close();accountStream=null;}
  if(!auth?.token)return;
  try{ await api('/api/auth/me'); }catch(_){ clearInvalidAuth(); return; }
  const u=new URL('/api/my/stream',location.origin);u.searchParams.set('token',auth.token);
  accountStream=new EventSource(u);
  accountStream.onmessage=e=>{try{const evt=JSON.parse(e.data);if(last?.request_id===evt.request_id&&evt.status){$('#status').textContent=({pending:'En attente',preparing:'En préparation',ready:'Prête',completed:'Terminée',cancelled:'Annulée'})[evt.status]||evt.status}if(evt.type==='announcement_targeted')refreshAnnouncements()}catch(_){} refreshTrackedOrders()};
  accountStream.onerror=()=>{accountStream?.close();accountStream=null;accountHistoryTimer=setTimeout(startAccountHistorySync,5000)};
}


const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const BOUTIQUE_STORE=new URLSearchParams(location.search).get('store')||'';

/* =====================================================================
   LobiCop 0.2.18 — les 7 cartes (réglages, icônes, favoris, composants)
   UI.newDays : combien de jours le badge « Nouveau » reste affiché.
   Aucun point de statut, aucun bleu : les couleurs viennent du CSS du projet.
   ===================================================================== */
const UI={newDays:7,favKey:'lobicop_favs'};
const ICON={
  heart:'<path d="M12 20s-7-4.4-7-9.6A4 4 0 0 1 12 7.8a4 4 0 0 1 7 2.6C19 15.6 12 20 12 20Z"/>',
  back:'<path d="M15 5l-7 7 7 7"/>',
  share:'<path d="M12 3v12M8 7l4-4 4 4M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7"/>',
  cart:'<path d="M3 4h2l2.2 10.2a1 1 0 0 0 1 .8h8.6a1 1 0 0 0 1-.8L19.5 8H6"/><circle cx="9" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/>',
  arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  box:'<path d="M4 8l8-4 8 4v8l-8 4-8-4V8Z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
  bag:'<path d="M6 8h12l1 12H5L6 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  flag:'<path d="M6 21V4"/><path d="M6 5h11l-2 4 2 4H6"/>',
  minus:'<path d="M5 12h14"/>',
  plus:'<path d="M12 5v14M5 12h14"/>'
};
function ic(n){return `<span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${ICON[n]||''}</svg></span>`}
function safeImg(s){return typeof s==='string'&&s.startsWith('data:image/')?s:''}
function favSet(){try{return new Set(JSON.parse(storageGet(UI.favKey,'[]')||'[]'))}catch(_){return new Set()}}
function favId(id){return (BOUTIQUE_STORE||'-')+':'+id}
function isFav(id){return favSet().has(favId(id))}
function toggleFav(id){const s=favSet(),k=favId(id),on=!s.has(k);if(on)s.add(k);else s.delete(k);storageSet(UI.favKey,JSON.stringify([...s]));return on}
function heartBtn(id,cls=''){const on=isFav(id);return `<button type="button" class="heartBtn ${cls} ${on?'fav':''}" data-fav="${escAttr(id)}" aria-pressed="${on}" aria-label="Favori">${ic('heart')}</button>`}
function syncFavButtons(id,on){document.querySelectorAll('[data-fav]').forEach(b=>{if(b.dataset.fav===id){b.classList.toggle('fav',on);b.setAttribute('aria-pressed',String(on))}})}
function toast(msg){const t=document.createElement('div');t.className='lbToast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),1900)}
function isNewProduct(p){const t=Date.parse(p?.created_at||'');return Number.isFinite(t)&&Date.now()-t<UI.newDays*864e5}
function stockMarkup(p){const ok=p?.available!==false;return `<div class="stock ${ok?'isOk':'isOut'}">${ok?'Disponible':'Indisponible'}</div>`}
function maxQty(p){return Math.max(1,Number(p?.stock)||1)}
function cartAttention(){const c=$('#cart');if(c&&!c.classList.contains('collapsed')){c.classList.add('cartAttention');setTimeout(()=>c.classList.remove('cartAttention'),500)}}
function orderThumb(p){const src=safeImg(p?.image_data);return src?`<img src="${src}" alt="" loading="lazy">`:ic('box')}

/* Cartes 1 et 6 — carte produit : variante « voir » (bouton Voir) ou « shop » (bouton panier) */
function productCard(p,variant,i,badgeText){
  const k=opKind(p),info=opSpec(k),ok=p.available!==false,shop=variant==='shop',id=escAttr(p.id);
  const label=badgeText||(ok&&isNewProduct(p)?'Nouveau':'');
  const action=shop
    ?`<button class="quickAdd" data-quick="${id}" type="button" aria-label="Ajouter ${escAttr(p.name)}" ${ok?'':'disabled'}>${ic('cart')}</button>`
    :`<button class="presentationView" data-view="${id}" type="button">Voir ${ic('arrow')}</button>`;
  return `<article class="product productPresentation serviceProduct ${shop?'shopVariant':''} ${ok?'':'off'}" data-product="${id}" data-category="${escAttr(p.category)}" style="--i:${i||0}"><div class="presentationVisual">${label?`<span class="presentationBadge">${esc(label)}</span>`:''}${heartBtn(p.id,'roundBtn')}<button class="imageButton serviceVisual" data-view="${id}" type="button" aria-label="Voir ${escAttr(p.name)}">${productImageMarkup(p,info,'productImage')}</button></div><div class="presentationBody"><h3>${esc(p.name)}</h3><p class="presentationMeta">${esc(p.description||p.category||'')}</p><div class="presentationBottom"><div><div class="price operationPrice">${money(p.price)}</div>${stockMarkup(p)}</div>${action}</div></div></article>`;
}
function quickAdd(p){
  if(p.available===false)return;
  const spec=opSpec(opKind(p));
  if(quantityMode(p)==='multiple'&&!(spec.fields||[]).length&&opKind(p)!=='transfer'){add(p.id);toast(p.name+' ajouté');return}
  openProduct(p);
}

/* Carte 4 — suivi de commande */
const TRACK={
  steps:['pending','preparing','ready','completed'],
  label:{pending:'Confirmée',preparing:'Préparée',ready:'Prête',completed:'Terminée'},
  icon:{pending:'check',preparing:'box',ready:'bag',completed:'flag'},
  note:{
    pending:['Votre commande a été reçue.','Le vendeur va la prendre en charge.'],
    preparing:['Votre commande est en cours de préparation.','Le vendeur prépare votre commande.'],
    ready:['Votre commande est prête.','Le vendeur a terminé la préparation.'],
    completed:['Votre commande est terminée.','Merci de votre confiance.'],
    cancelled:['Cette commande a été annulée.','Contactez le vendeur pour en savoir plus.']
  }
};
function fmtDate(iso){const t=new Date(iso);return isNaN(t)?String(iso||''):t.toLocaleString('fr-FR',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'})}
function trackCard(d,fallbackDate){
  const st=d.status||'pending',cancelled=st==='cancelled',idx=Math.max(0,TRACK.steps.indexOf(st));
  const chip=cancelled?['cancelled','Annulée']:st==='completed'?['done','Terminée']:['','En cours'];
  const steps=TRACK.steps.map((s,i)=>`<li class="trackStep ${!cancelled&&i<idx?'done':''} ${!cancelled&&i===idx?'now':''}"><span class="stepIcon">${ic(TRACK.icon[s])}</span><small>${TRACK.label[s]}</small></li>`).join('');
  const note=TRACK.note[st]||TRACK.note.pending;
  const items=(d.items||[]).map(it=>{const p=products.find(x=>x.name===it.name);const price=it.unit_price!=null?it.unit_price:p?.price;return `<div class="trackItem"><span class="thumb">${p?orderThumb(p):ic('box')}</span><div><b>${esc(it.name)}</b><small>${price!=null?money(price)+' · ':''}Qté : ${esc(it.quantity)}</small></div></div>`}).join('');
  return `<article class="trackCard"><div class="trackHead"><span class="trackChip ${chip[0]}">${chip[1]}</span><b>Commande #${String(d.queue_number).padStart(3,'0')}</b><small>${esc(fmtDate(d.created_at||fallbackDate))}</small></div><ol class="trackSteps">${steps}</ol><div class="trackNote"><span class="noteIcon">${ic('box')}</span><p>${note[0]}<small>${note[1]}</small></p></div><h4>Détails de la commande</h4>${items}<div class="trackExtra"><span>Total</span><b>${money(d.total)}</b></div><button class="trackToggle" type="button" data-track-toggle>Voir les détails</button></article>`;
}

let orderStream=null;
let accountStream=null;
let activeOrderIdempotencyKey=null;
function newOrderIdempotencyKey(){return 'lobicop-'+(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(16).slice(2));}
let accountHistoryTimer=null;
function withStoreQuery(path){if(!BOUTIQUE_STORE || !path.startsWith('/api/')) return path; const u=new URL(path,location.origin); u.searchParams.set('store',BOUTIQUE_STORE); return u.pathname+u.search}
async function api(p,o={}){
  const target=withStoreQuery(p);
  const headers={'Content-Type':'application/json',...(o.headers||{})};
  if(auth?.token)headers.Authorization='Bearer '+auth.token;
  const r=await fetch(target,{cache:'no-store',...o,headers});
  let d=null; try{d=await r.json()}catch(_){d={}}
  if(r.status===401 && auth?.token && !String(p).startsWith('/api/auth/login') && !String(p).startsWith('/api/auth/signup')) clearInvalidAuth();
  if(!r.ok)throw Error(d.error||'Erreur réseau');
  return d;
}
function pulse(el){el?.classList.remove('pulse');if(el){void el.offsetWidth;el.classList.add('pulse')}}
let catalog={operations:[]}; const kindInfo={};
function opKind(p){return p?.operation_kind||catalog.operations.find(o=>o.id===p?.id)?.kind||''}
function opSpec(kind){return catalog.operations.find(o=>o.kind===kind)||{kind,name:kind,icon:'',description:'',fields:[]}}
function isRestaurant(){return enterprise.sector==='restaurant'}
function quantityMode(p){return opSpec(opKind(p)).quantity_mode||'single'}
function escAttr(s){return esc(s).replace(/`/g,'&#096;')}
function productImageMarkup(p,info,cls='productImage'){const src=typeof p?.image_data==='string'&&p.image_data.startsWith('data:image/')?p.image_data:'';return src?`<img class="${cls}" src="${src}" alt="${esc(p.name)}" loading="lazy">`:`<span class="placeholderImage ${cls}" aria-label="Aucune photo">${info.icon||ic('box')}</span>`;}

function renderHighlights(){
  if(!$('#highlightGrid'))return;
  $('#highlightGrid').innerHTML=highlights.length?highlights.map((h,i)=>{
    const p=products.find(x=>x.id===h.product_id);
    if(p)return productCard(p,'shop',i,h.subtitle||'');
    return `<article class="highlight serviceHighlight" style="--i:${i}"><span class="badge">${esc(h.subtitle||'Opération')}</span><h3>${esc(h.title)}</h3><p>${esc(h.description||'')}</p><button class="actionBtn" data-pid="${esc(h.product_id||'')}">${esc(h.cta||'Choisir')} <span>→</span></button></article>`;
  }).join(''):'<div class="empty">Aucune opération mise en avant.</div>'
}
function render(){
  const q=String($('#search').value||'').trim().toLowerCase(),c=$('#cat').value;
  const list=products.filter(p=>{const name=String(p.name||''),category=String(p.category||''),description=String(p.description||'');return (!q||name.toLowerCase().includes(q)||category.toLowerCase().includes(q)||description.toLowerCase().includes(q))&&(!c||category===c)});
  $('#grid').innerHTML=list.map((p,i)=>productCard(p,'voir',i)).join('')||'<p class="empty">Aucun article trouvé.</p>';
  renderCart();
}
let renderFrame=0;function scheduleRender(){if(renderFrame)return;renderFrame=requestAnimationFrame(()=>{renderFrame=0;render()})}
function onCardClick(e){
  const fav=e.target.closest('[data-fav]');
  if(fav){e.stopPropagation();const on=toggleFav(fav.dataset.fav);syncFavButtons(fav.dataset.fav,on);return}
  const quick=e.target.closest('[data-quick]');
  if(quick){e.stopPropagation();const p=products.find(x=>x.id===quick.dataset.quick);if(p){pulse(quick);quickAdd(p)}return}
  const view=e.target.closest('[data-view]');
  if(view){e.stopPropagation();openProduct(products.find(x=>x.id===view.dataset.view));return}
  const card=e.target.closest('.product');
  if(card&&!e.target.closest('button'))openProduct(products.find(x=>x.id===card.dataset.product));
}
function bindCatalogDelegation(){
  $('#grid')?.addEventListener('click',onCardClick);
  $('#highlightGrid')?.addEventListener('click',e=>{
    const b=e.target.closest('.actionBtn');
    if(b){pulse(b);const p=products.find(x=>x.id===b.dataset.pid);if(p)openProduct(p);return}
    onCardClick(e);
  });
}
function add(id){
  if(!id)return;
  const p=products.find(x=>x.id===id);if(!p)return;
  if(quantityMode(p)==='multiple'){const n=(cart.get(id)||0)+1;if(n>maxQty(p)){toast('Stock maximum atteint');return}cart.set(id,n)}
  else if(cart.has(id))cart.delete(id);
  else cart.set(id,1);
  render();cartAttention();
}
function change(id,d){const n=(cart.get(id)||0)+d;if(n<=0)cart.delete(id);else cart.set(id,n);render()}
function renderCart(){let html='',total=0;for(const [id,qty] of cart){const p=products.find(x=>x.id===id);if(!p)continue;total+=Number(p.price||0)*qty;html+=`<div class="cartRow"><span>${esc(p.name)} × ${qty}</span><button onclick="change('${id}',-1)" aria-label="Retirer">×</button></div>`}const cartN=[...cart.values()].reduce((a,b)=>a+b,0);$('#count').textContent=cartN;const sc=$('#shopCartCount');if(sc){sc.textContent=cartN;sc.classList.toggle('hidden',!cartN)}$('#total').textContent=cart.size?money(total):'À préciser';$('#items').className=html?'cartitems':'empty';$('#items').innerHTML=html||'Choisissez un article pour commencer.';$('#order').disabled=!cart.size}
function closeProductPreview(){if(!previewOpen)return;$('#productModal')?.classList.add('hidden');$('#productWorkspace').innerHTML='';previewOpen=false;document.removeEventListener('keydown',handleEscape)}
function handleEscape(e){if(e.key==='Escape')closeProductPreview()}
function showPage(page){document.body.dataset.page=page;document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$('#page-'+page).classList.add('active');document.querySelectorAll('.navItem').forEach(x=>x.classList.toggle('active',x.dataset.page===page));window.scrollTo(0,0)}document.querySelectorAll('.navItem').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
initTheme();
const adminLink=document.querySelector('.adminLink');if(adminLink&&BOUTIQUE_STORE)adminLink.href='/admin.html?store='+encodeURIComponent(BOUTIQUE_STORE);
startOrderStream();startAccountHistorySync();
function fieldFor(kind,index){const spec=opSpec(kind),base=`data-op-index="${index}"`;let fields=spec.fields.map(f=>{if(f.type==='select')return `<label class="operationField"><span>${esc(f.label||f.name)}</span><select ${base} data-field="${escAttr(f.name)}" ${f.required?'required':''}>${(f.options||[]).map(o=>`<option value="${escAttr(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>`;return `<label class="operationField"><span>${esc(f.label||f.name)}</span><input ${base} data-field="${escAttr(f.name)}" type="${f.type||'text'}" ${f.min!=null?`min="${f.min}"`:''} ${f.required?'required':''} placeholder="${escAttr(f.label||f.name)}"></label>`}).join('');return `<div class="operationFormCard"><div class="operationFormHead"><b>${spec.icon?esc(spec.icon)+' ':''}${esc(spec.name)}</b><span>Opération ${index+1}</span></div>${fields}</div>`}
function operationFormMarkup(p){
  const k=opKind(p),spec=opSpec(k),dis=p.available===false?'disabled':'';
  if(k==='transfer')return `<form class="cabinTransferForm openOrder" data-transfer-form><div class="toolSectionLabel">DEMANDE DE TRANSFERT</div><label class="operationField"><span>Numéro de téléphone</span><input data-field="phone" type="tel" inputmode="tel" autocomplete="tel" required placeholder="Numéro de téléphone"></label><label class="operationField"><span>Nom</span><input data-field="recipient_name" type="text" autocomplete="name" required placeholder="Nom"></label><label class="operationField"><span>Montant à envoyer (FCFA)</span><input data-field="amount" type="number" inputmode="numeric" min="1" required placeholder="Montant à envoyer (FCFA)"></label><button class="primary transferSubmit" type="submit" ${dis}>Envoyer la demande ${ic('arrow')}</button></form>`;
  if(quantityMode(p)==='multiple'){
    const qty=Math.min(cart.get(p.id)||1,maxQty(p));
    return `<div class="openOrder"><div class="openQtyRow"><span>Quantité</span><div class="qtyStepper" aria-label="Quantité"><button type="button" data-modal-qty="-" aria-label="Diminuer">${ic('minus')}</button><b data-modal-qty-value>${qty}</b><button type="button" data-modal-qty="+" aria-label="Augmenter">${ic('plus')}</button></div></div><button class="primary previewAction" data-add="${escAttr(p.id)}" type="button" ${dis}>${ic('cart')} Ajouter au panier</button></div>`;
  }
  const fields=(spec.fields||[]).length?`<div class="toolSectionLabel">PARAMÈTRES</div>${fieldFor(k,0)}`:'';
  return `<div class="openOrder">${fields}<button class="primary previewAction" data-add="${escAttr(p.id)}" type="button" ${dis}>Faire la demande ${ic('arrow')}</button></div>`;
}
function openProduct(p){
  if(!p)return;
  const modal=$('#productModal'),workspace=$('#productWorkspace'),k=opKind(p),info=opSpec(k);
  if(!modal||!workspace)return;
  const image=productImageMarkup(p,info,'previewImage');
  workspace.innerHTML=`<section class="productPreview visible" role="dialog" aria-modal="true" aria-label="${escAttr(p.name)}">
    <div class="previewCard cardOpen">
      <div class="openHero">${image}<div class="openBar"><button type="button" class="roundBtn productPreviewClose" aria-label="Retour" title="Retour">${ic('back')}</button><div class="openBarRight">${heartBtn(p.id,'roundBtn')}<button type="button" class="roundBtn" data-share aria-label="Partager" title="Partager">${ic('share')}</button></div></div></div>
      <div class="openBody">
        <span class="openCategory">${esc(p.category||info.name||'Service')}</span>
        <h2>${esc(p.name)}</h2>
        <div class="openPrice">${money(p.price)}</div>
        ${stockMarkup(p)}
        <p class="openDesc">${esc(p.description||info.help||'')}</p>
        ${operationFormMarkup(p)}
      </div>
    </div>
  </section>`;
  modal.classList.remove('hidden');
  previewOpen=true;
  document.addEventListener('keydown',handleEscape);
  const root=workspace.querySelector('.productPreview');
  root.onclick=closeProductPreview;
  workspace.querySelector('.previewCard').onclick=e=>e.stopPropagation();
  workspace.querySelector('.productPreviewClose')?.addEventListener('click',e=>{e.stopPropagation();closeProductPreview()});
  workspace.querySelector('[data-fav]')?.addEventListener('click',e=>{e.stopPropagation();const on=toggleFav(p.id);syncFavButtons(p.id,on)});
  workspace.querySelector('[data-share]')?.addEventListener('click',async e=>{
    e.stopPropagation();
    const data={title:p.name,text:p.name+' — '+money(p.price),url:location.href};
    try{
      if(navigator.share)await navigator.share(data);
      else if(navigator.clipboard){await navigator.clipboard.writeText(location.href);toast('Lien copié')}
    }catch(_){}
  });
  const transferForm=workspace.querySelector('[data-transfer-form]');
  if(transferForm){transferForm.onsubmit=async e=>{e.preventDefault();const values={};transferForm.querySelectorAll('[data-field]').forEach(el=>values[el.dataset.field]=el.value.trim());const submit=transferForm.querySelector('button[type="submit"]');if(submit)submit.disabled=true;const transferKey=newOrderIdempotencyKey();try{const d=await api('/api/requests',{method:'POST',headers:{'X-Idempotency-Key':transferKey},body:JSON.stringify({customer_name:values.recipient_name,customer_phone:values.phone,items:[{product_id:p.id,quantity:1,kind:'transfer',details:values}]})});last=d;trackOrder(d);refreshTrackedOrders();cart.delete(p.id);renderCart();closeProductPreview();$('#qn').textContent='#'+String(d.queue_number).padStart(3,'0');$('#status').textContent='En attente';$('#done').classList.remove('hidden')}catch(err){alert(err.message);if(submit)submit.disabled=false}};return}
  const qtyValue=workspace.querySelector('[data-modal-qty-value]');
  if(qtyValue){
    const minus=workspace.querySelector('[data-modal-qty="-"]'),plus=workspace.querySelector('[data-modal-qty="+"]'),max=maxQty(p);
    let q=Math.min(cart.get(p.id)||1,max);
    const setQ=n=>{q=Math.max(1,Math.min(max,n));qtyValue.textContent=q;minus.disabled=q<=1;plus.disabled=q>=max};
    minus.onclick=()=>setQ(q-1);plus.onclick=()=>setQ(q+1);setQ(q);
    workspace.querySelector('[data-add]').onclick=e=>{e.stopPropagation();cart.set(p.id,q);render();closeProductPreview();cartAttention();toast('Ajouté au panier')};
    return;
  }
  const addButton=workspace.querySelector('[data-add]');
  if(addButton)addButton.onclick=e=>{e.stopPropagation();const values={};workspace.querySelectorAll('[data-op-index="0"][data-field]').forEach(el=>values[el.dataset.field]=el.value);window._directOperationDraft={product_id:p.id,kind:k,details:values};cart.set(p.id,1);renderCart();closeProductPreview();openRequestForm(window._directOperationDraft)};
}
function renderOrderItems(){
  const arr=[...cart].map(([id,q])=>({p:products.find(x=>x.id===id),q})).filter(x=>x.p);
  $('#orderItems').innerHTML=arr.map(({p,q})=>{
    const multi=quantityMode(p)==='multiple',id=escAttr(p.id);
    return `<div class="orderItem"><span class="thumb">${orderThumb(p)}</span><div class="info"><b>${esc(p.name)}</b><small>${money(p.price)}</small>${stockMarkup(p)}</div>${multi?`<div class="qtyStepper"><button type="button" data-cart-qty="-" data-id="${id}" aria-label="Diminuer" ${q<=1?'disabled':''}>${ic('minus')}</button><b>${q}</b><button type="button" data-cart-qty="+" data-id="${id}" aria-label="Augmenter" ${q>=maxQty(p)?'disabled':''}>${ic('plus')}</button></div>`:''}</div>`;
  }).join('');
  $('#orderTotal').textContent=money(arr.reduce((s,{p,q})=>s+Number(p.price||0)*q,0));
}
function openRequestForm(draft){
  if(draft&&!draft.product_id)draft=null;
  if(!activeOrderIdempotencyKey)activeOrderIdempotencyKey=null;
  const fields=$('#operationFields');
  let arr=[...cart].map(([id])=>products.find(p=>p.id===id)).filter(Boolean);
  fields.innerHTML=arr.map((p,i)=>{
    if(!(opSpec(opKind(p)).fields||[]).length)return '';
    if(draft&&draft.product_id===p.id){setTimeout(()=>{for(const [k,v] of Object.entries(draft.details||{})){const el=fields.querySelector(`[data-op-index="${i}"][data-field="${escAttr(k)}"]`);if(el)el.value=v}},0)}
    return fieldFor(opKind(p),i);
  }).join('');
  renderOrderItems();
  $('#modal').classList.remove('hidden');
}
$('#order').onclick=openRequestForm;$('#close').onclick=()=>$('#modal').classList.add('hidden');$('#finish').onclick=()=>{$('#done').classList.add('hidden');showPage('history');refreshTrackedOrders()};$('#form').onsubmit=async e=>{e.preventDefault();const submit=e.currentTarget.querySelector('button[type=submit]');if(submit?.disabled)return;if(!activeOrderIdempotencyKey)activeOrderIdempotencyKey=newOrderIdempotencyKey();if(submit){submit.disabled=true;submit.dataset.originalHtml=submit.innerHTML;submit.textContent='Envoi…'}let arr=[...cart].map(([id])=>products.find(p=>p.id===id)).filter(Boolean);let items=arr.map((p,i)=>{let d={};document.querySelectorAll(`[data-op-index="${i}"][data-field]`).forEach(el=>d[el.dataset.field]=el.value);return {product_id:p.id,quantity:cart.get(p.id)||1,kind:opKind(p),details:d}});try{let d=await api('/api/requests',{method:'POST',headers:{'X-Idempotency-Key':activeOrderIdempotencyKey},body:JSON.stringify({customer_name:$('#name').value,customer_phone:$('#phone').value,items})});last=d;trackOrder(d);refreshTrackedOrders();$('#modal').classList.add('hidden');$('#qn').textContent='#'+String(d.queue_number).padStart(3,'0');$('#status').textContent='En attente';$('#done').classList.remove('hidden');cart.clear();render();activeOrderIdempotencyKey=null}catch(err){alert(err.message)}finally{if(submit){submit.disabled=false;submit.innerHTML=submit.dataset.originalHtml||'Commander'}}};
let clientIdentitySignature='';
async function syncClientShopIdentity(){
  try{
    const r=await api('/api/identity');
    const d=r.identity||{};
    const signature=JSON.stringify(d);
    if(signature!==clientIdentitySignature){
      clientIdentitySignature=signature;
      enterprise={...enterprise,...d};
      updateClientShopIdentity(d);
    }
  }catch(_){}
}

function renderAnnouncements(items){
  const list=Array.isArray(items)?items:[];
  const box=$('#announcements');
  if(box) box.innerHTML=list.map(x=>`<article class="announcement"><div class="announcementIcon">${x.type==='warning'?'!':'i'}</div><div><h3>${esc(x.title)}</h3><p>${esc(x.message)}</p><small>${esc(x.created_at||'')}</small></div></article>`).join('')||'<p class="empty">Aucune annonce.</p>';
  const badge=$('#annBadge');
  if(badge){badge.textContent=list.length;badge.classList.toggle('hidden',!list.length);}
}
async function refreshAnnouncements(){
  try{
    const n=await api('/api/announcements');
    renderAnnouncements(n.items||[]);
  }catch(_){}
}

async function load(options={}){try{const conn=$('#conn');if(conn)conn.hidden=true;let [cfg,p,n]=await Promise.all([api('/api/config'),api('/api/products'),api('/api/announcements')]);const previousCategory=$('#cat')?.value||'';enterprise={...(cfg.enterprise||{}),...(cfg.identity||{})};updateClientShopIdentity(enterprise);catalog=cfg.operation_catalog||{operations:[]};for(const o of catalog.operations)kindInfo[o.kind]=o;products=Array.isArray(p.items)?p.items:[];highlights=[];document.body.dataset.store=enterprise.store_id||BOUTIQUE_STORE||'';const categories=[...new Set(products.map(x=>String(x.category||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr'));$('#cat').innerHTML='<option value="">Toutes les catégories</option>'+categories.map(c=>`<option value="${escAttr(c)}">${esc(c)}</option>`).join('');if(categories.includes(previousCategory))$('#cat').value=previousCategory;renderCatTabs();render();renderAnnouncements(n.items||[]);refreshTrackedOrders();startOrderStream()}catch(e){const el=$('#conn');if(el&&!options.silent){el.textContent='Catalogue indisponible';el.hidden=false;el.title='Le catalogue n’a pas pu être chargé. Réessayez.'} $('#grid')&&( $('#grid').innerHTML='<p class="empty">Le catalogue n’a pas pu être chargé pour cette boutique.</p>' ); console.error('LobiCop client load failed',e)}}
function renderCatTabs(){
  const box=$('#catTabs'),sel=$('#cat');if(!box||!sel)return;
  const cats=[...sel.options].map(o=>({v:o.value,t:o.value?o.textContent:'Tous'}));
  box.hidden=cats.length<3;
  box.innerHTML=cats.map(c=>`<button type="button" class="catTab ${sel.value===c.v?'active':''}" role="tab" aria-selected="${sel.value===c.v}" data-cat="${escAttr(c.v)}">${esc(c.t)}</button>`).join('');
}
function initShopCards(){
  $('#catTabs')?.addEventListener('click',e=>{const b=e.target.closest('[data-cat]');if(!b)return;$('#cat').value=b.dataset.cat;renderCatTabs();$('#cat').dispatchEvent(new Event('change'))});
  $('#shopBack')?.addEventListener('click',()=>{location.href='/'});
  $('#shopSearchBtn')?.addEventListener('click',()=>{window.scrollTo({top:0,behavior:'smooth'});$('#search')?.focus()});
  $('#shopCartBtn')?.addEventListener('click',()=>{setCartCollapsed(false);$('#cart')?.classList.add('cartAttention');setTimeout(()=>$('#cart')?.classList.remove('cartAttention'),500)});
  $('#shopVisit')?.addEventListener('click',()=>{$('#closeClientShopCard')?.click();showPage('home');document.querySelector('.catalog')?.scrollIntoView({behavior:'smooth',block:'start'})});
  const fav=$('#shopFavBtn');
  if(fav){const sync=()=>{const on=isFav('__shop__');fav.classList.toggle('fav',on);fav.setAttribute('aria-pressed',String(on))};sync();fav.addEventListener('click',()=>{toggleFav('__shop__');sync()})}
  $('#backShop')?.addEventListener('click',()=>{$('#done').classList.add('hidden');showPage('home')});
  $('#history')?.addEventListener('click',e=>{const b=e.target.closest('[data-track-toggle]');if(!b)return;const on=b.closest('.trackCard').classList.toggle('expanded');b.textContent=on?'Masquer les détails':'Voir les détails'});
  $('#orderItems')?.addEventListener('click',e=>{
    const b=e.target.closest('[data-cart-qty]');if(!b)return;
    const id=b.dataset.id,p=products.find(x=>x.id===id);if(!p)return;
    cart.set(id,Math.max(1,Math.min(maxQty(p),(cart.get(id)||1)+(b.dataset.cartQty==='+'?1:-1))));
    renderOrderItems();renderCart();
  });
}
function initCatalogInteractions(){
  const search=$('#search'), clear=$('#searchClear'), cat=$('#cat');
  search?.addEventListener('input',scheduleRender);
  clear?.addEventListener('click',()=>{if(search){search.value='';search.focus();render()}});
  cat?.addEventListener('change',async()=>{
    // L'affichage du filtre est local et donc immédiat. On déclenche ensuite
    // une requête automatique pour récupérer l'état le plus récent du catalogue.
    render();
    await load({silent:true});
  });
}

syncClientShopIdentity();
load();
initTheme();
initCartCollapse();
bindAppIdentity();
bindClientShopIdentity();
initCatalogInteractions();
bindCatalogDelegation();
initShopCards();
let identityTimer=setInterval(()=>{if(!document.hidden)syncClientShopIdentity()},30000);
// Plus de rechargement aveugle toutes les 10 secondes : les actions utilisateur
// déclenchent les rafraîchissements utiles, avec un filet de sécurité plus lent.
let loadTimer=setInterval(()=>{if(!document.hidden)load({silent:true})},60000);
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden)load({silent:true});
});


// 2.2 — Le menu est disponible dès l'entrée. Le bouton est seulement un raccourci
// vers la liste : l'utilisateur peut aussi simplement descendre dans la page.
function initSimpleClientHome(){
  const button=$('#openMenu');
  if(!button) return;
  button.addEventListener('click',()=>{
    document.querySelector('.catalog')?.scrollIntoView({behavior:'smooth',block:'start'});
  });
}
initSimpleClientHome();

function makeFloatingIdentityMovable(button, storageKey){
  if(!button || button.dataset.dragBound) return;
  button.dataset.dragBound='1';
  button.style.touchAction='none';
  let dragging=false, moved=false, startX=0, startY=0, originLeft=0, originTop=0;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem(storageKey)||'null')}catch(_){return null}})();
  const apply=(left,top)=>{
    const maxX=Math.max(0,window.innerWidth-button.offsetWidth);
    const maxY=Math.max(0,window.innerHeight-button.offsetHeight);
    left=Math.max(0,Math.min(maxX,left)); top=Math.max(0,Math.min(maxY,top));
    button.style.left=left+'px'; button.style.top=top+'px';
    button.style.right='auto'; button.style.bottom='auto';
    try{localStorage.setItem(storageKey,JSON.stringify({left,top}))}catch(_){}
    window.dispatchEvent(new CustomEvent('nzela-shop-position'));
  };
  if(saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)){
    requestAnimationFrame(()=>apply(saved.left,saved.top));
  }
  const point=(e)=>({x:e.clientX,y:e.clientY});
  button.addEventListener('pointerdown',e=>{
    if(e.button!==undefined && e.button!==0) return;
    const p=point(e), r=button.getBoundingClientRect();
    dragging=true; moved=false; startX=p.x; startY=p.y; originLeft=r.left; originTop=r.top;
    button.setPointerCapture?.(e.pointerId);
  });
  button.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const p=point(e), dx=p.x-startX, dy=p.y-startY;
    if(Math.abs(dx)>4 || Math.abs(dy)>4)moved=true;
    if(moved)apply(originLeft+dx,originTop+dy);
  });
  const end=e=>{
    if(!dragging)return;
    dragging=false;
    button.releasePointerCapture?.(e.pointerId);
    if(moved){
      button.dataset.suppressClick='1';
      setTimeout(()=>{button.dataset.suppressClick='';},0);
    }
  };
  button.addEventListener('pointerup',end);
  button.addEventListener('pointercancel',end);
  button.addEventListener('click',e=>{
    if(button.dataset.suppressClick==='1'){e.preventDefault();e.stopImmediatePropagation();}
  },true);
  window.addEventListener('resize',()=>{
    const r=button.getBoundingClientRect();
    if(r.width)apply(r.left,r.top);
  });
}

makeFloatingIdentityMovable(document.getElementById('clientShopIdentity'),'nzela_client_identity_position');

// 2.18.16 — le bouton reste toujours sous l'icône, même après déplacement de celle-ci
function syncBackToTop(){
  const shop=document.getElementById('clientShopIdentity');
  const topBtn=document.getElementById('backToTop');
  if(!shop || !topBtn) return;
  const r=shop.getBoundingClientRect();
  const gap=8;
  topBtn.style.left=Math.round(r.left + (r.width-topBtn.offsetWidth)/2)+'px';
  topBtn.style.top=Math.round(r.bottom + gap)+'px';
  topBtn.style.right='auto';
}
window.addEventListener('nzela-shop-position',syncBackToTop);
window.addEventListener('resize',syncBackToTop);
requestAnimationFrame(syncBackToTop);

document.getElementById('backToTop')?.addEventListener('click',()=>{
  window.scrollTo(0,0);
});
