/* LOBICOP — thème partagé (sombre / clair), repris de l'espace administrateur.
   Une seule préférence pour toute la plateforme : nzela_theme (dark|light) + nzela_theme_scale (0-100).
   À charger dans <head> pour éviter un flash blanc au chargement. */
(function () {
  var KEY = 'nzela_theme', LEGACY = 'nzela_theme_mode', SCALE = 'nzela_theme_scale';
  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function clamp(n) { n = Number(n); return isFinite(n) ? Math.max(0, Math.min(100, n)) : 50; }
  var mode = (get(KEY) || get(LEGACY)) === 'light' ? 'light' : 'dark';
  var scale = get(SCALE) === null ? 50 : clamp(get(SCALE));

  function paint() {
    var h = document.documentElement, light = mode === 'light';
    h.classList.add('lbt'); h.classList.toggle('light', light);
    h.style.setProperty('--theme-scale', scale + '%');
    var b = document.body;
    if (b) { b.classList.toggle('light', light); b.classList.toggle('admin-dark', !light); b.style.setProperty('--theme-scale', scale + '%'); }
    var btn = document.getElementById('themeToggle'), rng = document.getElementById('themeScale'), lab = document.getElementById('themeScaleLabel');
    if (btn) { btn.textContent = light ? '☾' : '☼'; btn.title = light ? 'Passer au mode sombre' : 'Passer au mode clair'; btn.setAttribute('aria-label', btn.title); }
    if (rng) rng.value = String(scale);
    if (lab) lab.textContent = scale + '%';
    var meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'theme-color'; document.head.appendChild(meta); }
    meta.content = light ? (scale >= 80 ? '#ffffff' : '#e9eef6') : '#070b14';
  }
  function setMode(m) { mode = m === 'light' ? 'light' : 'dark'; set(KEY, mode); paint(); }
  function setScale(s) { scale = clamp(s); set(SCALE, String(scale)); paint(); }

  paint();                                   // <html> tout de suite (avant le premier affichage)
  function ready() {
    paint();                                 // <body> + boutons maintenant disponibles
    var btn = document.getElementById('themeToggle'), rng = document.getElementById('themeScale');
    if (btn) btn.addEventListener('click', function () { setMode(mode === 'light' ? 'dark' : 'light'); });
    if (rng) rng.addEventListener('input', function (e) { setScale(e.target.value); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
  // Un changement fait dans un autre onglet / une autre page s'applique tout de suite.
  window.addEventListener('storage', function (e) {
    if (e.key === KEY) { mode = e.newValue === 'light' ? 'light' : 'dark'; paint(); }
    if (e.key === SCALE) { scale = e.newValue === null ? 50 : clamp(e.newValue); paint(); }
  });
  window.LOBICOP_THEME = { setMode: setMode, setScale: setScale, get mode() { return mode; }, get scale() { return scale; } };
})();
