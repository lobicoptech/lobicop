import base64, json, sqlite3, threading, uuid
from datetime import datetime, timezone
from pathlib import Path

STATUSES = ('pending', 'preparing', 'ready', 'completed', 'cancelled')
MAX_IMAGE_BYTES = 1_500_000
MAX_PRODUCT_IMAGES = 1
IMAGE_DATA_PREFIX = 'data:image/'

class EngineError(ValueError):
    pass

class NzelaEngine:
    """UI/API-independent NZELA business engine.

    Owns business state and rules only: catalog, categories, requests, stock,
    status transitions and events. It knows nothing about HTML, HTTP or UI.
    """
    def __init__(self, db_path='nzela.db', operation_catalog=None, default_categories=None):
        self.db_path = str(db_path)
        self.operation_catalog = operation_catalog or {'operations': []}
        self.default_categories = list(default_categories or [])
        self.operations = {x['kind']: x for x in self.operation_catalog.get('operations', [])}
        self.operations_by_id = {x['id']: x for x in self.operation_catalog.get('operations', [])}
        self.lock = threading.RLock()
        self.init()

    def _db(self):
        c = sqlite3.connect(self.db_path, timeout=10)
        c.row_factory = sqlite3.Row
        return c

    @staticmethod
    def now():
        return datetime.now(timezone.utc).isoformat(timespec='seconds')

    def init(self):
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True) if Path(self.db_path).parent != Path('.') else None
        with self.lock, self._db() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS categories(id TEXT PRIMARY KEY,name TEXT NOT NULL UNIQUE COLLATE NOCASE,created_at TEXT);
            CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT,category TEXT,price INTEGER,available INTEGER,stock INTEGER,description TEXT,image_data TEXT,created_at TEXT,operation_kind TEXT);
            CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,queue_number INTEGER UNIQUE,customer_name TEXT,customer_phone TEXT,items_json TEXT,total INTEGER,status TEXT,channel TEXT,created_at TEXT,updated_at TEXT,customer_account_id TEXT);
            CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id TEXT,event_type TEXT,payload_json TEXT,created_at TEXT);
            CREATE TABLE IF NOT EXISTS request_idempotency(idempotency_key TEXT PRIMARY KEY,request_id TEXT NOT NULL,created_at TEXT);
            CREATE TABLE IF NOT EXISTS highlights(id TEXT PRIMARY KEY,title TEXT,subtitle TEXT,description TEXT,kind TEXT,product_id TEXT,active INTEGER,priority INTEGER,created_at TEXT);
            CREATE TABLE IF NOT EXISTS announcements(id TEXT PRIMARY KEY,title TEXT,message TEXT,type TEXT,active INTEGER,created_at TEXT);
            ''')
            cols_ann={r['name'] for r in c.execute('PRAGMA table_info(announcements)').fetchall()}
            if 'target_account_id' not in cols_ann:
                c.execute('ALTER TABLE announcements ADD COLUMN target_account_id TEXT')

            cols={r['name'] for r in c.execute('PRAGMA table_info(requests)').fetchall()}
            if 'customer_account_id' not in cols:
                c.execute('ALTER TABLE requests ADD COLUMN customer_account_id TEXT')
            # Chaque espace reçoit automatiquement les catégories correspondant
            # à son métier. INSERT OR IGNORE rend ce seed sûr pour les bases
            # existantes et n'écrase jamais les catégories personnalisées.
            for category in self.default_categories:
                name = str(category or '').strip()
                if name:
                    c.execute(
                        'INSERT OR IGNORE INTO categories VALUES(?,?,?)',
                        ('cat-' + uuid.uuid4().hex[:10].upper(), name, self.now())
                    )
            c.commit()

    def categories(self):
        with self.lock, self._db() as c:
            return [dict(r) for r in c.execute('SELECT id,name,created_at FROM categories ORDER BY name COLLATE NOCASE')]

    def add_category(self, name):
        name = str(name or '').strip()
        if not name or len(name) > 80: raise EngineError('invalid_category')
        cid = 'cat-' + uuid.uuid4().hex[:10].upper()
        with self.lock, self._db() as c:
            try: c.execute('INSERT INTO categories VALUES(?,?,?)', (cid, name, self.now())); c.commit()
            except sqlite3.IntegrityError: raise EngineError('category_exists')
        return {'id': cid, 'name': name}

    def products(self):
        with self.lock, self._db() as c:
            return [dict(r) for r in c.execute('SELECT id,name,category,price,available,stock,description,image_data,created_at,operation_kind FROM products ORDER BY category COLLATE NOCASE,name COLLATE NOCASE')]

    def _clean_image(self, value):
        if not value: return None
        values = value if isinstance(value, list) else [value]
        if len(values) > MAX_PRODUCT_IMAGES: raise EngineError('too_many_images')
        for item in values:
            if not isinstance(item, str) or not item.startswith(IMAGE_DATA_PREFIX) or ',' not in item:
                raise EngineError('invalid_image')
            try: raw = base64.b64decode(item.split(',', 1)[1], validate=True)
            except Exception: raise EngineError('invalid_image')
            if len(raw) > MAX_IMAGE_BYTES: raise EngineError('image_too_large')
        return json.dumps(values, ensure_ascii=False) if isinstance(value, list) else value

    def add_product(self, data):
        name = str(data.get('name','')).strip(); category = str(data.get('category','Général')).strip() or 'Général'
        desc = str(data.get('description','')).strip(); price = int(data.get('price',0)); stock = int(data.get('stock',0))
        available = 1 if bool(data.get('available', stock > 0)) and stock > 0 else 0
        kind = str(data.get('operation_kind','')).strip()
        if not name or price < 0 or stock < 0 or len(category) > 80: raise EngineError('invalid_product')
        image = self._clean_image(data.get('image_data')); pid = 'p-' + uuid.uuid4().hex[:8]; t = self.now()
        with self.lock, self._db() as c:
            c.execute('INSERT OR IGNORE INTO categories VALUES(?,?,?)', ('cat-'+uuid.uuid4().hex[:10].upper(), category, t))
            c.execute('INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?,?)', (pid,name,category,price,available,stock,desc,image,t,kind)); c.commit()
        return {'id': pid}

    def get_request(self, request_id):
        with self.lock, self._db() as c: r = c.execute('SELECT * FROM requests WHERE id=?',(request_id,)).fetchone()
        if not r: raise EngineError('request_not_found')
        return self._payload(r)

    @staticmethod
    def _payload(row):
        d = dict(row); d['items'] = json.loads(d.pop('items_json')); return d

    def requests(self, limit=100):
        with self.lock, self._db() as c: rows = c.execute('SELECT * FROM requests ORDER BY queue_number DESC LIMIT ?', (int(limit),)).fetchall()
        return [self._payload(r) for r in rows]

    def _validate_operation(self, kind, details):
        spec = self.operations.get(kind)
        if not spec: raise EngineError('unknown_operation')
        if not isinstance(details, dict): raise EngineError('details_required')
        for f in spec.get('fields', []):
            v = str(details.get(f['name'], '')).strip()
            if f.get('required') and not v: raise EngineError(f"{f['name']}_required")
            if f.get('type') == 'number' and v:
                try: n = int(v)
                except Exception: raise EngineError(f"{f['name']}_invalid")
                if n < int(f.get('min', 0)): raise EngineError(f"{f['name']}_invalid")
        return details

    def create_request(self, data, idempotency_key=None):
        account_id = str(data.get('customer_account_id','')).strip() or None
        name = str(data.get('customer_name','')).strip(); phone = str(data.get('customer_phone','')).strip(); items = data.get('items', [])
        if not name or not isinstance(items, list) or not items: raise EngineError('customer_name_and_items_required')
        idem = str(idempotency_key or '').strip()[:200] or None
        with self.lock, self._db() as c:
            if idem:
                previous = c.execute('SELECT request_id FROM request_idempotency WHERE idempotency_key=?',(idem,)).fetchone()
                if previous:
                    existing = c.execute('SELECT * FROM requests WHERE id=?',(previous['request_id'],)).fetchone()
                    if existing:
                        result = self._payload(existing)
                        return {'ok':True,'request_id':result['id'],'queue_number':result['queue_number'],'status':result['status'],'total':result['total'],'operation_count':len(result.get('items',[])),'duplicate':True}
                    c.execute('DELETE FROM request_idempotency WHERE idempotency_key=?',(idem,))
            total = 0; norm = []
            # Aggregate duplicate product lines before any stock mutation.
            grouped = {}
            for it in items:
                pid = str(it.get('product_id','')).strip()
                try: q = int(it.get('quantity', 1))
                except Exception: raise EngineError('invalid_quantity')
                grouped.setdefault(pid, []).append((it, q))
            merged = []
            for pid, lines in grouped.items():
                q = sum(x[1] for x in lines); base = dict(lines[0][0]); base['quantity'] = q; merged.append(base)
            for it in merged:
                pid = str(it.get('product_id','')).strip(); q = int(it.get('quantity',1)); pdt = c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                if not pdt: raise EngineError('product_not_found')
                # Le type d'opération vient du PRODUIT, pas du client : sinon un client pourrait envoyer un autre
                # « kind » sans champs obligatoires (ex. ordonnance) pour contourner la validation.
                kind = str(pdt['operation_kind'] or it.get('kind') or '').strip().lower() or self.operations_by_id.get(pid,{}).get('kind','')
                qmode = self.operations.get(kind,{}).get('quantity_mode','single')
                if q < 1 or (qmode != 'multiple' and q != 1): raise EngineError('invalid_quantity')
                if not pdt['available']: raise EngineError('service_unavailable')
                if q > int(pdt['stock'] or 0): raise EngineError('insufficient_stock')
                details = self._validate_operation(kind, it.get('details', {})); details['operation'] = kind
                unit = int(pdt['price'] or 0); subtotal = unit*q; total += subtotal
                norm.append({'product_id':pid,'name':pdt['name'],'quantity':q,'unit_price':unit,'subtotal':subtotal,'kind':kind,'details':details})
            qn = c.execute('SELECT COALESCE(MAX(queue_number),0)+1 n FROM requests').fetchone()['n']; rid = 'REQ-'+uuid.uuid4().hex[:8].upper(); t = self.now(); ch = str(data.get('channel','web'))[:30]
            c.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?,?,?,?)',(rid,qn,name,phone,json.dumps(norm,ensure_ascii=False),total,'pending',ch,t,t,account_id))
            for item in norm:
                cur = c.execute('UPDATE products SET stock=stock-?,available=CASE WHEN stock-?<=0 THEN 0 ELSE available END WHERE id=? AND stock>=?',(item['quantity'],item['quantity'],item['product_id'],item['quantity']))
                if cur.rowcount != 1:
                    c.rollback(); raise EngineError('insufficient_stock')
            self._event(c,rid,'request_created',{'queue_number':qn,'channel':ch,'operation_count':len(norm),'total':total});
            if idem: c.execute('INSERT INTO request_idempotency VALUES(?,?,?)',(idem,rid,t))
            c.commit()
        return {'ok':True,'request_id':rid,'queue_number':qn,'status':'pending','total':total,'operation_count':len(norm)}

    def requests_for_account(self, account_id, limit=100):
        with self.lock, self._db() as c:
            rows=c.execute('SELECT * FROM requests WHERE customer_account_id=? ORDER BY created_at DESC LIMIT ?', (str(account_id), int(limit))).fetchall()
        return [self._payload(r) for r in rows]

    def update_product(self, product_id, data):
        allowed={'name','category','price','stock','description','image_data'}
        changes=[]; values=[]
        with self.lock, self._db() as c:
            row=c.execute('SELECT * FROM products WHERE id=?',(product_id,)).fetchone()
            if not row: raise EngineError('product_not_found')
            for k in ('name','category','price','stock','description','image_data'):
                if k not in data: continue
                v=data[k]
                if k in ('price','stock'):
                    v=int(v)
                    if v<0: raise EngineError('invalid_product')
                elif k in ('name','category'):
                    v=str(v or '').strip()
                    if not v or (k=='category' and len(v)>80): raise EngineError('invalid_product')
                elif k=='description': v=str(v or '').strip()
                elif k=='image_data': v=self._clean_image(v)
                changes.append(f'{k}=?'); values.append(v)
            # Disponibilité calculée sur le stock FINAL (et non l'ancien) ; réapprovisionner un
            # produit épuisé le remet en vente, un stock à 0 le retire toujours.
            new_stock=int(data['stock']) if 'stock' in data else int(row['stock'] or 0)
            if 'available' in data: avail=1 if bool(data['available']) and new_stock>0 else 0
            elif 'stock' in data: avail=0 if new_stock<=0 else (1 if int(row['stock'] or 0)<=0 else int(row['available'] or 0))
            else: avail=None
            if avail is not None: changes.append('available=?'); values.append(avail)
            if changes:
                values.append(product_id); c.execute('UPDATE products SET '+','.join(changes)+' WHERE id=?',values); c.commit()
            return dict(c.execute('SELECT * FROM products WHERE id=?',(product_id,)).fetchone())

    def delete_product(self, product_id):
        with self.lock, self._db() as c:
            cur=c.execute('DELETE FROM products WHERE id=?',(product_id,)); c.commit()
            if cur.rowcount!=1: raise EngineError('product_not_found')
            return {'ok':True}

    def highlights(self):
        with self.lock, self._db() as c:
            return [dict(r) for r in c.execute('SELECT * FROM highlights ORDER BY priority DESC,created_at DESC')]

    def add_highlight(self, data):
        hid='hl-'+uuid.uuid4().hex[:10]; t=self.now()
        row=(hid,str(data.get('title','')).strip(),str(data.get('subtitle','')).strip(),str(data.get('description','')).strip(),str(data.get('kind','product')).strip(),str(data.get('product_id','')).strip() or None,1 if data.get('active',True) else 0,int(data.get('priority',100)),t)
        if not row[1]: raise EngineError('title_required')
        with self.lock, self._db() as c: c.execute('INSERT INTO highlights VALUES(?,?,?,?,?,?,?,?,?)',row); c.commit()
        return dict(zip(['id','title','subtitle','description','kind','product_id','active','priority','created_at'],row))

    def update_highlight(self, hid, data):
        active=1 if bool(data.get('active')) else 0
        with self.lock, self._db() as c:
            cur=c.execute('UPDATE highlights SET active=? WHERE id=?',(active,hid)); c.commit()
            if cur.rowcount!=1: raise EngineError('highlight_not_found')
            return dict(c.execute('SELECT * FROM highlights WHERE id=?',(hid,)).fetchone())

    def announcements(self, account_id=None):
        with self.lock, self._db() as c:
            if account_id:
                rows=c.execute("SELECT * FROM announcements WHERE active=1 AND (target_account_id IS NULL OR target_account_id='' OR target_account_id=?) ORDER BY created_at DESC",(account_id,)).fetchall()
            else:
                rows=c.execute('SELECT * FROM announcements ORDER BY created_at DESC').fetchall()
            return [dict(r) for r in rows]

    def add_announcement(self, data):
        aid='ann-'+uuid.uuid4().hex[:10]; t=self.now()
        title=str(data.get('title','')).strip()
        message=str(data.get('message','')).strip()
        kind=str(data.get('type','info')).strip()
        target=str(data.get('target_account_id') or '').strip() or None
        row=(aid,title,message,kind,1,t,target)
        if not title or not message: raise EngineError('announcement_required')
        with self.lock, self._db() as c:
            c.execute('INSERT INTO announcements(id,title,message,type,active,created_at,target_account_id) VALUES(?,?,?,?,?,?,?)',row)
            c.commit()
        return dict(zip(['id','title','message','type','active','created_at','target_account_id'],row))

    def update_announcement(self, aid, data):
        active=1 if bool(data.get('active')) else 0
        with self.lock, self._db() as c:
            cur=c.execute('UPDATE announcements SET active=? WHERE id=?',(active,aid)); c.commit()
            if cur.rowcount!=1: raise EngineError('announcement_not_found')
            return dict(c.execute('SELECT * FROM announcements WHERE id=?',(aid,)).fetchone())

    def update_status(self, request_id, status):
        if status not in STATUSES: raise EngineError('invalid_status')
        with self.lock, self._db() as c:
            r = c.execute('SELECT * FROM requests WHERE id=?',(request_id,)).fetchone()
            if not r: raise EngineError('request_not_found')
            old = r['status']
            if old == status: return self._payload(r)
            if old == 'cancelled': raise EngineError('request_cancelled')  # le stock a déjà été restitué
            if status == 'cancelled':  # une commande annulée rend le stock réservé
                for it in json.loads(r['items_json']):
                    c.execute('UPDATE products SET stock=stock+?,available=CASE WHEN stock=0 THEN 1 ELSE available END WHERE id=?',(int(it.get('quantity',0)),it.get('product_id')))
            c.execute('UPDATE requests SET status=?,updated_at=? WHERE id=?',(status,self.now(),request_id)); self._event(c,request_id,'status_changed',{'from':old,'to':status}); c.commit()
            return self._payload(c.execute('SELECT * FROM requests WHERE id=?',(request_id,)).fetchone())

    @staticmethod
    def _event(c, request_id, event_type, payload=None):
        c.execute('INSERT INTO events(request_id,event_type,payload_json,created_at) VALUES(?,?,?,?)',(request_id,event_type,json.dumps(payload or {},ensure_ascii=False),NzelaEngine.now()))

    def events(self, limit=200):
        with self.lock, self._db() as c: return [dict(r) for r in c.execute('SELECT id,request_id,event_type,payload_json,created_at FROM events ORDER BY id DESC LIMIT ?', (int(limit),))]

    def stats(self):
        with self.lock, self._db() as c:
            counts = {s:c.execute('SELECT COUNT(*) n FROM requests WHERE status=?',(s,)).fetchone()['n'] for s in STATUSES}
        counts['active'] = sum(counts[s] for s in ('pending','preparing','ready'))
        return counts
