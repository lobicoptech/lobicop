"""Messagerie LOBICOP : conversations privées et conversations avec boutiques.
Stockage SQLite local, persistant et compatible avec plusieurs requêtes simultanées.
"""
import sqlite3, threading, uuid
from datetime import datetime, timezone
from pathlib import Path

MAX_MESSAGE_LENGTH = 4000

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

class MessagingStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self._init()

    def _db(self):
        c = sqlite3.connect(self.path, timeout=10, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('PRAGMA foreign_keys=ON')
        return c

    def _init(self):
        with self.lock, self._db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS conversations (
              id TEXT PRIMARY KEY,
              kind TEXT NOT NULL CHECK(kind IN ('direct','store')),
              store_id TEXT,
              direct_key TEXT UNIQUE,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS participants (
              conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
              account_id TEXT NOT NULL,
              PRIMARY KEY(conversation_id, account_id)
            );
            CREATE TABLE IF NOT EXISTS messages (
              id TEXT PRIMARY KEY,
              conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
              sender_id TEXT NOT NULL,
              body TEXT NOT NULL,
              created_at TEXT NOT NULL,
              read_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_participant_account ON participants(account_id);
            CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);
            ''')

    def _conversation_for_user(self, db, conversation_id, account_id):
        row = db.execute('SELECT c.* FROM conversations c JOIN participants p ON p.conversation_id=c.id WHERE c.id=? AND p.account_id=?', (conversation_id, account_id)).fetchone()
        if not row: raise PermissionError('conversation_forbidden')
        return row

    def direct(self, a, b):
        if not a or not b or a == b: raise ValueError('invalid_recipient')
        key=':'.join(sorted((a,b)))
        with self.lock, self._db() as db:
            row=db.execute('SELECT * FROM conversations WHERE direct_key=?',(key,)).fetchone()
            if row: return dict(row)
            cid='conv-'+uuid.uuid4().hex[:16]; t=now()
            db.execute('INSERT INTO conversations(id,kind,direct_key,created_at,updated_at) VALUES(?,?,?,?,?)',(cid,'direct',key,t,t))
            db.executemany('INSERT INTO participants(conversation_id,account_id) VALUES(?,?)',[(cid,a),(cid,b)])
            return {'id':cid,'kind':'direct','direct_key':key,'created_at':t,'updated_at':t,'store_id':None,'other_id':b}

    def store_conversation(self, account_id, store_id, owner_id):
        if not owner_id: raise ValueError('store_has_no_owner')
        if account_id == owner_id: raise ValueError('cannot_message_own_store')
        key=f'store:{store_id}:{account_id}'
        with self.lock, self._db() as db:
            row=db.execute('SELECT * FROM conversations WHERE direct_key=?',(key,)).fetchone()
            if row: return dict(row)
            cid='conv-'+uuid.uuid4().hex[:16]; t=now()
            db.execute('INSERT INTO conversations(id,kind,store_id,direct_key,created_at,updated_at) VALUES(?,?,?,?,?,?)',(cid,'store',store_id,key,t,t))
            db.executemany('INSERT INTO participants(conversation_id,account_id) VALUES(?,?)',[(cid,account_id),(cid,owner_id)])
            return {'id':cid,'kind':'store','store_id':store_id,'direct_key':key,'created_at':t,'updated_at':t,'other_id':owner_id}

    def conversations(self, account_id):
        with self.lock, self._db() as db:
            rows=db.execute('''SELECT c.*, m.body last_body, m.created_at last_message_at,
                (SELECT account_id FROM participants p2 WHERE p2.conversation_id=c.id AND p2.account_id<>?) other_id
                FROM conversations c JOIN participants p ON p.conversation_id=c.id
                LEFT JOIN messages m ON m.id=(SELECT id FROM messages m2 WHERE m2.conversation_id=c.id ORDER BY created_at DESC LIMIT 1)
                WHERE p.account_id=? ORDER BY COALESCE(m.created_at,c.updated_at) DESC''',(account_id,account_id)).fetchall()
            out=[]
            for r in rows:
                d=dict(r)
                oid=d.get('other_id')
                out.append(d)
            return out

    def messages(self, conversation_id, account_id, limit=100):
        with self.lock, self._db() as db:
            self._conversation_for_user(db,conversation_id,account_id)
            rows=db.execute('SELECT id,conversation_id,sender_id,body,created_at,read_at FROM messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT ?', (conversation_id,max(1,min(int(limit),200)))).fetchall()
            return [dict(x) for x in reversed(rows)]

    def mark_read(self, conversation_id, account_id):
        with self.lock, self._db() as db:
            self._conversation_for_user(db, conversation_id, account_id)
            t=now()
            db.execute('UPDATE messages SET read_at=? WHERE conversation_id=? AND sender_id<>? AND read_at IS NULL',(t,conversation_id,account_id))
            return t

    def send(self, conversation_id, sender_id, body):
        body=' '.join(str(body or '').strip().split())
        if not body: raise ValueError('message_empty')
        if len(body)>MAX_MESSAGE_LENGTH: raise ValueError('message_too_long')
        with self.lock, self._db() as db:
            self._conversation_for_user(db,conversation_id,sender_id)
            mid='msg-'+uuid.uuid4().hex[:16]; t=now()
            db.execute('INSERT INTO messages(id,conversation_id,sender_id,body,created_at) VALUES(?,?,?,?,?)',(mid,conversation_id,sender_id,body,t))
            db.execute('UPDATE conversations SET updated_at=? WHERE id=?',(t,conversation_id))
            row=db.execute('SELECT * FROM messages WHERE id=?',(mid,)).fetchone()
            participants=[r['account_id'] for r in db.execute('SELECT account_id FROM participants WHERE conversation_id=?',(conversation_id,)).fetchall()]
            return dict(row), participants
