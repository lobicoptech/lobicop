"""Commerce/Boutique adapter for LOBICOP.

One adapter covers ordinary shops, online sellers, producers, artisans and
restaurants. The common CORE remains responsible for catalogue, stock,
requests and state transitions; this adapter only describes commerce actions.
"""
from nzela_core_engine import NzelaEngine, EngineError

COMMERCE_OPERATIONS = {
    'operations': [
        {'id':'product_order','kind':'product_order','name':'Commande de produit','quantity_mode':'multiple','fields':[]},
        {'id':'reservation_request','kind':'reservation_request','name':'Réservation','quantity_mode':'single',
         'fields':[{'name':'reservation_time','type':'text','required':True,'label':'Date et heure'},
                   {'name':'guests','type':'number','required':True,'min':1,'label':'Nombre de personnes'}]},
        {'id':'contact_request','kind':'contact_request','name':'Demande de contact','quantity_mode':'single','fields':[]},
    ]
}

COMMERCE_CATEGORIES = ['Produits','Alimentation','Boissons','Mode','Maison','Électronique','Artisanat','Services','Réservations','Autres']

class CommerceEngine(NzelaEngine):
    """Generic boutique/commerce engine; restaurant is a commerce profile."""
    def __init__(self, db_path='commerce.db', operation_catalog=None, default_categories=None):
        super().__init__(
            db_path=db_path,
            operation_catalog=operation_catalog or COMMERCE_OPERATIONS,
            default_categories=default_categories if default_categories is not None else COMMERCE_CATEGORIES
        )

    def add_item(self, data):
        d=dict(data); d['operation_kind']=d.get('operation_kind') or 'product_order'
        d['category']=str(d.get('category','Produits')).strip() or 'Produits'
        d.setdefault('description','')
        if d['operation_kind']=='reservation_request':
            d['category']='Réservations'; d['stock']=max(1,int(d.get('stock',20)))
        if d['operation_kind']=='contact_request':
            d['stock']=max(1,int(d.get('stock',1)))
        return self.add_product(d)

class RestaurantEngine(CommerceEngine):
    """Compatibility/profile adapter: restaurant operations on the commerce adapter."""
    def __init__(self, db_path='restaurant.db'):
        catalog = {
            'operations': [
                {'id':'menu_item','kind':'menu_item','name':'Article du menu','quantity_mode':'multiple','fields':[]},
                {'id':'reservation_request','kind':'reservation_request','name':'Réservation de table','quantity_mode':'single',
                 'fields':[{'name':'reservation_time','type':'text','required':True,'label':'Date et heure'},
                           {'name':'guests','type':'number','required':True,'min':1,'label':'Nombre de personnes'}]},
            ]
        }
        super().__init__(db_path=db_path, operation_catalog=catalog, default_categories=RESTAURANT_CATEGORIES)

    def add_menu_item(self, data):
        d=dict(data); d['operation_kind']='menu_item'; d['category']=str(d.get('category','Plats')).strip() or 'Plats'
        if d['category'] not in ['Entrées','Plats','Accompagnements','Boissons','Desserts','Menus','Réservations']:
            raise EngineError('invalid_restaurant_category')
        return self.add_product(d)

    def add_reservation_slot(self, data):
        d=dict(data); d['operation_kind']='reservation_request'; d['category']='Réservations'; d['stock']=max(1,int(d.get('stock',20)))
        return self.add_product(d)

RESTAURANT_CATEGORIES=['Entrées','Plats','Accompagnements','Boissons','Desserts','Menus','Réservations']
