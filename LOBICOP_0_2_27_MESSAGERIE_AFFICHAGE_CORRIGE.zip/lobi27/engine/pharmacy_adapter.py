"""Pharmacy adaptation for NZELA CORE.

The engine remains generic. This adapter defines pharmacy-specific operations
and validates pharmacy product metadata without providing medical advice.
"""
from nzela_core_engine import NzelaEngine, EngineError

PHARMACY_OPERATIONS = {
    'operations': [
        {
            'id': 'pharmacy_product',
            'kind': 'pharmacy_product',
            'name': 'Produit pharmaceutique',
            'quantity_mode': 'multiple',
            'fields': []
        },
        {
            'id': 'prescription_request',
            'kind': 'prescription_request',
            'name': 'Demande avec ordonnance',
            'quantity_mode': 'multiple',
            'fields': [
                {'name': 'prescription_reference', 'type': 'text', 'required': True}
            ]
        },
        {
            'id': 'pharmacy_service',
            'kind': 'pharmacy_service',
            'name': 'Service pharmacie',
            'quantity_mode': 'single',
            'fields': []
        }
    ]
}

PHARMACY_CATEGORIES = [
    'Médicaments',
    'Parapharmacie',
    'Hygiène',
    'Soins bébé',
    'Dispositifs médicaux',
    'Vitamines et bien-être',
    'Dermocosmétique',
    'Services'
]

class PharmacyEngine(NzelaEngine):
    """NZELA engine with pharmacy-oriented product rules and helpers."""
    def __init__(self, db_path='pharmacy.db'):
        super().__init__(db_path=db_path, operation_catalog=PHARMACY_OPERATIONS, default_categories=PHARMACY_CATEGORIES)

    def add_pharmacy_product(self, data):
        d = dict(data)
        d['operation_kind'] = d.get('operation_kind') or 'pharmacy_product'
        category = str(d.get('category', 'Médicaments')).strip()

        d['category'] = category
        d.setdefault('description', '')
        return self.add_product(d)

    def add_prescription_product(self, data):
        d = dict(data)
        d['operation_kind'] = 'prescription_request'
        d['category'] = str(d.get('category', 'Médicaments')).strip() or 'Médicaments'

        return self.add_product(d)

    def add_service(self, data):
        d = dict(data)
        d['operation_kind'] = 'pharmacy_service'
        d['category'] = 'Services'
        d['stock'] = max(1, int(d.get('stock', 1)))
        return self.add_product(d)
