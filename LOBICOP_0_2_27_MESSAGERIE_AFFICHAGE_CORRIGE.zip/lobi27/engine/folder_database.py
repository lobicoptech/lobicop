"""Importation des données LobiCop construites sous forme de dossiers.\n\nCette couche sépare les données réelles du code : une boutique est un dossier,\nun utilisateur est un dossier et chaque produit possède son propre dossier.\n"""
import base64, hashlib, json, mimetypes, os, shutil, uuid
from pathlib import Path
from datetime import datetime, timezone
from accounts import _hash_password

SECTORS = {'pharmacie','parapharmacie','restaurant','boutique','commerce','vendeur-en-ligne','prestataire','taxi','service','etablissement','hotel','ecole','clinique','agence'}

def _load_json(path):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception: return None

def _slug(text):
    import re, unicodedata
    text=''.join(c for c in unicodedata.normalize('NFD', str(text)) if unicodedata.category(c)!='Mn')
    return re.sub(r'[^a-zA-Z0-9]+','-',text).strip('-').lower() or 'espace'

def _now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

def _image_data(path):
    if not path or not Path(path).is_file(): return None
    raw=Path(path).read_bytes()
    if len(raw)>2_000_000: return None
    mime=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
    return 'data:%s;base64,%s' % (mime, base64.b64encode(raw).decode('ascii'))

def _find_logo(folder):
    for name in ('logo.png','logo.jpg','logo.jpeg','logo.webp','logo.svg'):
        p=folder/name
        if p.is_file(): return p
    return None

def sync_real_accounts(base_dir, accounts_path):
    users_dir=Path(base_dir)/'utilisateurs'; accounts_path=Path(accounts_path)
    try: accounts=json.loads(accounts_path.read_text(encoding='utf-8') or '[]')
    except Exception: accounts=[]
    by_id={a.get('id'):a for a in accounts if a.get('id')}; by_email={a.get('email','').lower():a for a in accounts if a.get('email')}
    changed=False; imported=[]
    if users_dir.exists():
        for folder in sorted(users_dir.iterdir()):
            if not folder.is_dir() or folder.name.startswith('_'): continue
            data=_load_json(folder/'utilisateur.json')
            if not isinstance(data,dict): continue
            email=str(data.get('email','')).strip().lower(); name=str(data.get('name','')).strip()
            if not email or not name: continue
            uid=str(data.get('id') or ('acc-'+_slug(folder.name)+'-'+uuid.uuid4().hex[:6]))
            existing=by_id.get(uid) or by_email.get(email)
            if existing:
                uid=existing['id']; account=existing
            else:
                account={'id':uid,'name':name,'email':email,'created_at':data.get('created_at') or _now(),'roles':data.get('roles',['user','creator'])}
                password=str(data.get('password',''))
                if password and password!='A_REMPLACER':
                    salt,h=_hash_password(password); account['salt']=salt; account['password_hash']=h
                elif data.get('salt') and data.get('password_hash'):
                    account['salt']=data['salt']; account['password_hash']=data['password_hash']
                else:
                    continue
                accounts.append(account); by_id[uid]=account; by_email[email]=account; changed=True; imported.append(uid)
    if changed:
        tmp=accounts_path.with_suffix('.tmp'); tmp.write_text(json.dumps(accounts,ensure_ascii=False,indent=2),encoding='utf8'); os.replace(tmp,accounts_path)
    return {a.get('id'):a for a in accounts if a.get('id')}, imported

def sync_real_stores(base_dir, data_dir, accounts, stores_path):
    boutiques_dir=Path(base_dir)/'boutiques'; stores_path=Path(stores_path); data_dir=Path(data_dir)
    try: stores=json.loads(stores_path.read_text(encoding='utf8') or '[]')
    except Exception: stores=[]
    by_id={s.get('id'):s for s in stores if s.get('id')}; by_name={str(s.get('name','')).lower():s for s in stores}
    imported=[]; changed=False
    for folder in sorted(boutiques_dir.iterdir() if boutiques_dir.exists() else []):
        if not folder.is_dir() or folder.name.startswith('_'): continue
        d=_load_json(folder/'boutique.json')
        if not isinstance(d,dict): continue
        name=str(d.get('name','')).strip()
        sector=str(d.get('sector','boutique')).strip().lower()
        city=str(d.get('city','')).strip()
        owner_id=str(d.get('owner_id','')).strip()
        owner_email=str(d.get('owner_email','')).strip().lower()
        if not name or sector not in SECTORS or not city: continue
        owner=accounts.get(owner_id) or next((a for a in accounts.values() if a.get('email')==owner_email),None)
        if not owner: continue
        sid=str(d.get('id') or ('shop-'+_slug(name)+'-'+hashlib.sha1(str(folder).encode()).hexdigest()[:6]))
        store=by_id.get(sid) or by_name.get(name.lower())
        if store is None:
            store={'id':sid,'name':name,'sector':sector,'city':city,'district':str(d.get('district','')),'address':str(d.get('address','')),'phone':str(d.get('phone','')),'description':str(d.get('description','')),'engine_db':f'db/{sid}.db','open':bool(d.get('open',True)),'owner_id':owner['id']}
            by_id[sid]=store; stores.append(store); changed=True; imported.append(sid)
        else:
            sid=store['id']; store.update({'name':name,'sector':sector,'city':city,'district':str(d.get('district','')),'address':str(d.get('address','')),'phone':str(d.get('phone','')),'description':str(d.get('description','')),'owner_id':owner['id'],'open':bool(d.get('open',True))})
        logo=_find_logo(folder)
        if logo:
            dest = Path(data_dir) / 'media' / 'real' / str(sid)
            dest.mkdir(parents=True, exist_ok=True)
            logo_name = 'logo' + str(logo.suffix).lower()
            shutil.copy2(str(logo), str(dest / logo_name))
            store['logo'] = f'media/real/{sid}/{logo_name}'
            changed = True
        # Keep a stable link to the folder so the seed layer can read its products.
        store['_real_folder']=str(folder.resolve())
    if changed:
        tmp=stores_path.with_suffix('.tmp'); tmp.write_text(json.dumps(stores,ensure_ascii=False,indent=2),encoding='utf8'); os.replace(tmp,stores_path)
    return stores, imported
