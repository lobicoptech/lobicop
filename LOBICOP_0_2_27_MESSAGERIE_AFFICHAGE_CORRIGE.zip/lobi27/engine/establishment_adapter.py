"""Establishment/organization adapter for LOBICOP.

For clinics, schools, agencies, offices, hotels, garages and organizations:
the space presents what the establishment offers and exposes contact,
appointment or registration actions without imposing a marketplace workflow.
"""
from nzela_core_engine import NzelaEngine

ESTABLISHMENT_OPERATIONS={'operations': [
    {'id':'contact_request','kind':'contact_request','name':'Contacter','quantity_mode':'single','fields':[]},
    {'id':'appointment_request','kind':'appointment_request','name':'Prendre rendez-vous','quantity_mode':'single',
     'fields':[{'name':'requested_time','type':'text','required':True,'label':'Date et heure souhaitées'}]},
    {'id':'registration_request','kind':'registration_request','name':'Demande d’inscription','quantity_mode':'single','fields':[]},
]}
ESTABLISHMENT_CATEGORIES=['Accueil','Consultation','Rendez-vous','Inscription','Hébergement','Ateliers','Autres']

class EstablishmentEngine(NzelaEngine):
    def __init__(self, db_path='establishment.db'):
        super().__init__(db_path=db_path, operation_catalog=ESTABLISHMENT_OPERATIONS, default_categories=ESTABLISHMENT_CATEGORIES)
    def add_offering(self, data):
        d=dict(data); d['operation_kind']=d.get('operation_kind') or 'contact_request'
        d['category']=str(d.get('category','Accueil')).strip() or 'Accueil'
        d['stock']=max(1,int(d.get('stock',1)))
        return self.add_product(d)
