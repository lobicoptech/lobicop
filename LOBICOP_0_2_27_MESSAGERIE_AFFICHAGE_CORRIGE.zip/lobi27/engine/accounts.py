"""Comptes acteurs pour NZELA GLOBAL : inscription, connexion, sessions.

Indépendant de l'interface HTTP, comme le moteur métier. Persistance simple
par fichier JSON (aucune dépendance externe), avec verrou pour les accès
concurrents — cohérent avec le reste du projet (stdlib uniquement).

Sécurité : mots de passe hachés avec PBKDF2-HMAC-SHA256 (module hashlib de
la bibliothèque standard), jamais stockés ni journalisés en clair.
"""
import hashlib, hmac, json, os, re, secrets, threading, uuid
from datetime import datetime, timezone
from pathlib import Path

EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
PBKDF2_ITERATIONS = 200_000
SESSION_BYTES = 24

class AccountError(ValueError):
    pass

def _now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def _hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), PBKDF2_ITERATIONS)
    return salt, digest.hex()

def _verify_password(password, salt, expected_hex):
    _, computed = _hash_password(password, salt)
    return hmac.compare_digest(computed, expected_hex)

class AccountStore:
    """Gère les comptes acteurs et leurs sessions actives.

    - accounts.json : liste des comptes (email, nom, mot de passe haché).
    - sessions.json : jetons de session actifs -> account_id, pour que les
      utilisateurs restent connectés même après un redémarrage du serveur.
    """
    def __init__(self, accounts_path, sessions_path):
        self.accounts_path = Path(accounts_path)
        self.sessions_path = Path(sessions_path)
        self.lock = threading.RLock()
        self.accounts_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.accounts_path.exists():
            self.accounts_path.write_text('[]', encoding='utf-8')
        if not self.sessions_path.exists():
            self.sessions_path.write_text('{}', encoding='utf-8')

    def _read_accounts(self):
        return json.loads(self.accounts_path.read_text(encoding='utf-8') or '[]')

    def _write_accounts(self, items):
        tmp = self.accounts_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, self.accounts_path)

    def _read_sessions(self):
        return json.loads(self.sessions_path.read_text(encoding='utf-8') or '{}')

    def _write_sessions(self, items):
        tmp = self.sessions_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, self.sessions_path)

    @staticmethod
    def _public(account):
        return {'id': account['id'], 'name': account['name'], 'email': account['email'], 'created_at': account['created_at'], 'roles': account.get('roles', ['user']), 'is_root': bool(account.get('is_root') or 'root' in account.get('roles', []))}

    def signup(self, name, email, password):
        name = str(name or '').strip()
        email = str(email or '').strip().lower()
        password = str(password or '')
        if not name or len(name) > 120:
            raise AccountError('name_required')
        if not EMAIL_RE.match(email):
            raise AccountError('invalid_email')
        if len(password) < 8:
            raise AccountError('password_too_short')
        with self.lock:
            accounts = self._read_accounts()
            if any(a['email'] == email for a in accounts):
                raise AccountError('email_already_used')
            salt, hashed = _hash_password(password)
            account = {
                'id': 'acc-' + uuid.uuid4().hex[:10],
                'name': name,
                'email': email,
                'salt': salt,
                'password_hash': hashed,
                'created_at': _now(),
                'roles': ['user', 'creator']
            }
            accounts.append(account)
            self._write_accounts(accounts)
            token = self._create_session(account['id'])
        return token, self._public(account)

    def login(self, email, password):
        email = str(email or '').strip().lower()
        password = str(password or '')
        with self.lock:
            accounts = self._read_accounts()
            account = next((a for a in accounts if a['email'] == email), None)
            if not account or not _verify_password(password, account['salt'], account['password_hash']):
                raise AccountError('invalid_credentials')
            token = self._create_session(account['id'])
        return token, self._public(account)

    def _create_session(self, account_id):
        sessions = self._read_sessions()
        token = secrets.token_hex(SESSION_BYTES)
        sessions[token] = {'account_id': account_id, 'created_at': _now()}
        self._write_sessions(sessions)
        return token

    def delete_account(self, account_id):
        account_id = str(account_id or '')
        if not account_id:
            raise AccountError('invalid_account')
        with self.lock:
            accounts = self._read_accounts()
            found = any(a.get('id') == account_id for a in accounts)
            if not found:
                raise AccountError('account_not_found')
            accounts = [a for a in accounts if a.get('id') != account_id]
            self._write_accounts(accounts)
            sessions = self._read_sessions()
            sessions = {k:v for k,v in sessions.items() if v.get('account_id') != account_id}
            self._write_sessions(sessions)
            return {'ok': True}

    def logout(self, token):
        with self.lock:
            sessions = self._read_sessions()
            if token in sessions:
                del sessions[token]
                self._write_sessions(sessions)

    def public_by_id(self, account_id):
        with self.lock:
            accounts = self._read_accounts()
            account = next((a for a in accounts if a.get('id') == account_id), None)
            return self._public(account) if account else None

    def account_for_token(self, token):
        if not token:
            return None
        with self.lock:
            sessions = self._read_sessions()
            session = sessions.get(token)
            if not session:
                return None
            accounts = self._read_accounts()
            account = next((a for a in accounts if a['id'] == session['account_id']), None)
            return self._public(account) if account else None
