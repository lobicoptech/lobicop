"""Service/provider adapter for LOBICOP.

Designed for taxi drivers, technicians, artisans, freelancers and other
providers who publish capabilities/skills and receive service requests.
"""
from nzela_core_engine import NzelaEngine, EngineError

SERVICE_OPERATIONS = {'operations': [
    {'id':'service_request','kind':'service_request','name':'Demande de service','quantity_mode':'single','fields':[]},
    {'id':'booking_request','kind':'booking_request','name':'Rendez-vous','quantity_mode':'single',
     'fields':[{'name':'requested_time','type':'text','required':True,'label':'Date et heure souhaitées'}]},
    {'id':'ride_request','kind':'ride_request','name':'Course / trajet','quantity_mode':'single',
     'fields':[{'name':'pickup','type':'text','required':True,'label':'Départ'}, {'name':'destination','type':'text','required':True,'label':'Destination'}]},
]}

SERVICE_CATEGORIES=['Transport','Réparation','Maison','Beauté','Création','Informatique','Conseil','Livraison','Cours','Autres']

class ServiceEngine(NzelaEngine):
    def __init__(self, db_path='service.db'):
        super().__init__(db_path=db_path, operation_catalog=SERVICE_OPERATIONS, default_categories=SERVICE_CATEGORIES)
    def add_capability(self, data):
        d=dict(data); d['operation_kind']=d.get('operation_kind') or 'service_request'
        d['category']=str(d.get('category','Services')).strip() or 'Services'
        d['stock']=max(1,int(d.get('stock',1)))
        return self.add_product(d)
