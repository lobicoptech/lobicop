# LobiCop — Dossier de données

Ce dossier est volontairement séparé du code du projet.

Une nouvelle version de LobiCop peut utiliser exactement les mêmes données en définissant :

```text
LOBICOP_DATA_DIR=C:\\LobiCop\\DONNEES
```

ou, sous Linux :

```text
LOBICOP_DATA_DIR=/opt/lobicop-data
```

## Contenu

- `accounts.json` : utilisateurs et créateurs
- `sessions.json` : sessions actives
- `stores.json` : espaces/boutiques et leurs propriétaires
- `db/` : bases métier SQLite des espaces
- `media/` : photos, logos, couvertures et futurs fichiers utilisateur
- `profiles/` : dossiers complémentaires de profils/espaces
- `logs/` : journaux persistants
- `manifest.json` : description de la structure et version des données

**Principe : le code peut changer de version sans remplacer ce dossier.**

## Base réelle par dossiers

Une seconde source de données est disponible dans `../base_reelle/` : `boutiques/` et `utilisateurs/`. Elle est destinée aux données réelles que vous ajoutez vous-même. Les modèles sont dans `../modeles_base_reelle/`.
