# Base réelle LobiCop — restaurants du catalogue fourni

Cette base contient les données par dossiers des restaurants importés depuis
`SOURCES/Catalogue_Des_Restaurants_Brazzaville.pdf`.

## Structure

- `boutiques/` : un dossier par boutique/restaurant.
- `utilisateurs/` : un dossier par compte propriétaire.
- `SOURCES/` : copie du document source utilisé pour la génération.

Chaque restaurant possède :
- `boutique.json`
- `description.txt`
- `logo.svg` (logo de démonstration généré à partir de la description textuelle du PDF, pas un logo officiel)
- `produits/`
- un `produit.json` par article
- `visuel_description.txt` par article lorsque le PDF fournit une description visuelle.

## Important

Le PDF décrit le répertoire comme « officieux ». LobiCop conserve ce statut
dans les fiches générées : ces établissements et informations ne sont pas
présentés comme vérifiés par LobiCop.

Le PDF ne donne pas de stock. Les 20 articles sont donc initialisés avec
`stock: 0` et `available: false`. Tu peux modifier ces champs directement
dans chaque `produit.json` pour tester les commandes.

## Comptes propriétaires de démonstration

Les 5 restaurants ont chacun un compte propriétaire généré pour le test.
Le mot de passe initial local de ces comptes est `12345678`.

## Compte root

- identifiant de connexion : `root@lobicop.local`
- nom : `root`
- mot de passe : `12345678`
- rôles : `root`, `admin`, `user`, `creator`

Le mot de passe est stocké haché dans `data/accounts.json`. Le fichier
`base_reelle/utilisateurs/root/utilisateur.json` rappelle le mot de passe
initial de développement afin de faciliter les tests locaux.
