Fiche boutique générée depuis le catalogue fourni.

Source : Catalogue_Des_Restaurants_Brazzaville.pdf
Statut : données officieuses selon le document source.
Propriétaire : Responsable — Grillades & Saveurs du Congo (responsable.grillades-saveurs-du-congo@demo.lobicop.local)

Les stocks ne sont pas indiqués dans le PDF : les produits sont donc initialisés avec stock=0 et indisponibles jusqu'à modification dans produit.json.
