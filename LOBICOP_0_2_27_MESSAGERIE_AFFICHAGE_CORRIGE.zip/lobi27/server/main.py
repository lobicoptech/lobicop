import json, os, re, sys, unicodedata, uuid, threading, time, logging, traceback, io
from pathlib import Path
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'engine'))
from pharmacy_adapter import PharmacyEngine, PHARMACY_CATEGORIES
from restaurant_adapter import RestaurantEngine, RESTAURANT_CATEGORIES
from commerce_adapter import CommerceEngine, COMMERCE_CATEGORIES, COMMERCE_OPERATIONS
from service_adapter import ServiceEngine, SERVICE_CATEGORIES, SERVICE_OPERATIONS
from establishment_adapter import EstablishmentEngine, ESTABLISHMENT_CATEGORIES, ESTABLISHMENT_OPERATIONS
from accounts import AccountStore, AccountError
from messaging import MessagingStore
from folder_database import sync_real_accounts, sync_real_stores

VERSION = '0.2.26'
BRAND = 'LOBICOP alternative'
HOST = os.getenv('NZELA_HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', os.getenv('NZELA_PORT', '8787')))
WEB = ROOT / 'web'
# Dossier de données indépendant du code : toutes les versions peuvent
# réutiliser le même dossier via LOBICOP_DATA_DIR.
_configured_data = os.getenv('LOBICOP_DATA_DIR', '').strip()
DATA = Path(_configured_data).expanduser() if _configured_data else (ROOT / 'data')
if not DATA.is_absolute():
    DATA = (ROOT / DATA).resolve()
STORES_PATH = DATA / 'stores.json'
DEMO_DATA = ROOT / 'demo_data'
REAL_BASE = ROOT / 'base_reelle'
REAL_BASE_BOUTIQUES = REAL_BASE / 'boutiques'
REAL_BASE_USERS = REAL_BASE / 'utilisateurs'
REAL_BASE_BOUTIQUES.mkdir(parents=True, exist_ok=True)
REAL_BASE_USERS.mkdir(parents=True, exist_ok=True)

def _ensure_demo_data():
    if not DEMO_DATA.exists(): return
    try:
        import subprocess
        subprocess.run([sys.executable, str(ROOT / 'tools' / 'import_demo_data.py')], cwd=str(ROOT), check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

_ensure_demo_data()
MEDIA_DIR = DATA / 'media'
DB_DIR = DATA / 'db'
MEDIA_DIR.mkdir(parents=True, exist_ok=True)
DB_DIR.mkdir(parents=True, exist_ok=True)
ACCOUNTS = AccountStore(DATA / 'accounts.json', DATA / 'sessions.json')
# Les dossiers de base_reelle sont une source de données réelle supplémentaire.
# Ils sont importés sans écraser les données existantes.
_REAL_ACCOUNTS, _REAL_USERS_IMPORTED = sync_real_accounts(REAL_BASE, DATA / 'accounts.json')
_REAL_STORES, _REAL_STORES_IMPORTED = sync_real_stores(REAL_BASE, DATA, _REAL_ACCOUNTS, STORES_PATH)
STORES = _REAL_STORES
ENGINES = {}
MESSAGES = MessagingStore(DATA / 'messages.db')
ENGINES_LOCK = threading.RLock()
STORES_LOCK = threading.RLock()
MAX_BODY = 12_000_000
EVENT_COND = threading.Condition()
EVENT_SEQ = 0
EVENTS = []

# =====================================================================
# JOURNALISATION (logs) — pour diagnostiquer le système soi-même.
# Tout ce qui se passe (requêtes, erreurs, démarrage) est écrit à la fois
# dans le terminal ET dans server/server.log, que l'on peut consulter
# avec :  python3 tools/nzela_cli.py logs
# Réglage du détail avec NZELA_LOG_LEVEL : DEBUG, INFO (défaut), WARNING.
# =====================================================================
LOG_LEVEL = os.getenv('NZELA_LOG_LEVEL', 'INFO').upper()
LOG_PATH = DATA / 'logs' / 'server.log'
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.FileHandler(LOG_PATH, encoding='utf-8'),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger('lobicop')

def publish_event(store_id, event_type, payload):
    global EVENT_SEQ
    with EVENT_COND:
        EVENT_SEQ += 1
        evt={'id':EVENT_SEQ,'store_id':store_id,'type':event_type,'payload':payload,'created_at':time.time()}
        EVENTS.append(evt)
        if len(EVENTS)>500: del EVENTS[:-500]
        EVENT_COND.notify_all()

def _event_matches(e, store_id, ids, account_id, event_types=None):
    return (store_id is None or e['store_id']==store_id) and (not ids or e['payload'].get('request_id') in ids) and (account_id is None or e['payload'].get('account_id')==account_id) and (not event_types or e['type'] in event_types)

def events_since(last_id, store_id=None, request_ids=None, account_id=None, event_types=None):
    ids=set(request_ids or [])
    with EVENT_COND:
        return [e for e in EVENTS if e['id']>last_id and _event_matches(e, store_id, ids, account_id, event_types)]

def wait_events(last_id, store_id=None, request_ids=None, account_id=None, timeout=15, event_types=None):
    """Attend un nouvel événement SANS jamais en rater un.
    Avant, le flux regardait s'il y avait du nouveau, puis se mettait en
    attente : un événement publié pile entre les deux n'était remarqué
    qu'au prochain battement (jusqu'à 15 s plus tard). Ici la vérification
    et l'attente se font sous le même verrou (wait_for), donc c'est impossible.
    Renvoie (dernier_id_vu, événements_pour_ce_flux)."""
    ids=set(request_ids or [])
    with EVENT_COND:
        EVENT_COND.wait_for(lambda: EVENT_SEQ>last_id, timeout=timeout)
        head=EVENT_SEQ
        return head, [e for e in EVENTS if last_id<e['id']<=head and _event_matches(e, store_id, ids, account_id, event_types)]

# Registre des adaptateurs : trois familles principales (boutique, prestataire,
# établissement) + profils spécialisés conservés pour pharmacie/restaurant.
# Ajouter un secteur consiste à sélectionner un adaptateur sans réécrire CORE.
# à le déclarer ici — le moteur générique et la couche GLOBAL n'ont pas à
# changer, conformément à l'architecture du livre blanc NZELA (section 9).
ADAPTERS = {
    'boutique': {
        'label': 'Boutique / commerce',
        'description': 'Produits, vendeurs en ligne, producteurs, artisans et restaurants.',
        'engine': CommerceEngine,
        'categories': COMMERCE_CATEGORIES,
        'operations': COMMERCE_OPERATIONS,
    },
    'prestataire': {
        'label': 'Prestataire / service',
        'description': 'Compétences, capacités et demandes de service, transport ou rendez-vous.',
        'engine': ServiceEngine,
        'categories': SERVICE_CATEGORIES,
        'operations': SERVICE_OPERATIONS,
    },
    'etablissement': {
        'label': 'Établissement / organisation',
        'description': 'Écoles, cliniques, hôtels, garages, agences, bureaux et organisations.',
        'engine': EstablishmentEngine,
        'categories': ESTABLISHMENT_CATEGORIES,
        'operations': ESTABLISHMENT_OPERATIONS,
    },
}

SECTOR_ENGINES = {
    'pharmacie': PharmacyEngine,
    'parapharmacie': PharmacyEngine,
    'restaurant': RestaurantEngine,
    'boutique': CommerceEngine,
    'commerce': CommerceEngine,
    'vendeur-en-ligne': CommerceEngine,
    'prestataire': ServiceEngine,
    'taxi': ServiceEngine,
    'service': ServiceEngine,
    'etablissement': EstablishmentEngine,
    'hotel': EstablishmentEngine,
    'ecole': EstablishmentEngine,
    'clinique': EstablishmentEngine,
    'agence': EstablishmentEngine,
}
SECTOR_CATEGORIES = {
    'pharmacie': PHARMACY_CATEGORIES, 'parapharmacie': PHARMACY_CATEGORIES,
    'restaurant': RESTAURANT_CATEGORIES, 'boutique': COMMERCE_CATEGORIES,
    'commerce': COMMERCE_CATEGORIES, 'vendeur-en-ligne': COMMERCE_CATEGORIES,
    'prestataire': SERVICE_CATEGORIES, 'taxi': SERVICE_CATEGORIES, 'service': SERVICE_CATEGORIES,
    'etablissement': ESTABLISHMENT_CATEGORIES, 'hotel': ESTABLISHMENT_CATEGORIES,
    'ecole': ESTABLISHMENT_CATEGORIES, 'clinique': ESTABLISHMENT_CATEGORIES, 'agence': ESTABLISHMENT_CATEGORIES,
}
SECTOR_LABELS = {
    'pharmacie':'Pharmacie','parapharmacie':'Parapharmacie','restaurant':'Restaurant',
    'boutique':'Boutique','commerce':'Commerce','vendeur-en-ligne':'Vendeur en ligne',
    'prestataire':'Prestataire','taxi':'Taxi','service':'Service',
    'etablissement':'Établissement','hotel':'Hôtel','ecole':'École','clinique':'Clinique','agence':'Agence',
}
ADAPTER_BY_SECTOR = {
    **{k:'boutique' for k in ['restaurant','boutique','commerce','vendeur-en-ligne','pharmacie','parapharmacie']},
    **{k:'prestataire' for k in ['prestataire','taxi','service']},
    **{k:'etablissement' for k in ['etablissement','hotel','ecole','clinique','agence']},
}

def engine_class_for(store):
    return SECTOR_ENGINES.get(str(store.get('sector', '')).lower(), CommerceEngine)

def resolve_store_db_path(store):
    raw = str(store.get('engine_db', '')).strip()
    if not raw:
        raise ValueError('store_db_missing')
    p = Path(raw).expanduser()
    if not p.is_absolute():
        # Compatibilité avec les anciennes fiches qui contiennent data/<id>.db.
        if raw.startswith('data/') or raw.startswith('data\\'):
            rel = raw[5:]
        else:
            rel = raw
        p = DATA / rel
    p = p.resolve()
    data_root = DATA.resolve()
    if p != data_root and data_root not in p.parents:
        raise ValueError('invalid_store_db')
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def engine_for(store):
    sid = store['id']
    eng = ENGINES.get(sid)
    if eng is not None: return eng
    with ENGINES_LOCK:  # deux requêtes simultanées ne doivent pas créer/semer deux fois le même moteur
        eng = ENGINES.get(sid)
        if eng is None:
            eng = engine_class_for(store)(resolve_store_db_path(store))
            seed_store(eng, sid)
            ENGINES[sid] = eng
        return eng

def add_store_product(store, data):
    e = engine_for(store)
    sector = str(store.get('sector','')).lower()
    kind = str(data.get('operation_kind') or '').strip()
    if sector == 'restaurant':
        if kind == 'reservation_request': return e.add_reservation_slot(data)
        return e.add_menu_item(data)
    if sector in ('pharmacie','parapharmacie'):
        if kind == 'prescription_request': return e.add_prescription_product(data)
        return e.add_pharmacy_product(data)
    if sector in ('prestataire','taxi','service'):
        return e.add_capability(data)
    if sector in ('etablissement','hotel','ecole','clinique','agence'):
        return e.add_offering(data)
    if isinstance(e, CommerceEngine):
        return e.add_item(data)
    return e.add_product(data)


def seed_store(engine, sid):
    if engine.products(): return
    seeds = {
      'shop-pharmacie-centre': [
        ('Paracétamol 500 mg','Médicaments',1500,40,'Produit catalogue.','pharmacy_product'),
        ('Vitamine C','Vitamines et bien-être',3500,25,'Produit catalogue.','pharmacy_product'),
        ('Gel douche','Hygiène',2800,30,'Produit de parapharmacie.','pharmacy_product'),
        ('Crème hydratante','Dermocosmétique',4500,18,'Produit de soin.','pharmacy_product'),
        ('Produit sur ordonnance','Médicaments',0,12,'Demande soumise avec référence d’ordonnance.','prescription_request')],
      'shop-pharma-moungali': [
        ('Ibuprofène 200 mg','Médicaments',1800,35,'Produit catalogue.','pharmacy_product'),
        ('Sirop','Médicaments',3000,20,'Produit catalogue.','pharmacy_product'),
        ('Savon doux','Hygiène',1200,50,'Produit d’hygiène.','pharmacy_product'),
        ('Demande avec ordonnance','Médicaments',0,10,'Demande soumise avec référence d’ordonnance.','prescription_request')],
      'shop-pharma-poto': [
        ('Thermomètre','Dispositifs médicaux',5000,12,'Dispositif médical catalogue.','pharmacy_product'),
        ('Lait bébé','Soins bébé',4200,20,'Produit bébé.','pharmacy_product')],
      'shop-parapharma': [
        ('Lait corps','Dermocosmétique',6500,20,'Soin corporel.','pharmacy_product'),
        ('Gel nettoyant','Hygiène',3800,25,'Produit d’hygiène.','pharmacy_product'),
        ('Crème solaire','Dermocosmétique',7500,15,'Produit de soin.','pharmacy_product')],
      'shop-resto-centre': [
        ('Poulet braisé','Plats',4500,30,'Poulet braisé, sauce maison.','menu_item'),
        ('Poisson salé','Plats',5500,20,'Poisson braisé aux légumes.','menu_item'),
        ('Attiéké','Accompagnements',1500,40,'Portion d’attiéké.','menu_item'),
        ('Jus de bissap','Boissons',1000,50,'Boisson locale rafraîchissante.','menu_item'),
        ('Table pour le soir','Réservations',0,20,'Réservation d’une table.','reservation_request')],
      'shop-resto-bacongo': [
        ('Saka-saka','Plats',3500,25,'Feuilles de manioc, riz.','menu_item'),
        ('Brochettes','Plats',3000,30,'Brochettes de bœuf grillées.','menu_item'),
        ('Bière locale','Boissons',1500,40,'Boisson fraîche.','menu_item')],
      'shop-boutique-kivu-market': [
        ('T-shirt coton','Mode',8500,18,'Article disponible en commande en ligne.','product_order'),
        ('Sac artisanal','Artisanat',12000,8,'Sac fabriqué localement.','product_order'),
        ('Lampe LED','Maison',6500,12,'Produit maison et équipement.','product_order')],
      'shop-taxi-brazza-rapide': [
        ('Course urbaine','Transport',0,50,'Demande de course avec départ et destination.','ride_request'),
        ('Transport colis','Livraison',0,20,'Transport de petit colis.','service_request')],
      'shop-centre-sante-lumiere': [
        ('Consultation générale','Consultation',0,20,'Demande de rendez-vous auprès de l’établissement.','appointment_request'),
        ('Accueil','Accueil',0,30,'Demande de contact avec l’établissement.','contact_request')]
    }
    # Si cette boutique vient de base_reelle/boutiques/, ses produits sont
    # lus depuis les dossiers produits réels, jamais inventés par le serveur.
    real_folder = next((x.get('_real_folder') for x in STORES if x.get('id') == sid and x.get('_real_folder')), None)
    if real_folder:
        products_dir = Path(real_folder) / 'produits'
        if products_dir.exists():
            for pf in sorted(products_dir.iterdir()):
                if not pf.is_dir() or pf.name.startswith('_'): continue
                pdata = None
                for jf in ('produit.json','product.json'):
                    q = pf / jf
                    if q.exists():
                        try: pdata=json.loads(q.read_text(encoding='utf-8'))
                        except Exception: pdata=None
                        break
                if not isinstance(pdata, dict): continue
                pdata.pop('id', None)
                image = pdata.get('image')
                if image and not str(image).startswith('data:'):
                    ip = pf / str(image)
                    pdata['image_data'] = __import__('folder_database')._image_data(ip)
                if 'image_data' not in pdata:
                    for nm in ('image.png','image.jpg','image.jpeg','image.webp','image.svg'):
                        ip=pf/nm
                        if ip.exists():
                            pdata['image_data']=__import__('folder_database')._image_data(ip); break
                try: engine.add_product(pdata)
                except Exception: log.warning('Produit réel ignoré dans %s', pf)
            if engine.products(): return
    demo_file = ROOT / 'demo_data' / 'products' / f'{sid}.json'
    if demo_file.exists():
        for item in json.loads(demo_file.read_text(encoding='utf-8')): engine.add_product(item)
        return
    for name,cat,price,stock,desc,kind in seeds.get(sid,[]):
        engine.add_product({'name':name,'category':cat,'price':price,'stock':stock,'description':desc,'operation_kind':kind})

def public_store(s):
    d = dict(s); d.pop('engine_db', None); d.pop('_real_folder', None)
    sector=str(s.get('sector','')).lower()
    d['sector_label'] = SECTOR_LABELS.get(sector, sector.capitalize())
    d['adapter'] = ADAPTER_BY_SECTOR.get(sector, 'boutique')
    d['adapter_label'] = ADAPTERS[d['adapter']]['label']
    if d.get('logo'): d['logo'] = '/' + str(d['logo']).lstrip('/')
    return d

def save_stores():
    tmp = STORES_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(STORES, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, STORES_PATH)

def slugify(text):
    text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
    text = re.sub(r'[^a-zA-Z0-9]+', '-', text).strip('-').lower()
    return text or 'espace'

def create_space(account, data):
    name = str(data.get('name', '')).strip()
    sector = str(data.get('sector', '')).strip().lower()
    city = str(data.get('city', '')).strip()
    district = str(data.get('district', '')).strip()
    address = str(data.get('address', '')).strip()
    phone = str(data.get('phone', '')).strip()
    description = str(data.get('description', '')).strip()
    if not name or len(name) > 120: raise ValueError('name_required')
    if sector not in SECTOR_ENGINES: raise ValueError('invalid_sector')
    if not city: raise ValueError('city_required')
    sid = f"shop-{slugify(name)}-{uuid.uuid4().hex[:6]}"
    store = {
        'id': sid, 'name': name, 'sector': sector, 'city': city, 'district': district,
        'address': address, 'phone': phone, 'description': description,
        'engine_db': f'db/{sid}.db', 'open': True, 'owner_id': account['id'],
    }
    # Crée aussi le dossier métier correspondant : il devient la fiche réelle
    # que l'utilisateur peut ensuite copier, compléter et archiver.
    real_folder = REAL_BASE_BOUTIQUES / sid
    (real_folder / 'produits').mkdir(parents=True, exist_ok=True)
    (real_folder / 'boutique.json').write_text(json.dumps({k:v for k,v in store.items() if k != 'engine_db'}, ensure_ascii=False, indent=2), encoding='utf-8')
    (real_folder / 'description.txt').write_text(description + '\n', encoding='utf-8')
    user_folder = REAL_BASE_USERS / account['id']
    user_folder.mkdir(parents=True, exist_ok=True)
    user_file = user_folder / 'utilisateur.json'
    if not user_file.exists():
        user_file.write_text(json.dumps({'id':account['id'],'name':account.get('name',''),'email':account.get('email',''),'roles':account.get('roles',['user','creator'])}, ensure_ascii=False, indent=2), encoding='utf-8')
    engine_for(store)  # crée d'abord le moteur/la base : si cela échoue, rien n'est enregistré
    with STORES_LOCK:
        STORES.append(store)
        try: save_stores()
        except Exception:
            STORES.remove(store); ENGINES.pop(sid, None); raise
    return store

IDENTITY_LIMITS = {'name':120,'slogan':200,'description':2000,'phone':40,'address':300,'hours':200,'logo_data':3_000_000,'cover_data':6_000_000}
def update_identity(store, data):
    updates = {}
    for k, limit in IDENTITY_LIMITS.items():
        if k not in data: continue
        v = str(data[k] or '').strip()
        if k == 'name' and not v: raise ValueError('name_required')
        if len(v) > limit: raise ValueError(k + '_too_long')
        if k in ('logo_data','cover_data') and v and not v.startswith('data:image/'): raise ValueError('invalid_image')
        updates[k] = v
    with STORES_LOCK:
        store.update(updates)
        save_stores()

def send(h, code, obj):
    b=json.dumps(obj,ensure_ascii=False).encode()
    try:
        h.send_response(code); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Cache-Control','no-store'); h.send_header('Access-Control-Allow-Origin','*'); h.send_header('Content-Length',str(len(b))); h.end_headers(); h.wfile.write(b)
    except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError):
        return None


def selected_store(query):
    sid=_qget(query, 'store')
    if sid:
        return next((s for s in STORES if s['id']==sid), None)
    return STORES[0] if STORES else None

def operation_catalog_for(store):
    if not store: return {'operations':[]}
    try: return engine_for(store).operation_catalog
    except Exception: return {'operations':[]}

def public_identity(store):
    if not store: return {'name':BRAND,'slogan':'','sector':'','city':'','district':'','address':'','phone':'','hours':'','description':''}
    return {
        'name': store.get('name',BRAND),
        'slogan': store.get('slogan',''),
        'sector': store.get('sector',''),
        'sector_label': SECTOR_LABELS.get(str(store.get('sector','')).lower(), str(store.get('sector','')).capitalize()),
        'city': store.get('city',''),
        'district': store.get('district',''),
        'address': store.get('address',''),
        'phone': store.get('phone',''),
        'hours': store.get('hours',''),
        'description': store.get('description',''),
        # Public identity must expose the persisted logo so the admin and client
        # can render the same restaurant/boutique profile image.
        'logo_data': store.get('logo_data',''),
        'cover_data': store.get('cover_data',''),
        'store_id': store.get('id','')
    }

def find_request_engine(request_id, preferred=None):
    candidates=[]
    if preferred: candidates.append(preferred)
    candidates.extend(s for s in STORES if s not in candidates)
    for store in candidates:
        try: return store, engine_for(store), engine_for(store).get_request(request_id)
        except Exception: pass
    return None,None,None

def _qget(query, key):
    """Lit un paramètre d'URL en acceptant les DEUX formats utilisés dans ce
    fichier : un dict issu de parse_qs (chaque valeur est une LISTE, chemin
    historique do_GET/do_POST) ou un MultiDict Flask (request.args, où
    .get() renvoie directement la chaîne). Les confondre faisait extraire un
    seul caractère de la valeur côté Flask (ex: query.get('token',[''])[0]
    prenait la 1re LETTRE de la chaîne au lieu du 1er élément d'une liste) —
    d'où l'échec silencieux de l'authentification sur les flux temps réel
    natifs Flask (/api/admin/stream) quand le jeton ou la boutique arrivait
    en paramètre d'URL plutôt qu'en en-tête."""
    v = query.get(key)
    if isinstance(v, list):
        v = v[0] if v else ''
    return (v or '').strip()

def bearer_token(handler, query=None):
    auth = handler.headers.get('Authorization', '')
    if auth.startswith('Bearer '): return auth[7:].strip()
    if query:
        return _qget(query, 'token') or None
    return None

def current_account(handler, query=None):
    token=bearer_token(handler,query)
    return ACCOUNTS.account_for_token(token) if token else None

def read_json_body(handler):
    n = int(handler.headers.get('Content-Length', '0') or '0')
    if n < 0 or n > MAX_BODY: raise ValueError('payload_too_large')
    raw = handler.rfile.read(n) if n else b''
    data = json.loads(raw.decode('utf-8') or '{}')
    if not isinstance(data, dict): raise ValueError('invalid_json')
    return data

def public_tracking(r):
    """Vue publique d'une commande (suivi par numéro) : aucune donnée personnelle."""
    return {'id':r['id'],'queue_number':r['queue_number'],'total':r['total'],'status':r['status'],
            'channel':r.get('channel'),'created_at':r['created_at'],'updated_at':r['updated_at'],
            'items':[{'name':i.get('name'),'quantity':i.get('quantity')} for i in r.get('items',[])]}

def _alias(path):
    # Anciennes URL utilisées par l'espace entreprise -> routes /api/admin/...
    for a, b in (('/api/highlights','/api/admin/highlights'),('/api/announcements','/api/admin/announcements')):
        if path == a or path.startswith(a + '/'): return b + path[len(a):]
    return path

def owner_store(account, query):
    if not account: return None
    sid=_qget(query, 'store')
    # Le compte root peut administrer n'importe quelle boutique réelle.
    # Sans ?store=..., on conserve le comportement historique en ouvrant
    # la première boutique disponible.
    is_root = bool(account.get('is_root') or 'root' in account.get('roles', []))
    if is_root:
        if sid:
            return next((s for s in STORES if s['id']==sid), None)
        return STORES[0] if STORES else None
    owned=[s for s in STORES if s.get('owner_id')==account.get('id')]
    if sid:
        return next((s for s in owned if s['id']==sid), None)
    return owned[0] if owned else None

def admin_auth(handler, query):
    account=current_account(handler, query)
    return account, owner_store(account, query)

def public_request(r):
    d=dict(r); d.pop('customer_account_id',None); return d

def public_message(m):
    return {'id':m['id'],'conversation_id':m['conversation_id'],'sender_id':m['sender_id'],'body':m['body'],'created_at':m['created_at'],'read_at':m.get('read_at')}

def public_conversation(c, account_id):
    d={k:c.get(k) for k in ('id','kind','store_id','created_at','updated_at','last_body','last_message_at','other_id')}
    d['unread_count']=0
    if not d.get('other_id') and d.get('id'):
        try:
            with MESSAGES.lock, MESSAGES._db() as db:
                row=db.execute('SELECT account_id FROM participants WHERE conversation_id=? AND account_id<>?',(d['id'],account_id)).fetchone()
                d['other_id']=row['account_id'] if row else None
        except Exception:
            d['other_id']=None
    try:
        with MESSAGES.lock, MESSAGES._db() as db:
            row=db.execute('SELECT COUNT(*) AS n FROM messages WHERE conversation_id=? AND sender_id<>? AND read_at IS NULL',(d.get('id'),account_id)).fetchone()
            d['unread_count']=int(row['n'] if row else 0)
    except Exception:
        d['unread_count']=0
    other=ACCOUNTS.public_by_id(d.get('other_id')) if d.get('other_id') else None
    d['other']=other
    if d.get('store_id'):
        st=next((x for x in STORES if x.get('id')==d['store_id']),None)
        d['store']=public_store(st) if st else None
    return d

def message_recipient_ids(conversation_id, sender_id):
    with MESSAGES.lock, MESSAGES._db() as db:
        rows=db.execute('SELECT account_id FROM participants WHERE conversation_id=? AND account_id<>?',(conversation_id,sender_id)).fetchall()
        return [r['account_id'] for r in rows]

def publish_message_events(message, participants):
    for aid in participants:
        publish_event(None,'message_created',{'account_id':aid,'conversation_id':message['conversation_id'],'message':public_message(message)})

def sse(handler, store_id, request_ids=None, account_id=None, event_types=None):
    """Flux temps réel (Server-Sent Events).

    Règles importantes :
    - Une NOUVELLE connexion repart de « maintenant » : elle ne rejoue pas les
      anciens événements (avant, chaque reconnexion rejouait jusqu'à 500
      événements, d'où de fausses « nouvelle commande » et des rafales de
      rechargements). Ce que la page a pu manquer, elle le récupère elle-même
      avec /api/admin/requests dès que le flux s'ouvre.
    - Une reconnexion automatique du navigateur (en-tête Last-Event-ID)
      reprend, elle, exactement là où elle s'était arrêtée.
    - Fermer un onglet coupe la connexion à tout moment (OSError, y compris
      ConnectionAbortedError sous Windows) : c'est normal, on s'arrête
      proprement sans traceback.
    """
    with EVENT_COND:
        last=EVENT_SEQ
    given=(handler.headers.get('Last-Event-ID','') or '').strip()
    if given:
        try: last=min(int(given), last)
        except Exception: pass
    try:
        handler.send_response(200)
        handler.send_header('Content-Type','text/event-stream; charset=utf-8')
        handler.send_header('Cache-Control','no-cache, no-transform')
        handler.send_header('Connection','keep-alive')
        handler.send_header('X-Accel-Buffering','no')  # empêche un proxy (nginx...) de retenir le flux
        handler.send_header('Access-Control-Allow-Origin','*')
        handler.end_headers()
        handler.wfile.write(b'retry: 2000\n: connected\n\n'); handler.wfile.flush()
    except OSError:
        return  # le client a déjà fermé la connexion avant même de recevoir la réponse
    while True:
        head,batch=wait_events(last, store_id, request_ids, account_id, timeout=15, event_types=event_types)
        try:
            if batch:
                for evt in batch:
                    payload=json.dumps({'type':evt['type'],**{k:v for k,v in evt['payload'].items() if k!='account_id'}},ensure_ascii=False)
                    handler.wfile.write(f"id: {evt['id']}\ndata: {payload}\n\n".encode())
            else:
                handler.wfile.write(b': heartbeat\n\n')  # garde la connexion vivante
            handler.wfile.flush()
        except OSError:
            return  # connexion fermée par le client : on arrête proprement
        last=head

class Handler(BaseHTTPRequestHandler):
    server_version=f'LOBICOP/{VERSION}'
    def log_message(self, fmt, *args):
        msg = re.sub(r'(token=)[^&\s"]+', r'\1***', fmt % args)  # ne jamais écrire un jeton de session dans les journaux
        log.info('%s - %s', self.address_string(), msg)

    def log_error(self, fmt, *args):
        log.warning('%s - %s', self.address_string(), fmt % args)

    def handle_error(self, request, client_address):
        """Appelé par Python quand une exception non rattrapée survient
        pendant le traitement d'une requête. Une connexion coupée par le
        client (onglet fermé, page rechargée) est un événement NORMAL, pas
        un bug — on l'écrit en une ligne discrète plutôt que de vider un
        traceback complet dans les journaux à chaque fois."""
        exc_type = sys.exc_info()[0]
        if exc_type and issubclass(exc_type, OSError):
            log.info('(connexion interrompue par le client %s — normal, rien à corriger)', client_address)
            return
        super().handle_error(request, client_address)

    def _safe(self, handler_name, fn):
        """Filet de sécurité : si une route plante de façon inattendue (bug
        non prévu), on l'écrit clairement dans le journal au lieu de laisser
        le serveur planter en silence, et le client reçoit une erreur 500
        propre plutôt qu'une connexion coupée sans explication."""
        try:
            log.debug('%s %s', handler_name, self.path)
            fn()
        except Exception:
            log.error('Erreur non gérée dans %s %s :\n%s', handler_name, self.path, traceback.format_exc())
            try:
                send(self, 500, {'error': 'internal_error'})
            except Exception:
                pass

    def do_GET(self): self._safe('GET', self._do_GET)
    def do_POST(self): self._safe('POST', self._do_POST)
    def do_PUT(self): self._safe('PUT', self._do_PUT)
    def do_DELETE(self): self._safe('DELETE', self._do_DELETE)

    def _do_GET(self):
        p=urlparse(self.path); raw_path=p.path or '/'; path=raw_path.rstrip('/') or '/'
        query=parse_qs(p.query)
        store=selected_store(query)
        # Compatibility API for the immersive interface. It exposes the same
        # business space through the reference world's UI without duplicating
        # business state or creating a second engine.
        if path == '/api/identity': return send(self,200,{'identity':public_identity(store)})
        if path == '/api/config': return send(self,200,{'enterprise':public_identity(store),'identity':public_identity(store),'operation_catalog':operation_catalog_for(store)})
        if path == '/api/products': return send(self,200,{'items':engine_for(store).products() if store else []})
        if path == '/api/highlights':
            items=engine_for(store).highlights() if store else []
            if not items and store:
                products=engine_for(store).products(); items=[{'id':'ice-'+p['id'],'title':p['name'],'subtitle':p.get('category') or 'Offre','description':p.get('description') or '','kind':'product','product_id':p['id'],'cta':'Découvrir','active':1,'priority':100-i} for i,p in enumerate(products[:3])]
            return send(self,200,{'items':[x for x in items if x.get('active',1)]})
        if path == '/api/announcements':
            viewer=current_account(self,query)
            return send(self,200,{'items':engine_for(store).announcements(viewer['id'] if viewer else None) if store else []})
        if path == '/api/auth/me':
            account = current_account(self)
            return send(self,200,{'account':account}) if account else send(self,401,{'error':'not_authenticated'})
        if path == '/api/sector-catalog':
            sector = _qget(query, 'sector').lower()
            return send(self,200,{'categories': SECTOR_CATEGORIES.get(sector, [])})
        if path == '/api/events/stream':
            store_id=_qget(query, 'store') or None
            raw_ids=_qget(query, 'request_ids')
            request_ids=[x for x in raw_ids.split(',') if x]
            if not request_ids: return send(self,400,{'error':'request_ids_required'})
            return sse(self, store_id, request_ids)
        if path == '/api/accounts/search':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            q=_qget(query, 'q').lower()
            if len(q)<2: return send(self,200,{'items':[]})
            # Le store d'identité reste la source unique des comptes. Les résultats
            # n'exposent jamais les données sensibles de session/mot de passe.
            matches=[]
            for st in ACCOUNTS._read_accounts():
                if st.get('id')==account['id']: continue
                if q in st.get('name','').lower() or q in st.get('email','').lower():
                    matches.append(ACCOUNTS._public(st))
                if len(matches)>=20: break
            return send(self,200,{'items':matches})
        if path == '/api/messages/conversations':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            return send(self,200,{'items':[public_conversation(x,account['id']) for x in MESSAGES.conversations(account['id'])]})
        if path.startswith('/api/messages/conversations/') and path.endswith('/read'):
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            cid=path.split('/')[4]
            try:
                MESSAGES.mark_read(cid,account['id'])
                return send(self,200,{'ok':True})
            except PermissionError: return send(self,403,{'error':'conversation_forbidden'})
            except Exception as e: return send(self,404,{'error':str(e)})
        if path.startswith('/api/messages/conversations/') and path.endswith('/messages'):
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            cid=path.split('/')[4]
            try: return send(self,200,{'items':MESSAGES.messages(cid,account['id'])})
            except PermissionError: return send(self,403,{'error':'conversation_forbidden'})
            except Exception as e: return send(self,404,{'error':str(e)})
        if path == '/api/messages/stream':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            return sse(self,None,None,account['id'],event_types={'message_created'})
        if path == '/api/my/stream':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            return sse(self,None,None,account['id'])
        if path == '/api/my/stores':
            account=current_account(self)
            if not account: return send(self,401,{'error':'authentication_required'})
            return send(self,200,{'items':[public_store(st) for st in STORES if st.get('owner_id')==account['id']]})
        if path == '/api/my/requests':
            account=current_account(self)
            if not account: return send(self,401,{'error':'authentication_required'})
            items=[]
            for st in STORES:
                try: items.extend(engine_for(st).requests_for_account(account['id']))
                except Exception: pass
            items.sort(key=lambda x:x.get('created_at',''),reverse=True)
            return send(self,200,{'items':[public_request(x) for x in items[:100]]})
        if path == '/api/admin/context':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'account':account,'store':public_store(ast)})
        if path == '/api/admin/requests':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'items':[public_request(x) for x in engine_for(ast).requests()]})
        if path.startswith('/api/admin/requests/'):
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            rid=path.rsplit('/',1)[-1]
            try:
                item=engine_for(ast).get_request(rid)
            except Exception:
                item=None
            return send(self,200,public_request(item)) if item else send(self,404,{'error':'request_not_found'})
        if path == '/api/admin/stream':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return sse(self,ast['id'])
        if path == '/api/stats':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'counts':engine_for(ast).stats()})
        if path == '/api/categories':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'items':engine_for(ast).categories()})
        if path == '/api/admin/highlights':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'items':engine_for(ast).highlights()})
        if path == '/api/admin/announcements':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'items':engine_for(ast).announcements()})
        if path == '/api/requests':
            account,ast=admin_auth(self,query)  # contient noms et téléphones des clients : propriétaire uniquement
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            return send(self,200,{'items':[public_request(x) for x in engine_for(ast).requests()]})
        if path.startswith('/api/requests/'):
            rid=path.split('/')[-1]
            st,e,r=find_request_engine(rid,store)
            return send(self,200,public_tracking(r)) if r else send(self,404,{'error':'request_not_found'})
        if path == '/api/health': return send(self,200,{'ok':True,'version':VERSION})
        if path == '/api/adapters':
            items=[]
            for aid,a in ADAPTERS.items():
                items.append({'id':aid,'label':a['label'],'description':a['description'],'categories':a['categories'],'operations':[o['kind'] for o in a['operations']['operations']]})
            return send(self,200,{'items':items})
        if path.startswith('/api/adapters/'):
            aid=path.split('/')[-1]
            if aid not in ADAPTERS: return send(self,404,{'error':'adapter_not_found'})
            a=ADAPTERS[aid]
            return send(self,200,{'id':aid,'label':a['label'],'description':a['description'],'categories':a['categories'],'operation_catalog':a['operations']})
        if path == '/api/sectors':
            items=[{'id':sid,'label':SECTOR_LABELS.get(sid,sid.capitalize())} for sid in sorted(SECTOR_ENGINES)]
            return send(self,200,{'items':items})
        if path == '/api/search':
            q=parse_qs(p.query); raw=q.get('q',[''])[0].strip().lower(); text=''.join(c for c in unicodedata.normalize('NFD',raw) if unicodedata.category(c)!='Mn')
            items=[]
            broad=text in {'produit','produits','boutique','boutiques','commerce','commerces','service','services'}
            for s in STORES:
                hay=' '.join([s['name'],s['sector'],s['city'],s['district'],s['address'],s['description']]).lower(); hay=''.join(c for c in unicodedata.normalize('NFD',hay) if unicodedata.category(c)!='Mn')
                if broad or (text and text in hay):
                    items.append(public_store(s)); continue
                if not text: continue
                try:
                    e=engine_for(s)
                    if any(text in ''.join(c for c in unicodedata.normalize('NFD',' '.join([str(x.get('name','')),str(x.get('category','')),str(x.get('description',''))]).lower()) if unicodedata.category(c)!='Mn') for x in e.products()):
                        items.append(public_store(s))
                except Exception: pass
            return send(self,200,{'items':items,'count':len(items)})
        if path == '/api/stores':
            q=parse_qs(p.query); raw=q.get('q',[''])[0].strip().lower(); text=''.join(c for c in unicodedata.normalize('NFD',raw) if unicodedata.category(c)!='Mn'); sector=q.get('sector',[''])[0].strip().lower(); city=q.get('city',[''])[0].strip().lower()
            items=[]
            for s in STORES:
                hay=' '.join([s['name'],s['sector'],s['city'],s['district'],s['address']]).lower()
                if text and text not in hay: continue
                if sector and s['sector'].lower()!=sector: continue
                if city and s['city'].lower()!=city: continue
                items.append(public_store(s))
            return send(self,200,{'items':items,'count':len(items)})
        if path.startswith('/api/stores/'):
            parts=path.split('/')
            sid=parts[3] if len(parts)>3 else ''
            store=next((s for s in STORES if s['id']==sid),None)
            if not store: return send(self,404,{'error':'store_not_found'})
            if len(parts)==4: return send(self,200,{'store':public_store(store)})
            if parts[4]=='catalog':
                e=engine_for(store)
                sector=str(store.get('sector','')).lower()
                return send(self,200,{'store':public_store(store),'categories':e.categories(),'products':e.products(),'sector_categories':SECTOR_CATEGORIES.get(sector,[])})
            if parts[4]=='requests':
                account=current_account(self,query)
                if not account: return send(self,401,{'error':'authentication_required'})
                if account['id']!=store.get('owner_id'): return send(self,403,{'error':'not_space_owner'})
                return send(self,200,{'items':[public_request(x) for x in engine_for(store).requests()]})
        if path == '/admin.html': return self.file('/web/admin.html','text/html; charset=utf-8')
        if path == '/': return self.file('/web/index.html','text/html; charset=utf-8')
        if raw_path == '/boutique':
            self.send_response(301); self.send_header('Location','/boutique/'); self.end_headers(); return
        if raw_path == '/boutique/':
            return self.file('/web/boutique/index.html','text/html; charset=utf-8')
        if path == '/taxi': return self.file('/web/taxi.html','text/html; charset=utf-8')
        rel=path.lstrip('/')
        f=None
        if rel.startswith('web/'): f=(ROOT / rel).resolve()
        elif rel.startswith('boutique/'): f=(WEB / rel).resolve()
        if f is not None and f.is_file() and WEB.resolve() in f.parents:  # jamais en dehors de web/
            typ={'.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.html':'text/html; charset=utf-8',
                 '.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.ico':'image/x-icon',
                 '.webp':'image/webp','.woff2':'font/woff2','.json':'application/json; charset=utf-8'}.get(f.suffix.lower(),'application/octet-stream')
            return self.file('/'+rel,typ)
        return send(self,404,{'error':'not_found'})
    def file(self, rel, typ):
        clean=rel.lstrip('/')
        if clean.startswith('boutique/'):
            f=(WEB / clean).resolve()
        else:
            f=(ROOT / clean).resolve()
        b=f.read_bytes(); self.send_response(200); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def _do_PUT(self):
        p=urlparse(self.path); path=_alias(p.path.rstrip('/')); query=parse_qs(p.query)
        if path.startswith('/api/messages/conversations/') and path.endswith('/read'):
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            cid=path.split('/')[4]
            try:
                MESSAGES.mark_read(cid,account['id'])
                return send(self,200,{'ok':True})
            except PermissionError: return send(self,403,{'error':'conversation_forbidden'})
            except Exception as e: return send(self,404,{'error':str(e)})
        if path.startswith('/api/requests/') and path.endswith('/status'):
            rid=path.split('/')[-2]; st,e,r=find_request_engine(rid)
            if not st: return send(self,404,{'error':'request_not_found'})
            account,ast=admin_auth(self,query)
            if not account or not ast or ast['id']!=st['id']: return send(self,403,{'error':'not_space_owner'})
            try:
                data=read_json_body(self); result=e.update_status(rid,str(data.get('status','')))
                publish_event(st['id'],'status_changed',{'request_id':rid,'status':result['status'],'queue_number':result['queue_number'],'account_id':result.get('customer_account_id')})
                return send(self,200,public_request(result))
            except Exception as ex: return send(self,400,{'error':str(ex)})
        if path == '/api/identity':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                update_identity(ast, read_json_body(self))
                publish_event(ast['id'],'identity_changed',{})
                return send(self,200,{'identity':public_identity(ast)})
            except Exception as ex: return send(self,400,{'error':str(ex)})
        if path.startswith('/api/products/') or path.startswith('/api/admin/highlights/') or path.startswith('/api/admin/announcements/'):
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                data=read_json_body(self); e=engine_for(ast)
                if path.startswith('/api/products/'):
                    result=e.update_product(path.split('/')[-1],data); publish_event(ast['id'],'catalog_changed',{})
                elif '/active' in path and '/highlights/' in path:
                    result=e.update_highlight(path.split('/')[-2],data); publish_event(ast['id'],'highlight_changed',{})
                elif '/active' in path and '/announcements/' in path:
                    result=e.update_announcement(path.split('/')[-2],data); publish_event(ast['id'],'announcement_changed',{})
                else: return send(self,404,{'error':'endpoint_not_found'})
                return send(self,200,result)
            except Exception as ex: return send(self,400,{'error':str(ex)})
        return send(self,404,{'error':'endpoint_not_found'})

    def _delete_owned_store(self, account, sid):
        with STORES_LOCK:
            st=next((x for x in STORES if x.get('id')==sid),None)
            if not st: raise ValueError('store_not_found')
            if st.get('owner_id')!=account.get('id'): raise PermissionError('not_space_owner')
            db_path=resolve_store_db_path(st)
            data_root=ROOT.resolve()
            if data_root not in db_path.parents: raise ValueError('invalid_store_db')
            STORES.remove(st)
            save_stores()
            ENGINES.pop(sid,None)
            if db_path.exists(): db_path.unlink()
            return public_store(st)

    def _delete_account_with_stores(self, account):
        owned=[st for st in STORES if st.get('owner_id')==account.get('id')]
        with STORES_LOCK:
            for st in owned:
                sid=st.get('id')
                db_path=resolve_store_db_path(st)
                if DATA.resolve() in db_path.parents and db_path.exists(): db_path.unlink()
                ENGINES.pop(sid,None)
            STORES[:] = [st for st in STORES if st.get('owner_id')!=account.get('id')]
            save_stores()
        return len(owned)

    def _do_DELETE(self):
        p=urlparse(self.path); path=p.path.rstrip('/'); query=parse_qs(p.query)
        if path.startswith('/api/products/'):
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                result=engine_for(ast).delete_product(path.split('/')[-1]); publish_event(ast['id'],'catalog_changed',{}); return send(self,200,result)
            except Exception as ex: return send(self,400,{'error':str(ex)})
        if path.startswith('/api/stores/') and path.count('/')==3:
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            try:
                st=self._delete_owned_store(account,path.rsplit('/',1)[-1])
                return send(self,200,{'ok':True,'store':st})
            except PermissionError: return send(self,403,{'error':'not_space_owner'})
            except ValueError as e: return send(self,404,{'error':str(e)})
        if path == '/api/auth/account':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            try:
                stores_removed=self._delete_account_with_stores(account)
                result=ACCOUNTS.delete_account(account['id'])
                result['stores_removed']=stores_removed
                return send(self,200,result)
            except Exception as e: return send(self,400,{'error':str(e)})
        return send(self,404,{'error':'endpoint_not_found'})
    def _do_POST(self):
        p=urlparse(self.path); path=_alias(p.path.rstrip('/'))
        query=parse_qs(p.query); store=selected_store(query)

        if path == '/api/auth/signup':
            try:
                data = read_json_body(self)
                token, account = ACCOUNTS.signup(data.get('name'), data.get('email'), data.get('password'))
                return send(self,201,{'token':token,'account':account})
            except AccountError as e:
                return send(self,400,{'error':str(e)})
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if path == '/api/auth/login':
            try:
                data = read_json_body(self)
                token, account = ACCOUNTS.login(data.get('email'), data.get('password'))
                return send(self,200,{'token':token,'account':account})
            except AccountError as e:
                return send(self,401,{'error':str(e)})
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if path == '/api/auth/logout':
            token = bearer_token(self)
            if token: ACCOUNTS.logout(token)
            return send(self,200,{'ok':True})

        if path == '/api/messages/conversations':
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            try:
                data=read_json_body(self)
                target=str(data.get('target_account_id') or '').strip()
                store_id=str(data.get('store_id') or '').strip()
                if store_id:
                    st=next((x for x in STORES if x.get('id')==store_id),None)
                    if not st: return send(self,404,{'error':'store_not_found'})
                    conv=MESSAGES.store_conversation(account['id'],store_id,st.get('owner_id'))
                else:
                    target_account=ACCOUNTS.public_by_id(target)
                    if not target_account: return send(self,404,{'error':'account_not_found'})
                    conv=MESSAGES.direct(account['id'],target)
                return send(self,201,{'conversation':public_conversation(conv,account['id'])})
            except ValueError as e: return send(self,400,{'error':str(e)})
            except Exception as e: return send(self,400,{'error':str(e)})
        if path.startswith('/api/messages/conversations/') and path.endswith('/read'):
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            cid=path.split('/')[4]
            try:
                MESSAGES.mark_read(cid,account['id'])
                return send(self,200,{'ok':True})
            except PermissionError: return send(self,403,{'error':'conversation_forbidden'})
            except Exception as e: return send(self,404,{'error':str(e)})
        if path.startswith('/api/messages/conversations/') and path.endswith('/messages'):
            account=current_account(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            cid=path.split('/')[4]
            try:
                data=read_json_body(self)
                message,participants=MESSAGES.send(cid,account['id'],data.get('body'))
                # Réponse d'une boutique = annonce ciblée pour le client.
                try:
                    with MESSAGES.lock, MESSAGES._db() as db:
                        conv=db.execute('SELECT * FROM conversations WHERE id=?',(cid,)).fetchone()
                    if conv and conv['kind']=='store':
                        st=next((x for x in STORES if x.get('id')==conv['store_id']),None)
                        if st and st.get('owner_id')==account.get('id'):
                            target=next((aid for aid in participants if aid!=account.get('id')),None)
                            if target:
                                announcement=engine_for(st).add_announcement({
                                    'title': f"Réponse de {st.get('name') or 'la boutique'}",
                                    'message': str(data.get('body') or '').strip(),
                                    'type': 'info',
                                    'target_account_id': target,
                                })
                                publish_event(st['id'],'announcement_targeted',{'account_id':target,'announcement_id':announcement['id']})
                except Exception:
                    log.exception('Impossible de créer l’annonce ciblée après une réponse boutique')
                publish_message_events(message,participants)
                return send(self,201,{'message':public_message(message)})
            except PermissionError: return send(self,403,{'error':'conversation_forbidden'})
            except ValueError as e: return send(self,400,{'error':str(e)})
            except Exception as e: return send(self,400,{'error':str(e)})
        if path == '/api/spaces':
            account = current_account(self)
            if not account: return send(self,401,{'error':'authentication_required'})
            try:
                data = read_json_body(self)
                new_store = create_space(account, data)
                return send(self,201,{'store':public_store(new_store)})
            except ValueError as e:
                return send(self,400,{'error':str(e)})
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if path == '/api/products':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                data=read_json_body(self)
                result=add_store_product(ast, data)
                publish_event(ast['id'],'catalog_changed',{})
                return send(self,201,result)
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if path == '/api/requests':
            asked=_qget(query, 'store')
            if asked and not any(x['id']==asked for x in STORES):
                return send(self,404,{'error':'store_not_found'})  # ne jamais envoyer la commande à une autre boutique
            try:
                data=read_json_body(self)
                account=current_account(self)
                if account: data['customer_account_id']=account['id']
                result=engine_for(store).create_request(data, self.headers.get('X-Idempotency-Key','')) if store else None
                if result is None: return send(self,404,{'error':'store_not_found'})
                if result.get('duplicate'): return send(self,200,result)
                publish_event(store['id'],'request_created',{'request_id':result['request_id'],'status':result['status'],'queue_number':result['queue_number'],'account_id':data.get('customer_account_id')})
                return send(self,201,result)
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if path in ('/api/categories','/api/admin/announcements','/api/admin/highlights'):
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                data=read_json_body(self); e=engine_for(ast)
                if path=='/api/categories': result=e.add_category(data.get('name'))
                elif path=='/api/admin/announcements': result=e.add_announcement(data); publish_event(ast['id'],'announcement_changed',{})
                else: result=e.add_highlight(data); publish_event(ast['id'],'highlight_changed',{})
                return send(self,201,result)
            except Exception as e: return send(self,400,{'error':str(e)})
        if path == '/api/identity':
            account,ast=admin_auth(self,query)
            if not account: return send(self,401,{'error':'authentication_required'})
            if not ast: return send(self,403,{'error':'not_space_owner'})
            try:
                update_identity(ast, read_json_body(self))
                publish_event(ast['id'],'identity_changed',{})
                return send(self,200,{'identity':public_identity(ast)})
            except Exception as e: return send(self,400,{'error':str(e)})
        if not path.startswith('/api/stores/'): return send(self,404,{'error':'endpoint_not_found'})
        parts=path.split('/'); sid=parts[3] if len(parts)>3 else ''
        store=next((s for s in STORES if s['id']==sid),None)
        if not store: return send(self,404,{'error':'store_not_found'})
        if len(parts)!=5: return send(self,404,{'error':'endpoint_not_found'})

        if parts[4] == 'products':
            account = current_account(self)
            if not account or account['id'] != store.get('owner_id'):
                return send(self,403,{'error':'not_space_owner'})
            try:
                data=read_json_body(self)
                result=add_store_product(store, data)
                publish_event(store['id'],'catalog_changed',{})
                return send(self,201,result)
            except Exception as e:
                return send(self,400,{'error':str(e)})

        if parts[4] != 'requests': return send(self,404,{'error':'endpoint_not_found'})
        try:
            data=read_json_body(self)
            account=current_account(self)
            if account: data['customer_account_id']=account['id']
            result=engine_for(store).create_request(data, self.headers.get('X-Idempotency-Key',''))
            if result.get('duplicate'):
                return send(self,200,result)
            publish_event(store['id'],'request_created',{'request_id':result['request_id'],'status':result['status'],'queue_number':result['queue_number'],'account_id':data.get('customer_account_id')})
            return send(self,201,result)
        except Exception as e:
            return send(self,400,{'error':str(e)})


# =====================================================================
# FLASK / WSGI
# =====================================================================
# LOBICOP conserve ici les fonctions métier et les routes historiques, mais
# l'entrée HTTP est désormais Flask/WSGI. Cela permet un déploiement direct
# sur PythonAnywhere et évite de dépendre de ThreadingHTTPServer.
from flask import Flask, Response, request, redirect, send_file, make_response

app = Flask(__name__, static_folder=None)
app.config['JSON_AS_ASCII'] = False

class FlaskCompatHandler(Handler):
    """Adaptateur minimal pour réutiliser les routes historiques sans réécrire
    le métier. Flask reste le serveur WSGI public; cet objet ne crée aucun
    socket et ne dépend pas de BaseHTTPRequestHandler.__init__()."""
    def __init__(self):
        self.path = request.full_path[:-1] if request.full_path.endswith('?') else request.full_path
        self.headers = request.headers
        self.rfile = io.BytesIO(request.get_data(cache=True) or b'')
        self.wfile = io.BytesIO()
        self._status = 200
        self._headers = {}

    def address_string(self):
        return request.remote_addr or '-'

    def send_response(self, code, message=None):
        self._status = code

    def send_header(self, key, value):
        self._headers[key] = str(value)

    def end_headers(self):
        return None

    def _response(self):
        return Response(self.wfile.getvalue(), status=self._status, headers=self._headers)


def _compat_call(method):
    h = FlaskCompatHandler()
    try:
        getattr(h, method)()
    except Exception:
        log.error('Erreur Flask dans %s %s:\n%s', method, request.path, traceback.format_exc())
        return make_response(json.dumps({'error':'internal_error'}, ensure_ascii=False), 500, {'Content-Type':'application/json; charset=utf-8'})
    return h._response()


def _sse_flask(store_id=None, request_ids=None, account_id=None, event_types=None):
    """Version WSGI du SSE. Génératrice pour ne pas bloquer le worker Flask."""
    last = EVENT_SEQ
    given = (request.headers.get('Last-Event-ID','') or '').strip()
    if given:
        try: last = min(int(given), last)
        except Exception: pass

    def generate():
        nonlocal last
        yield 'retry: 2000\n: connected\n\n'
        while True:
            head, batch = wait_events(last, store_id, request_ids, account_id, timeout=15, event_types=event_types)
            if batch:
                for evt in batch:
                    payload=json.dumps({'type':evt['type'], **{k:v for k,v in evt['payload'].items() if k!='account_id'}}, ensure_ascii=False)
                    yield f'id: {evt["id"]}\ndata: {payload}\n\n'
            else:
                yield ': heartbeat\n\n'
            last = head

    return Response(generate(), mimetype='text/event-stream', headers={
        'Cache-Control':'no-cache, no-transform',
        'X-Accel-Buffering':'no',
        'Access-Control-Allow-Origin':'*',
    })


@app.after_request
def flask_headers(response):
    response.headers.setdefault('Access-Control-Allow-Origin', '*')
    response.headers.setdefault('Cache-Control', 'no-store') if request.path.startswith('/api/') and 'stream' not in request.path else None
    return response


@app.route('/api/events/stream', methods=['GET'])
def api_events_stream():
    store_id=(request.args.get('store') or '').strip() or None
    raw_ids=(request.args.get('request_ids') or '').strip()
    request_ids=[x for x in raw_ids.split(',') if x]
    if not request_ids:
        return {'error':'request_ids_required'}, 400
    return _sse_flask(store_id, request_ids)


@app.route('/api/messages/stream', methods=['GET'])
def api_messages_stream():
    account=current_account(FlaskCompatHandler(), request.args)
    if not account: return {'error':'authentication_required'}, 401
    return _sse_flask(account_id=account['id'], event_types={'message_created'})


@app.route('/api/my/stream', methods=['GET'])
def api_my_stream():
    account=current_account(FlaskCompatHandler(), request.args)
    if not account: return {'error':'authentication_required'}, 401
    return _sse_flask(account_id=account['id'])


@app.route('/api/admin/stream', methods=['GET'])
def api_admin_stream():
    h=FlaskCompatHandler()
    account, ast = admin_auth(h, request.args)
    if not account: return {'error':'authentication_required'}, 401
    if not ast: return {'error':'not_space_owner'}, 403
    return _sse_flask(store_id=ast['id'])


@app.route('/api/<path:subpath>', methods=['GET','POST','PUT','DELETE','OPTIONS'])
@app.route('/api', methods=['GET','POST','PUT','DELETE','OPTIONS'])
def api_legacy(subpath=''):
    if request.method == 'OPTIONS':
        r=make_response('',204)
        r.headers['Access-Control-Allow-Headers']='Content-Type, Authorization, X-Idempotency-Key, Last-Event-ID'
        r.headers['Access-Control-Allow-Methods']='GET, POST, PUT, DELETE, OPTIONS'
        return r
    return _compat_call({'GET':'do_GET','POST':'do_POST','PUT':'do_PUT','DELETE':'do_DELETE'}[request.method])


@app.route('/', defaults={'subpath':''}, methods=['GET'])
@app.route('/<path:subpath>', methods=['GET'])
def web_legacy(subpath=''):
    # Les pages statiques historiques sont servies par Flask, pas par un
    # serveur de fichiers artisanal.
    if request.path == '/':
        return send_file(WEB / 'index.html')
    if request.path == '/admin.html':
        return send_file(WEB / 'admin.html')
    if request.path == '/taxi':
        return send_file(WEB / 'taxi.html')
    if request.path == '/boutique':
        return redirect('/boutique/', code=301)
    if request.path == '/boutique/':
        return send_file(WEB / 'boutique' / 'index.html')

    rel=request.path.lstrip('/')
    candidate=None
    if rel.startswith('web/'):
        candidate=(ROOT / rel).resolve()
    elif rel.startswith('boutique/'):
        candidate=(WEB / rel).resolve()
    if candidate and candidate.is_file() and WEB.resolve() in candidate.parents:
        return send_file(candidate)
    return {'error':'not_found'}, 404



@app.route('/media/real/<path:subpath>', methods=['GET'])
def real_media(subpath):
    candidate=(DATA / 'media' / 'real' / subpath).resolve()
    media_root=(DATA / 'media' / 'real').resolve()
    if candidate.is_file() and (candidate == media_root or media_root in candidate.parents):
        return send_file(candidate)
    return {'error':'not_found'}, 404

@app.errorhandler(404)
def not_found(_):
    if request.path.startswith('/api/'):
        return {'error':'not_found'}, 404
    return {'error':'not_found'}, 404


@app.errorhandler(413)
def too_large(_):
    return {'error':'payload_too_large'}, 413


# Objet attendu par PythonAnywhere : /var/www/.../wsgi.py importe `application`.
application = app


def run_local():
    DATA.mkdir(exist_ok=True)
    log.info('=' * 70)
    log.info('%s %s — démarrage Flask/WSGI', BRAND, VERSION)
    log.info('  Adresse       : http://%s:%s', HOST, PORT)
    log.info('  Boutiques     : %d chargées (%s)', len(STORES), ', '.join(s['id'] for s in STORES))
    log.info('  Secteurs      : %s', ', '.join(SECTOR_CATEGORIES.keys()))
    log.info('  Niveau de log : %s', LOG_LEVEL)
    log.info('  Journal écrit : %s', LOG_PATH)
    log.info('=' * 70)
    app.run(host=HOST, port=PORT, threaded=True)


if __name__=='__main__':
    run_local()
