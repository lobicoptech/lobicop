"""Régressions : fichiers sensibles non servis, listes de commandes privées, stock restitué à
l'annulation, type d'opération imposé par le produit, routes admin annonces/à la une."""
import json, os, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
tmp = Path(tempfile.mkdtemp()); work = tmp / 'p'
shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('*.log', '__pycache__'))
for f in (work / 'data').glob('*.db'): f.unlink()
(work / 'data' / 'sessions.json').write_text('{}'); (work / 'data' / 'accounts.json').write_text('[]')
PORT = '8793'; B = f'http://127.0.0.1:{PORT}'
srv = subprocess.Popen([sys.executable, 'server/main.py'], cwd=work, env=dict(os.environ, PORT=PORT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
def call(m, p, body=None, tok=None):
    h = {'Content-Type': 'application/json'}
    if tok: h['Authorization'] = 'Bearer ' + tok
    r = urllib.request.Request(B + p, data=None if body is None else json.dumps(body).encode(), method=m, headers=h)
    try:
        with urllib.request.urlopen(r) as x: return x.status, json.loads(x.read() or b'{}')
    except urllib.error.HTTPError as e:
        raw = e.read()
        try: return e.code, json.loads(raw)
        except Exception: return e.code, {}
try:
    for _ in range(50):
        try: call('GET', '/api/health'); break
        except Exception: time.sleep(0.2)
    for p in ('/data/sessions.json', '/data/accounts.json', '/data/stores.json', '/server/main.py', '/web/../data/accounts.json'):
        try: code = urllib.request.urlopen(B + p).status
        except urllib.error.HTTPError as e: code = e.code
        assert code == 404, (p, code)
    assert call('GET', '/api/products?store=inconnue')[1]['items'] == []
    assert call('GET', '/api/requests')[0] == 401
    assert call('GET', '/api/stores/shop-resto-centre/requests')[0] == 401
    tok = call('POST', '/api/auth/signup', {'name': 'T', 'email': 'a@b.cd', 'password': 'password123'})[1]['token']
    sid = call('POST', '/api/spaces', {'name': 'Shop', 'sector': 'boutique', 'city': 'Brazzaville'}, tok)[1]['store']['id']
    pid = call('POST', f'/api/products?store={sid}', {'name': 'Stylo', 'price': 500, 'stock': 3}, tok)[1]['id']
    stock = lambda: next(p for p in call('GET', f'/api/products?store={sid}')[1]['items'] if p['id'] == pid)
    rid = call('POST', f'/api/requests?store={sid}', {'customer_name': 'C', 'customer_phone': '0600', 'items': [{'product_id': pid, 'quantity': 3}]})[1]['request_id']
    assert stock()['stock'] == 0 and stock()['available'] == 0
    t = call('GET', f'/api/requests/{rid}')[1]
    assert 'customer_phone' not in t and 'customer_name' not in t
    assert call('PUT', f'/api/requests/{rid}/status?store={sid}', {'status': 'cancelled'}, tok)[0] == 200
    assert stock()['stock'] == 3 and stock()['available'] == 1
    assert call('PUT', f'/api/requests/{rid}/status?store={sid}', {'status': 'pending'}, tok)[0] == 400
    call('PUT', f'/api/products/{pid}?store={sid}', {'stock': 0}, tok); assert stock()['available'] == 0
    call('PUT', f'/api/products/{pid}?store={sid}', {'stock': 5}, tok); assert stock()['available'] == 1
    assert call('POST', f'/api/admin/announcements?store={sid}', {'title': 'a', 'message': 'b'}, tok)[0] == 201
    assert call('PUT', f'/api/identity?store={sid}', {'name': ''}, tok)[0] == 400
    pres = next(p for p in call('GET', '/api/stores/shop-pharmacie-centre/catalog')[1]['products'] if p['operation_kind'] == 'prescription_request')
    st, d = call('POST', '/api/requests?store=shop-pharmacie-centre', {'customer_name': 'X', 'items': [{'product_id': pres['id'], 'quantity': 1, 'kind': 'pharmacy_product', 'details': {}}]})
    assert st == 400 and d['error'] == 'prescription_reference_required'
    # thème partagé clair/sombre (même mémorisation sur toute la plateforme)
    for u in ('/web/theme.js', '/web/theme.css'):
        assert urllib.request.urlopen(B + u).status == 200
    for page in ('/', '/taxi'):
        html = urllib.request.urlopen(B + page).read().decode()
        assert '/web/theme.js' in html and '/web/theme.css' in html and 'id="themeToggle"' in html, page
    for page in ('/boutique/', '/admin.html'):
        assert 'id="themeToggle"' in urllib.request.urlopen(B + page).read().decode(), page
    for js in ('/boutique/assets/admin.js', '/boutique/assets/app.js'):
        assert "THEME_KEY='nzela_theme'" in urllib.request.urlopen(B + js).read().decode(), js
    assert 'MONDE CLASSIQUE' not in urllib.request.urlopen(B + '/boutique/assets/app.css').read().decode()  # plus de blanc forcé en mode sombre
    for css in ('/web/theme.css', '/boutique/assets/app.css', '/boutique/assets/admin.css'):  # mode clair : le curseur à 100 % donne du blanc pur
        assert 'color-mix(in srgb,#ffffff var(--theme-scale' in urllib.request.urlopen(B + css).read().decode().replace('--lb-a:#ffffff; --lb-b:#b9c6d8;   /* 100 % = blanc pur, 0 % = gris-bleu */\n  --theme-bg:color-mix(in srgb,var(--lb-a)', 'color-mix(in srgb,#ffffff'), css
    print('LOBICOP BUGFIXES 0.2.7 TEST OK')
finally:
    srv.terminate(); shutil.rmtree(tmp, ignore_errors=True)
