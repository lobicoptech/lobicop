import sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'engine'))

from restaurant_adapter import RestaurantEngine
from accounts import AccountStore, AccountError

# --- Adaptateur restaurant : le moteur générique reste inchangé, seules les
# règles (catégories, opérations) sont spécifiques au secteur. ---
with tempfile.TemporaryDirectory() as td:
    e = RestaurantEngine(Path(td) / 'resto.db')
    e.add_menu_item({'name': 'Poulet braisé', 'category': 'Plats', 'price': 4500, 'stock': 10})
    p = e.products()[0]
    r = e.create_request({'customer_name': 'Client', 'items': [
        {'product_id': p['id'], 'quantity': 2, 'kind': 'menu_item', 'details': {}}
    ]})
    assert r['status'] == 'pending' and r['total'] == 9000
    assert e.products()[0]['stock'] == 8
    try:
        e.add_menu_item({'name': 'Invalide', 'category': 'Catégorie inconnue', 'price': 100, 'stock': 1})
        raise AssertionError('devrait rejeter une catégorie inconnue')
    except Exception as exc:
        assert 'invalid_restaurant_category' in str(exc)

# --- Comptes acteurs : inscription, connexion, sessions ---
with tempfile.TemporaryDirectory() as td:
    store = AccountStore(Path(td) / 'accounts.json', Path(td) / 'sessions.json')
    token, account = store.signup('Awa Nzila', 'Awa@Example.com', 'motdepasse123')
    assert account['email'] == 'awa@example.com'
    assert store.account_for_token(token)['id'] == account['id']

    # Email déjà utilisé
    try:
        store.signup('Autre', 'awa@example.com', 'autremotdepasse')
        raise AssertionError('devrait rejeter un email déjà utilisé')
    except AccountError as exc:
        assert str(exc) == 'email_already_used'

    # Connexion correcte
    token2, account2 = store.login('awa@example.com', 'motdepasse123')
    assert account2['id'] == account['id']

    # Mauvais mot de passe
    try:
        store.login('awa@example.com', 'faux-mot-de-passe')
        raise AssertionError('devrait rejeter un mauvais mot de passe')
    except AccountError as exc:
        assert str(exc) == 'invalid_credentials'

    # Déconnexion invalide le jeton
    store.logout(token2)
    assert store.account_for_token(token2) is None
    # Le premier jeton reste valide (sessions indépendantes)
    assert store.account_for_token(token) is not None

print('NZELA RESTAURANT + ACCOUNTS TEST OK')
