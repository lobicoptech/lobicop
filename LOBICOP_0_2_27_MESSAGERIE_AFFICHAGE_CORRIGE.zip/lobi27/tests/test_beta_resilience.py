"""Bêta: persistance après redémarrage et séparation des clients."""
import json, os, shutil, socket, subprocess, sys, tempfile, time, urllib.error, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0)); return s.getsockname()[1]

def call(base, method, path, body=None, tok=None):
    headers={'Content-Type':'application/json'}
    if tok: headers['Authorization']='Bearer '+tok
    req=urllib.request.Request(base+path,method=method,data=None if body is None else json.dumps(body).encode(),headers=headers)
    try:
        with urllib.request.urlopen(req,timeout=8) as r: return r.status,json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code,json.loads(e.read() or b'{}')

work=Path(tempfile.mkdtemp()); app=work/'app'; shutil.copytree(ROOT,app,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','server.log'))
for f in (app/'data').glob('*.db'): f.unlink()
(app/'data/accounts.json').write_text('[]'); (app/'data/sessions.json').write_text('{}')
port=free_port(); base=f'http://127.0.0.1:{port}'
env={**os.environ,'PORT':str(port),'NZELA_PORT':str(port)}
srv=None
try:
    def start():
        global srv
        srv=subprocess.Popen([sys.executable,'server/main.py'],cwd=app,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env)
        for _ in range(60):
            try:
                if call(base,'GET','/api/health')[0]==200: return
            except Exception: pass
            time.sleep(.15)
        raise RuntimeError('serveur non démarré')
    start()
    _,a=call(base,'POST','/api/auth/signup',{'name':'Vendeur','email':'vendeur@x.cd','password':'secret123'}); tok=a['token']
    _,s=call(base,'POST','/api/spaces',{'name':'Boutique Test','sector':'boutique','city':'Brazzaville'},tok); sid=s['store']['id']
    _,p=call(base,'POST',f'/api/products?store={sid}',{'name':'Article','price':1000,'stock':4},tok); pid=p['id']
    _,c1=call(base,'POST','/api/auth/signup',{'name':'Client A','email':'a@x.cd','password':'secret123'}); t1=c1['token']
    _,c2=call(base,'POST','/api/auth/signup',{'name':'Client B','email':'b@x.cd','password':'secret123'}); t2=c2['token']
    st,r1=call(base,'POST',f'/api/requests?store={sid}',{'customer_name':'Client A','items':[{'product_id':pid,'quantity':1,'kind':'product_order','details':{}}]},t1); assert st==201
    st,r2=call(base,'POST',f'/api/requests?store={sid}',{'customer_name':'Client B','items':[{'product_id':pid,'quantity':1,'kind':'product_order','details':{}}]},t2); assert st==201 and r1['request_id']!=r2['request_id']
    # chaque client ne voit que sa propre commande dans l'historique authentifié
    _,h1=call(base,'GET',f'/api/my/requests?store={sid}',None,t1); _,h2=call(base,'GET',f'/api/my/requests?store={sid}',None,t2)
    assert {x['id'] for x in h1['items']}=={r1['request_id']}; assert {x['id'] for x in h2['items']}=={r2['request_id']}
    # redémarrage: comptes, boutique, commandes et statut restent présents
    srv.terminate(); srv.wait(timeout=5); start()
    st,h=call(base,'GET',f'/api/admin/requests?store={sid}',None,tok); assert st==200 and {x['id'] for x in h['items']}=={r1['request_id'],r2['request_id']}
    st,_=call(base,'PUT',f'/api/requests/{r1["request_id"]}/status?store={sid}',{'status':'preparing'},tok); assert st==200
    st,tr=call(base,'GET',f'/api/requests/{r1["request_id"]}?store={sid}'); assert st==200 and tr['status']=='preparing'
    print('LOBICOP BETA RESILIENCE TEST OK')
finally:
    if srv:
        srv.terminate()
        try: srv.wait(timeout=3)
        except Exception: srv.kill()
    shutil.rmtree(work,ignore_errors=True)
