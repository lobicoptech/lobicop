import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'engine'))
from pharmacy_adapter import PharmacyEngine
stores=json.loads((ROOT/'data/stores.json').read_text())
assert len(stores)>=4
with tempfile.TemporaryDirectory() as td:
    e=PharmacyEngine(Path(td)/'shop.db')
    e.add_pharmacy_product({'name':'Test','category':'Hygiène','price':1000,'stock':2})
    p=e.products()[0]
    r=e.create_request({'customer_name':'Client','items':[{'product_id':p['id'],'quantity':1,'kind':'pharmacy_product','details':{}}]})
    assert r['status']=='pending' and r['total']==1000
    assert e.products()[0]['stock']==1
print('NZELA GLOBAL TEST OK')
