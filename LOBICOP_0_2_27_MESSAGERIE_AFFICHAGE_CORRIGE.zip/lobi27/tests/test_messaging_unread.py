import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from messaging import MessagingStore

class MessagingUnreadTest(unittest.TestCase):
    def test_unread_and_read_state(self):
        with tempfile.TemporaryDirectory() as td:
            store = MessagingStore(Path(td) / 'messages.db')
            conv = store.direct('alice', 'bob')
            msg, _ = store.send(conv['id'], 'alice', 'Bonjour')
            rows = store.messages(conv['id'], 'bob')
            self.assertEqual(rows[0]['body'], 'Bonjour')
            self.assertIsNone(rows[0]['read_at'])
            store.mark_read(conv['id'], 'bob')
            rows = store.messages(conv['id'], 'bob')
            self.assertIsNotNone(rows[0]['read_at'])
            with self.assertRaises(PermissionError):
                store.messages(conv['id'], 'intrus')

    def test_owner_cannot_open_store_conversation_with_self(self):
        with tempfile.TemporaryDirectory() as td:
            store = MessagingStore(Path(td) / 'messages.db')
            with self.assertRaises(ValueError):
                store.store_conversation('owner', 'store-1', 'owner')

if __name__ == '__main__':
    unittest.main()
