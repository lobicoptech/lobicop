"""Tests du temps réel des commandes (v0.2.10).

Lance une copie du serveur dans un dossier temporaire (les vraies données ne
sont jamais touchées) et vérifie le chemin client -> serveur -> flux admin.
"""
import json, os, shutil, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0)); return s.getsockname()[1]

work = Path(tempfile.mkdtemp()); app = work / 'app'
shutil.copytree(ROOT, app, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', 'server.log', '.git'))
port = free_port(); base = f'http://127.0.0.1:{port}'
srv = subprocess.Popen([sys.executable, 'server/main.py'], cwd=app, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       env={**os.environ, 'PORT': str(port), 'NZELA_PORT': str(port)})

def call(method, path, body=None, tok=None):
    req = urllib.request.Request(base + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={'Content-Type': 'application/json', **({'Authorization': 'Bearer ' + tok} if tok else {})})
    try:
        with urllib.request.urlopen(req, timeout=10) as r: return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b'{}')

def listen(path, out, stop, headers=None):
    try:
        r = urllib.request.urlopen(urllib.request.Request(base + path, headers=headers or {}), timeout=30)
        while not stop.is_set():
            line = r.readline()
            if not line: break
            line = line.decode().strip()
            if line.startswith('data:'): out.append((time.time(), json.loads(line[5:])))
    except Exception: pass

try:
    for _ in range(60):
        try: urllib.request.urlopen(base + '/api/health', timeout=1); break
        except Exception: time.sleep(.25)
    _, d = call('POST', '/api/auth/signup', {'name': 'Patron', 'email': f'p{time.time()}@x.com', 'password': 'secret123'}); tok = d['token']
    _, d = call('POST', '/api/spaces', {'name': 'Ma Boutique', 'sector': 'boutique', 'city': 'Brazzaville'}, tok); sid = d['store']['id']
    _, d = call('POST', f'/api/products?store={sid}', {'name': 'Robe', 'category': 'Mode', 'price': 5000, 'stock': 50}, tok); pid = d['id']
    def order(name):
        return call('POST', f'/api/requests?store={sid}', {'customer_name': name, 'customer_phone': '06', 'items': [{'product_id': pid, 'quantity': 1, 'kind': '', 'details': {}}]})

    # 1) l'événement arrive à l'admin en moins d'une seconde
    got = []; stop = threading.Event()
    threading.Thread(target=listen, args=(f'/api/admin/stream?store={sid}&token={tok}', got, stop), daemon=True).start(); time.sleep(.8)
    t0 = time.time(); assert order('Alice')[0] == 201; time.sleep(1.0)
    assert any(e.get('type') == 'request_created' and ts - t0 < 1.0 for ts, e in got), 'événement request_created trop lent ou absent'
    stop.set()

    # 2) une NOUVELLE connexion ne rejoue pas l'historique
    got2 = []; stop2 = threading.Event()
    threading.Thread(target=listen, args=(f'/api/admin/stream?store={sid}&token={tok}', got2, stop2), daemon=True).start(); time.sleep(1.0)
    assert got2 == [], f'rejeu inattendu des anciens événements : {got2}'
    # 2b) ... mais une reconnexion avec Last-Event-ID reprend où elle s'était arrêtée
    got3 = []; stop3 = threading.Event()
    threading.Thread(target=listen, args=(f'/api/admin/stream?store={sid}&token={tok}', got3, stop3, {'Last-Event-ID': '0'}), daemon=True).start(); time.sleep(1.0)
    assert any(e.get('type') == 'request_created' for _, e in got3), 'Last-Event-ID devrait rattraper les événements manqués'
    # 2c) la commande suivante est bien reçue par la connexion neuve
    order('Bob'); time.sleep(.8)
    assert any(e.get('type') == 'request_created' for _, e in got2), 'la 2e commande doit arriver sur le flux'
    stop2.set(); stop3.set()

    # 3) le flux public refuse de s'ouvrir sans liste de commandes suivies (sinon il fuitait tout)
    assert call('GET', f'/api/events/stream?store={sid}')[0] == 400

    # 4) une boutique inconnue ne redirige plus la commande vers la 1re boutique
    assert call('POST', '/api/requests?store=shop-inexistante', {'customer_name': 'X', 'items': [{'product_id': pid, 'quantity': 1}]})[0] == 404

    # 5) l'admin retrouve bien toutes les commandes
    st, d = call('GET', f'/api/admin/requests?store={sid}', None, tok)
    assert st == 200 and {x['customer_name'] for x in d['items']} == {'Alice', 'Bob'}

    # 6) deux envois avec la même clé d'idempotence créent UNE seule commande
    idem='test-idem-'+str(time.time_ns())
    payload={'customer_name':'Idem','customer_phone':'06','items':[{'product_id':pid,'quantity':1,'kind':'','details':{}}]}
    req=urllib.request.Request(base+f'/api/requests?store={sid}',method='POST',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Idempotency-Key':idem})
    with urllib.request.urlopen(req,timeout=10) as r: first=json.loads(r.read())
    req=urllib.request.Request(base+f'/api/requests?store={sid}',method='POST',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Idempotency-Key':idem})
    with urllib.request.urlopen(req,timeout=10) as r: second=json.loads(r.read()); second_status=r.status
    assert second_status==200 and first['request_id']==second['request_id'] and second.get('duplicate') is True, 'idempotence commande non garantie'

    # 7) un changement de statut est immédiatement visible sur le flux public client
    public_events=[]; stop4=threading.Event()
    threading.Thread(target=listen, args=(f'/api/events/stream?store={sid}&request_ids={first["request_id"]}', public_events, stop4), daemon=True).start(); time.sleep(.5)
    st,_=call('PUT',f'/api/requests/{first["request_id"]}/status?store={sid}',{'status':'preparing'},tok)
    assert st==200
    time.sleep(.8)
    assert any(e.get('type')=='status_changed' and e.get('status')=='preparing' for _,e in public_events), 'statut non transmis au client'
    stop4.set()

    # 8) le flux admin peut récupérer immédiatement UNE commande, sans
    # recharger toute la liste : c'est le chemin utilisé par l'interface
    # quand request_created arrive.
    alice = next(x for x in d['items'] if x['customer_name'] == 'Alice')
    st, one = call('GET', f"/api/admin/requests/{alice['id']}?store={sid}", None, tok)
    assert st == 200 and one['id'] == alice['id'] and one['customer_name'] == 'Alice'
finally:
    srv.terminate(); shutil.rmtree(work, ignore_errors=True)
print('LOBICOP REALTIME ORDERS TEST OK')
