from pathlib import Path

APP = Path(__file__).resolve().parents[1] / 'web' / 'app.js'
BOUTIQUE_APP = Path(__file__).resolve().parents[1] / 'web' / 'boutique' / 'assets' / 'app.js'


def test_message_ui_opens_chat_panel_and_loads_conversation_before_opening():
    src = APP.read_text(encoding='utf-8')
    assert "$('#chatEmpty')?.classList.add('hidden');$('#chatActive')?.classList.remove('hidden');" in src
    assert 'await loadConversations();\n    const cid=messageQuery.get' in src
    assert 'await openConversation(fresh.id,false)' not in src


def test_message_ui_bootstraps_existing_session_and_contact_link():
    src = APP.read_text(encoding='utf-8')
    boutique = BOUTIQUE_APP.read_text(encoding='utf-8')
    assert "if(auth){startMessageStream();loadConversations()}" in src
    assert "location.href='/?messages=1&conversation='+encodeURIComponent(d.conversation.id)" in boutique
