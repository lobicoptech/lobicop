import tempfile, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine.messaging import MessagingStore

with tempfile.TemporaryDirectory() as d:
    m=MessagingStore(Path(d)/"messages.db")
    c=m.direct("a","b")
    assert c["other_id"]=="b"
    msg,parts=m.send(c["id"],"a","  Bonjour   Bob  ")
    assert msg["body"]=="Bonjour Bob" and set(parts)=={"a","b"}
    assert m.messages(c["id"],"b")[0]["body"]=="Bonjour Bob"
    try: m.messages(c["id"],"c")
    except PermissionError: pass
    else: raise AssertionError("unauthorized read accepted")
    sc=m.store_conversation("u","shop-1","owner")
    assert sc["other_id"]=="owner"
    print("LOBICOP MESSAGING TEST OK")
