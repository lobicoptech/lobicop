import sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engine'))
from commerce_adapter import CommerceEngine
from service_adapter import ServiceEngine
from establishment_adapter import EstablishmentEngine

with tempfile.TemporaryDirectory() as td:
    e=CommerceEngine(Path(td)/'commerce.db')
    e.add_item({'name':'Sac','category':'Mode','price':10000,'stock':5})
    p=e.products()[0]
    r=e.create_request({'customer_name':'Client','items':[{'product_id':p['id'],'quantity':2,'kind':'product_order','details':{}}]})
    assert r['total']==20000 and e.products()[0]['stock']==3

with tempfile.TemporaryDirectory() as td:
    e=ServiceEngine(Path(td)/'service.db')
    e.add_capability({'name':'Course urbaine','category':'Transport','price':0,'stock':5,'operation_kind':'ride_request'})
    p=e.products()[0]
    r=e.create_request({'customer_name':'Client','items':[{'product_id':p['id'],'quantity':1,'kind':'ride_request','details':{'pickup':'A','destination':'B'}}]})
    assert r['status']=='pending'

with tempfile.TemporaryDirectory() as td:
    e=EstablishmentEngine(Path(td)/'establishment.db')
    e.add_offering({'name':'Rendez-vous','category':'Rendez-vous','price':0,'stock':5,'operation_kind':'appointment_request'})
    p=e.products()[0]
    r=e.create_request({'customer_name':'Client','items':[{'product_id':p['id'],'quantity':1,'kind':'appointment_request','details':{'requested_time':'demain 10h'}}]})
    assert r['status']=='pending'

print('LOBICOP 3 ADAPTERS TEST OK')
