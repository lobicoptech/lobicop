#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================================
 NZELA CLI — l'outil pour manipuler le projet LOBICOP tout seul
============================================================================
Ce programme n'a besoin de RIEN d'autre que Python (déjà installé si le
serveur fonctionne). Il permet de :
  - se promener dans les dossiers et fichiers du projet
  - lire un fichier (en entier ou seulement quelques lignes)
  - chercher un mot ou un bout de texte dans tout le projet
  - modifier UNE ligne précise, ou remplacer un bout de texte précis
  - annuler automatiquement une modification qui se passe mal
  - lancer le serveur avec des journaux (logs) clairs pour diagnostiquer
  - vérifier que rien n'est cassé avant de continuer

DEUX FAÇONS DE L'UTILISER
--------------------------------------------------------------------------
1) MODE MENU (le plus simple, recommandé au début) :

      python3 tools/nzela_cli.py

   Un menu numéroté s'affiche, on tape un chiffre, on suit les questions.

2) MODE COMMANDE (plus rapide une fois habitué) :

      python3 tools/nzela_cli.py voir web/app.css 1 20
      python3 tools/nzela_cli.py chercher "z-index"
      python3 tools/nzela_cli.py modifier-ligne web/app.css 12 "  --accent:#ff0000;"
      python3 tools/nzela_cli.py restaurer web/app.css

Tapez  python3 tools/nzela_cli.py aide  pour la liste complète.
============================================================================
"""
import os, sys, re, json, shutil, difflib, subprocess, time
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]           # dossier du projet (parent de tools/)
BACKUP_DIR = ROOT / ".nzela_backups"                   # toutes les sauvegardes vivent ici
LOG_FILE = ROOT / "server" / "server.log"
IGNORED_DIRS = {".git", "__pycache__", ".nzela_backups", "node_modules", ".pytest_cache"}
TEXT_EXTENSIONS = {".py", ".js", ".css", ".html", ".json", ".md", ".txt", ".yaml", ".yml", ".gitignore", ""}

# ---------------------------------------------------------------------
# Utilitaires de base
# ---------------------------------------------------------------------

def resolve(path_str):
    """Transforme un chemin tapé par l'utilisateur (relatif au projet) en
    chemin réel, et vérifie qu'on ne sort jamais du dossier du projet
    (sécurité : impossible de modifier un fichier ailleurs sur l'ordinateur)."""
    p = (ROOT / path_str).resolve()
    if ROOT not in p.parents and p != ROOT:
        raise SystemExit(f"❌ Chemin refusé (hors du projet) : {path_str}")
    return p

def is_text_file(p):
    return p.suffix.lower() in TEXT_EXTENSIONS or p.name in (".gitignore", "Dockerfile", "Procfile")

def read_lines(p):
    return p.read_text(encoding="utf-8").splitlines(keepends=False)

def write_lines(p, lines):
    p.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")

# ---------------------------------------------------------------------
# Sauvegardes automatiques (filet de sécurité)
# ---------------------------------------------------------------------

def backup(p):
    """Copie le fichier AVANT modification dans .nzela_backups/, avec un
    horodatage précis à la microseconde (pour ne jamais écraser une
    sauvegarde précédente même si deux opérations se suivent très vite).
    Ne supprime jamais rien : on peut toujours revenir en arrière."""
    if not p.exists():
        return None
    rel = p.relative_to(ROOT)
    dest_dir = BACKUP_DIR / rel.parent
    dest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    dest = dest_dir / f"{rel.name}.{stamp}.bak"
    shutil.copy2(p, dest)
    return dest

def list_backups(p):
    rel = p.relative_to(ROOT)
    dest_dir = BACKUP_DIR / rel.parent
    if not dest_dir.exists():
        return []
    return sorted(dest_dir.glob(f"{rel.name}.*.bak"))

# ---------------------------------------------------------------------
# Commandes
# ---------------------------------------------------------------------

def cmd_tree(args):
    start = resolve(args[0]) if args else ROOT
    print(f"\n📁 Arborescence de {start.relative_to(ROOT) if start != ROOT else '.'}\n")
    def walk(p, prefix=""):
        entries = sorted([e for e in p.iterdir() if e.name not in IGNORED_DIRS and not e.name.startswith(".")],
                          key=lambda e: (e.is_file(), e.name.lower()))
        for i, e in enumerate(entries):
            last = i == len(entries) - 1
            branch = "└── " if last else "├── "
            print(prefix + branch + (e.name + "/" if e.is_dir() else e.name))
            if e.is_dir():
                walk(e, prefix + ("    " if last else "│   "))
    walk(start)
    print()

def cmd_list(args):
    start = resolve(args[0]) if args else ROOT
    for e in sorted(start.iterdir(), key=lambda e: (e.is_file(), e.name.lower())):
        if e.name in IGNORED_DIRS: continue
        kind = "DOSSIER" if e.is_dir() else f"{e.stat().st_size:>7} o"
        print(f"  {kind:>10}  {e.name}")

def cmd_view(args):
    if not args:
        print("Usage : voir <fichier> [ligne_debut] [ligne_fin]")
        return
    p = resolve(args[0])
    if not p.exists() or not p.is_file():
        print(f"❌ Fichier introuvable : {args[0]}"); return
    if not is_text_file(p):
        print("⚠️  Ce fichier n'est pas un fichier texte reconnu, affichage brut risqué — annulé."); return
    lines = read_lines(p)
    start = int(args[1]) if len(args) > 1 else 1
    end = int(args[2]) if len(args) > 2 else len(lines)
    start = max(1, start); end = min(len(lines), end)
    print(f"\n📄 {p.relative_to(ROOT)}  (lignes {start} à {end} sur {len(lines)})\n" + "-"*60)
    width = len(str(end))
    for i in range(start, end+1):
        print(f"{str(i).rjust(width)} | {lines[i-1]}")
    print("-"*60 + "\n")

def cmd_find(args):
    if not args:
        print("Usage : chercher <texte> [dossier]"); return
    needle = args[0].lower()
    start = resolve(args[1]) if len(args) > 1 else ROOT
    hits = 0
    for dirpath, dirnames, filenames in os.walk(start):
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DIRS and not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if not is_text_file(p): continue
            try:
                lines = read_lines(p)
            except Exception:
                continue
            for i, line in enumerate(lines, 1):
                if needle in line.lower():
                    hits += 1
                    print(f"{p.relative_to(ROOT)}:{i}: {line.strip()[:140]}")
    print(f"\n🔎 {hits} résultat(s) pour « {args[0]} »\n")

def cmd_edit_line(args):
    if len(args) < 2:
        print('Usage : modifier-ligne <fichier> <numero_ligne> <nouveau_contenu>'); return
    p = resolve(args[0]); n = int(args[1]); new_content = args[2] if len(args) > 2 else ""
    lines = read_lines(p)
    if not (1 <= n <= len(lines)):
        print(f"❌ Le fichier n'a que {len(lines)} lignes, impossible d'aller à la ligne {n}."); return
    old = lines[n-1]
    b = backup(p)
    lines[n-1] = new_content
    write_lines(p, lines)
    print(f"✅ Ligne {n} modifiée dans {p.relative_to(ROOT)}")
    print(f"   avant : {old}")
    print(f"   après : {new_content}")
    print(f"   (sauvegarde : {b.relative_to(ROOT)})" if b else "")

def cmd_insert(args):
    if len(args) < 2:
        print('Usage : inserer <fichier> <apres_ligne> <contenu>'); return
    p = resolve(args[0]); n = int(args[1]); content = args[2] if len(args) > 2 else ""
    lines = read_lines(p)
    if not (0 <= n <= len(lines)):
        print(f"❌ Position invalide (0 à {len(lines)})."); return
    b = backup(p)
    lines.insert(n, content)
    write_lines(p, lines)
    print(f"✅ Ligne insérée après la ligne {n} dans {p.relative_to(ROOT)}")
    print(f"   (sauvegarde : {b.relative_to(ROOT)})" if b else "")

def cmd_delete_lines(args):
    if len(args) < 2:
        print('Usage : supprimer-lignes <fichier> <debut> <fin>'); return
    p = resolve(args[0]); start = int(args[1]); end = int(args[2]) if len(args) > 2 else start
    lines = read_lines(p)
    if not (1 <= start <= end <= len(lines)):
        print(f"❌ Plage invalide (le fichier a {len(lines)} lignes)."); return
    b = backup(p)
    removed = lines[start-1:end]
    del lines[start-1:end]
    write_lines(p, lines)
    print(f"✅ Lignes {start} à {end} supprimées dans {p.relative_to(ROOT)} ({len(removed)} ligne(s))")
    print(f"   (sauvegarde : {b.relative_to(ROOT)})" if b else "")

def cmd_replace(args):
    if len(args) < 3:
        print('Usage : remplacer <fichier> <texte_exact_a_chercher> <texte_de_remplacement>'); return
    p = resolve(args[0]); old, new = args[1], args[2]
    content = p.read_text(encoding="utf-8")
    count = content.count(old)
    if count == 0:
        print("❌ Ce texte est introuvable tel quel dans le fichier (attention aux espaces/majuscules)."); return
    if count > 1:
        print(f"⚠️  Ce texte apparaît {count} fois — remplacement refusé pour éviter une erreur.")
        print("   Utilisez plutôt 'modifier-ligne' avec le numéro de ligne exact."); return
    b = backup(p)
    p.write_text(content.replace(old, new, 1), encoding="utf-8")
    print(f"✅ Texte remplacé dans {p.relative_to(ROOT)}")
    print(f"   (sauvegarde : {b.relative_to(ROOT)})" if b else "")

def cmd_history(args):
    if not args:
        print("Usage : historique <fichier>"); return
    p = resolve(args[0])
    backups = list_backups(p)
    if not backups:
        print("Aucune sauvegarde pour ce fichier."); return
    print(f"\n🕓 Sauvegardes de {p.relative_to(ROOT)} :")
    for b in backups:
        print(f"   {b.name}")
    print()

def cmd_restore(args):
    if not args:
        print("Usage : restaurer <fichier> [nom_exact_de_sauvegarde]"); return
    p = resolve(args[0])
    backups = list_backups(p)
    if not backups:
        print("Aucune sauvegarde disponible pour ce fichier."); return
    target = backups[-1]
    if len(args) > 1:
        matches = [b for b in backups if args[1] in b.name]
        if not matches:
            print("Sauvegarde introuvable avec ce nom."); return
        target = matches[-1]
    target_content = target.read_bytes()  # lu AVANT toute autre écriture, par sécurité
    backup(p)  # on sauvegarde aussi l'état actuel avant d'écraser, au cas où
    p.write_bytes(target_content)
    print(f"✅ {p.relative_to(ROOT)} restauré depuis {target.name}")

def cmd_diff(args):
    if not args:
        print("Usage : diff <fichier>"); return
    p = resolve(args[0])
    backups = list_backups(p)
    if not backups:
        print("Aucune sauvegarde à comparer."); return
    old_lines = backups[-1].read_text(encoding="utf-8").splitlines()
    new_lines = p.read_text(encoding="utf-8").splitlines()
    diff = difflib.unified_diff(old_lines, new_lines, fromfile=f"avant ({backups[-1].name})", tofile="maintenant", lineterm="")
    out = list(diff)
    if not out:
        print("Aucune différence avec la dernière sauvegarde.")
    else:
        print("\n".join(out))

def cmd_logs(args):
    n = int(args[0]) if args else 50
    if not LOG_FILE.exists():
        print("Aucun journal pour l'instant — lancez d'abord le serveur avec la commande 'lancer'."); return
    lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    for line in lines[-n:]:
        print(line)

def cmd_check(args):
    print("🔍 Vérification du projet...\n")
    ok = True
    for py in sorted(ROOT.rglob("*.py")):
        if any(part in IGNORED_DIRS for part in py.parts): continue
        r = subprocess.run([sys.executable, "-m", "py_compile", str(py)], capture_output=True, text=True)
        status = "✅" if r.returncode == 0 else "❌"
        print(f"  {status} {py.relative_to(ROOT)}")
        if r.returncode != 0:
            ok = False
            print("     " + r.stderr.strip().replace("\n", "\n     "))
    print()
    for test in sorted((ROOT / "tests").glob("test_*.py")) if (ROOT/"tests").exists() else []:
        r = subprocess.run([sys.executable, str(test)], capture_output=True, text=True, cwd=ROOT)
        status = "✅" if r.returncode == 0 else "❌"
        print(f"  {status} {test.relative_to(ROOT)} — {r.stdout.strip() or r.stderr.strip()}")
        if r.returncode != 0: ok = False
    print("\n" + ("🟢 Tout est en ordre." if ok else "🔴 Des erreurs ont été trouvées — voir ci-dessus."))

def cmd_run(args):
    print("🚀 Lancement du serveur avec journalisation détaillée...")
    print(f"   Journal en direct dans : {LOG_FILE.relative_to(ROOT)}")
    print("   Ctrl+C pour arrêter.\n")
    env = os.environ.copy()
    env.setdefault("NZELA_LOG_LEVEL", "DEBUG")
    subprocess.run([sys.executable, "-u", "server/main.py"], cwd=ROOT, env=env)

HELP = """
Commandes disponibles :

  arbre [dossier]                         voir la structure des dossiers
  liste [dossier]                         lister le contenu d'un dossier
  voir <fichier> [debut] [fin]            lire un fichier (ou une plage de lignes)
  chercher <texte> [dossier]              chercher un mot/texte dans tout le projet
  modifier-ligne <fichier> <n> <texte>    remplacer UNE ligne précise
  remplacer <fichier> <ancien> <nouveau>  remplacer un texte précis (doit être unique)
  inserer <fichier> <apres_ligne> <texte> ajouter une ligne à un endroit précis
  supprimer-lignes <fichier> <debut> <fin> supprimer une plage de lignes
  historique <fichier>                    voir les sauvegardes disponibles
  diff <fichier>                          voir ce qui a changé depuis la dernière sauvegarde
  restaurer <fichier> [nom_sauvegarde]    annuler la dernière modification
  logs [n]                                voir les n dernières lignes du journal serveur
  verifier                                vérifier que rien n'est cassé (syntaxe + tests)
  lancer                                  démarrer le serveur avec journalisation
  aide                                    afficher ce message

Astuce : chaque commande de modification fait une sauvegarde automatique
AVANT de toucher au fichier. En cas de doute, tapez toujours 'diff' juste
après pour vérifier ce qui a changé, et 'restaurer' pour annuler.
"""

COMMANDS = {
    "arbre": cmd_tree, "tree": cmd_tree,
    "liste": cmd_list, "list": cmd_list,
    "voir": cmd_view, "view": cmd_view,
    "chercher": cmd_find, "find": cmd_find,
    "modifier-ligne": cmd_edit_line, "edit-line": cmd_edit_line,
    "inserer": cmd_insert, "insert": cmd_insert,
    "supprimer-lignes": cmd_delete_lines, "delete-lines": cmd_delete_lines,
    "remplacer": cmd_replace, "replace": cmd_replace,
    "historique": cmd_history, "history": cmd_history,
    "diff": cmd_diff,
    "restaurer": cmd_restore, "restore": cmd_restore,
    "logs": cmd_logs,
    "verifier": cmd_check, "check": cmd_check,
    "lancer": cmd_run, "run": cmd_run,
}

def print_menu():
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                    NZELA CLI — MENU PRINCIPAL                     ║
╠══════════════════════════════════════════════════════════════════╣
║  1. Voir la structure du projet (arbre)                           ║
║  2. Lister le contenu d'un dossier                                ║
║  3. Lire un fichier                                                ║
║  4. Chercher un texte dans tout le projet                         ║
║  5. Modifier une ligne précise                                    ║
║  6. Remplacer un texte précis                                     ║
║  7. Insérer une ligne                                              ║
║  8. Supprimer des lignes                                          ║
║  9. Voir les sauvegardes d'un fichier                             ║
║ 10. Voir ce qui a changé depuis la dernière sauvegarde (diff)     ║
║ 11. Restaurer un fichier (annuler une modification)               ║
║ 12. Voir les journaux du serveur (logs)                           ║
║ 13. Vérifier que rien n'est cassé                                 ║
║ 14. Lancer le serveur                                             ║
║  0. Quitter                                                        ║
╚══════════════════════════════════════════════════════════════════╝
""")

def ask(prompt, default=None):
    v = input(prompt + (f" [{default}] " if default is not None else " ")).strip()
    return v if v else default

def interactive():
    print(HELP)
    while True:
        print_menu()
        choice = input("Votre choix : ").strip()
        try:
            if choice == "0": print("À bientôt."); return
            elif choice == "1": cmd_tree([ask("Dossier de départ (vide = racine du projet) :", "")])
            elif choice == "2": cmd_list([ask("Dossier (vide = racine) :", "")])
            elif choice == "3":
                f = ask("Fichier :"); d = ask("Ligne de début (vide = 1) :", "1"); fN = ask("Ligne de fin (vide = tout) :", "999999")
                cmd_view([f, d, fN])
            elif choice == "4": cmd_find([ask("Texte à chercher :")])
            elif choice == "5":
                f = ask("Fichier :"); n = ask("Numéro de ligne :"); t = ask("Nouveau contenu de cette ligne :", "")
                cmd_edit_line([f, n, t])
            elif choice == "6":
                f = ask("Fichier :"); o = ask("Texte exact à remplacer :"); n = ask("Nouveau texte :", "")
                cmd_replace([f, o, n])
            elif choice == "7":
                f = ask("Fichier :"); n = ask("Insérer après quelle ligne (0 = tout début) :"); t = ask("Contenu à insérer :", "")
                cmd_insert([f, n, t])
            elif choice == "8":
                f = ask("Fichier :"); s = ask("Première ligne à supprimer :"); e = ask("Dernière ligne à supprimer :", s)
                cmd_delete_lines([f, s, e])
            elif choice == "9": cmd_history([ask("Fichier :")])
            elif choice == "10": cmd_diff([ask("Fichier :")])
            elif choice == "11": cmd_restore([ask("Fichier :")])
            elif choice == "12": cmd_logs([ask("Combien de lignes (vide = 50) :", "50")])
            elif choice == "13": cmd_check([])
            elif choice == "14": cmd_run([]); return
            else: print("Choix non reconnu.")
        except SystemExit as e:
            print(e)
        except Exception as e:
            print(f"❌ Erreur : {e}")
        input("\n(Entrée pour continuer) ")

def main():
    args = sys.argv[1:]
    if not args:
        interactive(); return
    cmd, rest = args[0], args[1:]
    if cmd in ("aide", "help", "-h", "--help"):
        print(HELP); return
    fn = COMMANDS.get(cmd)
    if not fn:
        print(f"Commande inconnue : {cmd}\n"); print(HELP); sys.exit(1)
    fn(rest)

if __name__ == "__main__":
    main()
