import json, sys, uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engine'))
from accounts import _hash_password

def load_json(p, default):
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default

def import_demo(root=ROOT):
    demo=ROOT/'demo_data'; data=ROOT/'data'; data.mkdir(exist_ok=True)
    accounts=load_json(data/'accounts.json',[]); by_email={a.get('email'):a for a in accounts}
    for u in load_json(demo/'users.json',[]):
        if u['email'] in by_email: continue
        salt,h=_hash_password(u['password'])
        a={'id':u['id'],'name':u['name'],'email':u['email'].lower(),'salt':salt,'password_hash':h,'created_at':'2026-10-02T00:00:00+00:00','roles':u.get('roles',['user','creator'])}
        accounts.append(a); by_email[a['email']]=a
    (data/'accounts.json').write_text(json.dumps(accounts,ensure_ascii=False,indent=2),encoding='utf-8')
    stores=load_json(data/'stores.json',[]); by_id={s.get('id'):s for s in stores}
    for s in load_json(demo/'stores.json',[]):
        if s['id'] in by_id: continue
        s=dict(s); s['engine_db']=f'data/db/{s["id"]}.db'; stores.append(s)
    (data/'stores.json').write_text(json.dumps(stores,ensure_ascii=False,indent=2),encoding='utf-8')
    # Product data is imported on demand by the application engine; keep the pack authoritative.
    return {'users_added':len([u for u in load_json(demo/'users.json',[]) if u['email'] in by_email]),'stores_total':len(stores),'product_files':len(list((demo/'products').glob('*.json')))}

if __name__=='__main__': print(json.dumps(import_demo(),ensure_ascii=False,indent=2))
